import type { Review, ReviewPlan, Task } from "./types"

export const mockReviews: Review[] = [
  {
    id: "RVW-001",
    name: "Quarterly Risk Assessment",
    description: "Comprehensive review of operational risk factors and mitigation strategies for Q4 2024",
  },
  {
    id: "RVW-002",
    name: "Compliance Documentation Review",
    description: "Annual review of regulatory compliance documentation and procedures",
  },
  {
    id: "RVW-003",
    name: "Customer Data Privacy Audit",
    description: "GDPR compliance audit focusing on customer data handling and privacy controls",
  },
  {
    id: "RVW-004",
    name: "Financial Controls Assessment",
    description: "Internal audit of financial controls and reporting mechanisms",
  },
  {
    id: "RVW-005",
    name: "Cybersecurity Framework Review",
    description: "Evaluation of current cybersecurity measures and incident response procedures",
  },
  {
    id: "RVW-006",
    name: "Vendor Risk Management",
    description: "Assessment of third-party vendor relationships and associated risks",
  },
]

const planTasks: { [planId: string]: Task[] } = {
  "PLN-001": [
    // Main Folder: Risk Assessment
    {
      id: "TSK-001",
      name: "Risk Assessment Framework",
      description: "Develop comprehensive risk assessment framework for quarterly reviews",
      plan_id: "PLN-001",
      parent_id: null,
      assigned_to: "",
      responsible_person: "John Smith",
      days_required: 0,
      difficulty: "Medium",
      completed: false,
      discussions: [
        {
          id: "DISC-001",
          author: "John Smith",
          message:
            "Starting the risk assessment framework development. Need to align with Basel III requirements and internal risk appetite.",
          timestamp: "2024-01-10T09:00:00Z",
          task_id: "TSK-001",
        },
        {
          id: "DISC-002",
          author: "Sarah Johnson",
          message:
            "Should we consider integrating ESG risk factors into this framework? It's becoming increasingly important for regulatory compliance.",
          timestamp: "2024-01-10T14:30:00Z",
          task_id: "TSK-001",
        },
        {
          id: "DISC-003",
          author: "John Smith",
          message:
            "Good point Sarah. Let's include ESG risks as a separate category. I'll coordinate with the sustainability team.",
          timestamp: "2024-01-11T08:15:00Z",
          task_id: "TSK-001",
        },
      ],
      conclusions: [],
      is_folder: true,
    },
    // Sub-folder: Risk Identification
    {
      id: "TSK-002",
      name: "Risk Identification Process",
      description: "Define process for identifying and categorizing operational risks",
      plan_id: "PLN-001",
      parent_id: "TSK-001",
      assigned_to: "",
      responsible_person: "Michael Brown",
      days_required: 0,
      difficulty: "Medium",
      completed: false,
      discussions: [
        {
          id: "DISC-004",
          author: "Michael Brown",
          message:
            "Working on the risk identification methodology. Reviewing industry best practices and regulatory guidelines.",
          timestamp: "2024-01-12T10:00:00Z",
          task_id: "TSK-002",
        },
        {
          id: "DISC-005",
          author: "Emily Davis",
          message:
            "Michael, make sure to include operational risks from digital transformation initiatives. We've seen increased cyber risks.",
          timestamp: "2024-01-12T15:45:00Z",
          task_id: "TSK-002",
        },
      ],
      conclusions: [],
      is_folder: true,
    },
    // Tasks under Risk Identification
    {
      id: "TSK-003",
      name: "Create Risk Categories Matrix",
      description: "Define operational, financial, and compliance risk categories",
      plan_id: "PLN-001",
      parent_id: "TSK-002",
      assigned_to: "Michael Brown",
      days_required: 2,
      difficulty: "Easy",
      completed: true,
      discussions: [
        {
          id: "DISC-006",
          author: "Michael Brown",
          message:
            "Completed the risk categories matrix. Identified 15 main risk categories across operational, financial, and compliance domains.",
          timestamp: "2024-01-15T10:30:00Z",
          task_id: "TSK-003",
        },
        {
          id: "DISC-007",
          author: "David Wilson",
          message:
            "The matrix looks comprehensive. Should we add a technology risk subcategory under operational risks?",
          timestamp: "2024-01-15T13:20:00Z",
          task_id: "TSK-003",
        },
        {
          id: "DISC-008",
          author: "Michael Brown",
          message:
            "Already included technology risks under operational. Created specific subcategories for cybersecurity, system failures, and data breaches.",
          timestamp: "2024-01-15T14:00:00Z",
          task_id: "TSK-003",
        },
      ],
      conclusions: [
        {
          id: "CONC-001",
          author: "Michael Brown",
          message:
            "Risk categories matrix completed with 15 main categories and 45 subcategories. Matrix approved by risk committee and ready for implementation across all business units.",
          timestamp: "2024-01-15T16:00:00Z",
          version: 1,
          task_id: "TSK-003",
        },
      ],
    },
    {
      id: "TSK-004",
      name: "Risk Identification Procedures",
      description: "Document step-by-step procedures for risk identification",
      plan_id: "PLN-001",
      parent_id: "TSK-002",
      assigned_to: "Sarah Johnson",
      days_required: 3,
      difficulty: "Medium",
      completed: false,
      discussions: [
        {
          id: "DISC-009",
          author: "Sarah Johnson",
          message: "Working on the procedures document. Need clarification on escalation process for high-risk items.",
          timestamp: "2024-01-16T14:20:00Z",
          task_id: "TSK-004",
        },
        {
          id: "DISC-010",
          author: "John Smith",
          message:
            "For high-risk items (score >15), immediate escalation to CRO. Medium risks (8-15) go to department heads first.",
          timestamp: "2024-01-16T16:30:00Z",
          task_id: "TSK-004",
        },
        {
          id: "DISC-011",
          author: "Sarah Johnson",
          message: "Thanks John. Also, should we include quarterly risk identification workshops in the procedures?",
          timestamp: "2024-01-17T09:15:00Z",
          task_id: "TSK-004",
        },
        {
          id: "DISC-012",
          author: "Emily Davis",
          message:
            "Yes, quarterly workshops are essential. They help identify emerging risks that might not be caught in regular monitoring.",
          timestamp: "2024-01-17T11:45:00Z",
          task_id: "TSK-004",
        },
      ],
      conclusions: [],
    },
    {
      id: "TSK-005",
      name: "Risk Register Template",
      description: "Create standardized template for risk documentation",
      plan_id: "PLN-001",
      parent_id: "TSK-002",
      assigned_to: "Emily Davis",
      days_required: 1,
      difficulty: "Easy",
      completed: false,
      discussions: [],
      conclusions: [],
    },
    // Sub-folder: Risk Assessment
    {
      id: "TSK-006",
      name: "Risk Scoring & Evaluation",
      description: "Establish scoring criteria and evaluation methodologies",
      plan_id: "PLN-001",
      parent_id: "TSK-001",
      assigned_to: "",
      responsible_person: "Emily Davis",
      days_required: 0,
      difficulty: "Hard",
      completed: false,
      discussions: [
        {
          id: "DISC-015",
          author: "Emily Davis",
          message:
            "Beginning work on risk scoring methodology. Considering both quantitative and qualitative approaches.",
          timestamp: "2024-01-16T09:00:00Z",
          task_id: "TSK-006",
        },
        {
          id: "DISC-016",
          author: "John Smith",
          message:
            "Make sure the scoring aligns with our risk appetite statement and regulatory requirements. We need consistency across all risk types.",
          timestamp: "2024-01-16T11:30:00Z",
          task_id: "TSK-006",
        },
      ],
      conclusions: [],
      is_folder: true,
    },
    // Tasks under Risk Scoring
    {
      id: "TSK-007",
      name: "Impact Assessment Criteria",
      description: "Define criteria for measuring risk impact levels",
      plan_id: "PLN-001",
      parent_id: "TSK-006",
      assigned_to: "Emily Davis",
      days_required: 2,
      difficulty: "Medium",
      completed: false,
      discussions: [
        {
          id: "DISC-017",
          author: "Emily Davis",
          message:
            "Reviewing industry standards for impact assessment. Considering 5-point scale vs 3-point scale for better granularity.",
          timestamp: "2024-01-17T09:15:00Z",
          task_id: "TSK-007",
        },
        {
          id: "DISC-018",
          author: "David Wilson",
          message:
            "I'd recommend 5-point scale. It provides better differentiation for medium-impact risks, which are most common in our portfolio.",
          timestamp: "2024-01-17T13:45:00Z",
          task_id: "TSK-007",
        },
        {
          id: "DISC-019",
          author: "Sarah Johnson",
          message:
            "Agree with David. Also, we should define impact in multiple dimensions: financial, operational, reputational, and regulatory.",
          timestamp: "2024-01-17T15:20:00Z",
          task_id: "TSK-007",
        },
      ],
      conclusions: [],
    },
    {
      id: "TSK-008",
      name: "Probability Assessment Model",
      description: "Develop model for assessing risk probability",
      plan_id: "PLN-001",
      parent_id: "TSK-006",
      assigned_to: "David Wilson",
      days_required: 3,
      difficulty: "Hard",
      completed: false,
      discussions: [],
      conclusions: [],
    },
    {
      id: "TSK-009",
      name: "Risk Heat Map Design",
      description: "Create visual heat map for risk prioritization",
      plan_id: "PLN-001",
      parent_id: "TSK-006",
      assigned_to: "Michael Brown",
      days_required: 1,
      difficulty: "Easy",
      completed: false,
      discussions: [
        {
          id: "DISC-022",
          author: "Michael Brown",
          message:
            "Designing the risk heat map visualization. Using standard red-amber-green color coding for easy interpretation.",
          timestamp: "2024-01-19T09:30:00Z",
          task_id: "TSK-009",
        },
      ],
      conclusions: [],
    },
    // Main Folder: Compliance Documentation
    {
      id: "TSK-010",
      name: "Compliance Documentation Update",
      description: "Update all compliance documentation to reflect current regulations",
      plan_id: "PLN-001",
      parent_id: null,
      assigned_to: "",
      responsible_person: "Sarah Johnson",
      days_required: 0,
      difficulty: "Medium",
      completed: false,
      discussions: [
        {
          id: "DISC-023",
          author: "Sarah Johnson",
          message:
            "Starting comprehensive review of all compliance documentation. Priority on recently updated regulations.",
          timestamp: "2024-01-15T08:00:00Z",
          task_id: "TSK-010",
        },
        {
          id: "DISC-024",
          author: "John Smith",
          message:
            "Sarah, focus on Basel III updates first, then GDPR amendments. These have the highest regulatory impact.",
          timestamp: "2024-01-15T10:45:00Z",
          task_id: "TSK-010",
        },
      ],
      conclusions: [],
      is_folder: true,
    },
    // Sub-folder: Policy Review
    {
      id: "TSK-011",
      name: "Policy Review Process",
      description: "Establish systematic process for regular policy reviews",
      plan_id: "PLN-001",
      parent_id: "TSK-010",
      assigned_to: "",
      responsible_person: "David Wilson",
      days_required: 0,
      difficulty: "Easy",
      completed: false,
      discussions: [
        {
          id: "DISC-025",
          author: "David Wilson",
          message:
            "Establishing systematic policy review process. Aim for annual reviews with quarterly updates for critical policies.",
          timestamp: "2024-01-16T11:00:00Z",
          task_id: "TSK-011",
        },
      ],
      conclusions: [],
      is_folder: true,
    },
    // Tasks under Policy Review
    {
      id: "TSK-012",
      name: "Policy Inventory Audit",
      description: "Complete inventory of all existing policies",
      plan_id: "PLN-001",
      parent_id: "TSK-011",
      assigned_to: "David Wilson",
      days_required: 2,
      difficulty: "Easy",
      completed: true,
      discussions: [
        {
          id: "DISC-026",
          author: "David Wilson",
          message: "Completed policy inventory. Found 47 active policies, 12 need immediate updates, 5 are obsolete.",
          timestamp: "2024-01-18T11:30:00Z",
          task_id: "TSK-012",
        },
        {
          id: "DISC-027",
          author: "Sarah Johnson",
          message:
            "Great work David. Can you prioritize the 12 that need updates? We should tackle the most critical ones first.",
          timestamp: "2024-01-18T13:15:00Z",
          task_id: "TSK-012",
        },
        {
          id: "DISC-028",
          author: "David Wilson",
          message:
            "Already prioritized. Top 5 are related to AML, data protection, credit risk, operational risk, and business continuity.",
          timestamp: "2024-01-18T14:45:00Z",
          task_id: "TSK-012",
        },
      ],
      conclusions: [
        {
          id: "CONC-002",
          author: "David Wilson",
          message:
            "Policy inventory completed successfully. Identified 47 active policies with clear prioritization for updates. 5 obsolete policies marked for retirement. Priority update list created and approved by compliance committee.",
          timestamp: "2024-01-18T15:45:00Z",
          version: 1,
          task_id: "TSK-012",
        },
      ],
    },
    {
      id: "TSK-013",
      name: "Policy Update Schedule",
      description: "Create schedule for systematic policy updates",
      plan_id: "PLN-001",
      parent_id: "TSK-011",
      assigned_to: "Sarah Johnson",
      days_required: 1,
      difficulty: "Easy",
      completed: false,
      discussions: [],
      conclusions: [],
    },
    // Sub-folder: Regulatory Compliance
    {
      id: "TSK-014",
      name: "Regulatory Compliance Mapping",
      description: "Map current processes to regulatory requirements",
      plan_id: "PLN-001",
      parent_id: "TSK-010",
      assigned_to: "",
      responsible_person: "John Smith",
      days_required: 0,
      difficulty: "Hard",
      completed: false,
      discussions: [
        {
          id: "DISC-031",
          author: "John Smith",
          message:
            "Starting regulatory compliance mapping exercise. Focus on Basel III, GDPR, and AML requirements first.",
          timestamp: "2024-01-17T08:30:00Z",
          task_id: "TSK-014",
        },
        {
          id: "DISC-032",
          author: "Emily Davis",
          message:
            "John, don't forget about the new ESG reporting requirements. They're becoming mandatory next quarter.",
          timestamp: "2024-01-17T10:15:00Z",
          task_id: "TSK-014",
        },
      ],
      conclusions: [],
      is_folder: true,
    },
    // Tasks under Regulatory Compliance
    {
      id: "TSK-015",
      name: "Basel III Compliance Check",
      description: "Verify compliance with Basel III requirements",
      plan_id: "PLN-001",
      parent_id: "TSK-014",
      assigned_to: "John Smith",
      days_required: 4,
      difficulty: "Hard",
      completed: false,
      discussions: [
        {
          id: "DISC-033",
          author: "John Smith",
          message:
            "Starting Basel III compliance review. Need to coordinate with finance team for capital adequacy calculations.",
          timestamp: "2024-01-19T08:00:00Z",
          task_id: "TSK-015",
        },
        {
          id: "DISC-034",
          author: "Michael Brown",
          message: "John, I can help with the operational risk capital calculations. Have the latest models ready.",
          timestamp: "2024-01-19T10:30:00Z",
          task_id: "TSK-015",
        },
        {
          id: "DISC-035",
          author: "David Wilson",
          message:
            "Make sure to include the new buffer requirements that came into effect this year. They affect our capital ratios.",
          timestamp: "2024-01-19T14:15:00Z",
          task_id: "TSK-015",
        },
      ],
      conclusions: [],
    },
    {
      id: "TSK-016",
      name: "GDPR Data Processing Review",
      description: "Review data processing activities for GDPR compliance",
      plan_id: "PLN-001",
      parent_id: "TSK-014",
      assigned_to: "Emily Davis",
      days_required: 3,
      difficulty: "Medium",
      completed: false,
      discussions: [
        {
          id: "DISC-036",
          author: "Emily Davis",
          message:
            "Beginning GDPR data processing review. Need to map all customer data flows and processing purposes.",
          timestamp: "2024-01-20T09:30:00Z",
          task_id: "TSK-016",
        },
        {
          id: "DISC-037",
          author: "Sarah Johnson",
          message:
            "Emily, pay special attention to third-party data sharing agreements. Several need updating for GDPR compliance.",
          timestamp: "2024-01-20T11:45:00Z",
          task_id: "TSK-016",
        },
        {
          id: "DISC-038",
          author: "Emily Davis",
          message:
            "Good point Sarah. I'll create a separate checklist for third-party agreements and data processing addendums.",
          timestamp: "2024-01-20T13:20:00Z",
          task_id: "TSK-016",
        },
      ],
      conclusions: [],
    },
    {
      id: "TSK-017",
      name: "AML Procedures Update",
      description: "Update anti-money laundering procedures",
      plan_id: "PLN-001",
      parent_id: "TSK-014",
      assigned_to: "Michael Brown",
      days_required: 2,
      difficulty: "Medium",
      completed: false,
      discussions: [],
      conclusions: [],
    },
  ],
  "PLN-002": [
    {
      id: "TSK-018",
      name: "Data Privacy Impact Assessment",
      description: "Conduct comprehensive DPIA for customer data processing activities",
      plan_id: "PLN-002",
      parent_id: null,
      assigned_to: "Emily Davis",
      days_required: 6,
      difficulty: "Hard",
      completed: false,
      discussions: [
        {
          id: "DISC-041",
          author: "Emily Davis",
          message:
            "Starting DPIA process. Need to map all data flows and processing activities across all customer touchpoints.",
          timestamp: "2024-01-20T09:00:00Z",
          task_id: "TSK-018",
        },
        {
          id: "DISC-042",
          author: "David Wilson",
          message:
            "Emily, make sure to include our new mobile banking app. It processes significant amounts of customer data.",
          timestamp: "2024-01-20T11:15:00Z",
          task_id: "TSK-018",
        },
        {
          id: "DISC-043",
          author: "Emily Davis",
          message:
            "Already on the list David. Also including the new AI-powered fraud detection system and customer analytics platform.",
          timestamp: "2024-01-20T13:30:00Z",
          task_id: "TSK-018",
        },
        {
          id: "DISC-044",
          author: "Sarah Johnson",
          message:
            "Don't forget about data retention policies. We need to ensure we're not keeping customer data longer than necessary.",
          timestamp: "2024-01-20T15:45:00Z",
          task_id: "TSK-018",
        },
      ],
      conclusions: [],
    },
    {
      id: "TSK-019",
      name: "Cybersecurity Controls Review",
      description: "Evaluate current cybersecurity measures and identify improvements",
      plan_id: "PLN-002",
      parent_id: null,
      assigned_to: "David Wilson",
      days_required: 4,
      difficulty: "Medium",
      completed: false,
      discussions: [
        {
          id: "DISC-045",
          author: "David Wilson",
          message:
            "Beginning cybersecurity controls review. Focus on network security, access controls, and incident response procedures.",
          timestamp: "2024-01-21T08:00:00Z",
          task_id: "TSK-019",
        },
        {
          id: "DISC-046",
          author: "Michael Brown",
          message:
            "David, include a review of our third-party security assessments. Several vendors need updated security certifications.",
          timestamp: "2024-01-21T10:30:00Z",
          task_id: "TSK-019",
        },
        {
          id: "DISC-047",
          author: "Emily Davis",
          message:
            "Also consider reviewing our employee security training program. Human factor is often the weakest link.",
          timestamp: "2024-01-21T12:15:00Z",
          task_id: "TSK-019",
        },
      ],
      conclusions: [],
    },
  ],
  "PLN-003": [
    {
      id: "TSK-020",
      name: "Vendor Risk Assessment",
      description: "Assess risks associated with third-party vendors",
      plan_id: "PLN-003",
      parent_id: null,
      assigned_to: "John Smith",
      days_required: 5,
      difficulty: "Medium",
      completed: true,
      discussions: [
        {
          id: "DISC-048",
          author: "John Smith",
          message:
            "Completed vendor risk assessment for all critical suppliers. Identified 3 high-risk vendors requiring immediate attention.",
          timestamp: "2024-01-21T14:30:00Z",
          task_id: "TSK-020",
        },
        {
          id: "DISC-049",
          author: "Sarah Johnson",
          message:
            "John, what are the main risk factors for the high-risk vendors? Are they operational, financial, or compliance related?",
          timestamp: "2024-01-21T15:15:00Z",
          task_id: "TSK-020",
        },
        {
          id: "DISC-050",
          author: "John Smith",
          message:
            "Mix of all three. One has financial stability concerns, another has weak cybersecurity controls, and the third has compliance gaps.",
          timestamp: "2024-01-21T15:45:00Z",
          task_id: "TSK-020",
        },
        {
          id: "DISC-051",
          author: "Emily Davis",
          message:
            "Should we consider alternative vendors for the high-risk ones? Better to have backup options ready.",
          timestamp: "2024-01-21T16:00:00Z",
          task_id: "TSK-020",
        },
      ],
      conclusions: [
        {
          id: "CONC-003",
          author: "John Smith",
          message:
            "Vendor risk assessment completed successfully. Assessed 25 critical vendors with comprehensive risk scoring. 3 high-risk vendors identified with specific remediation plans. Alternative vendor options researched for contingency planning. Board-level recommendations prepared for vendor relationship management.",
          timestamp: "2024-01-21T16:45:00Z",
          version: 1,
          task_id: "TSK-020",
        },
      ],
    },
  ],
}

export const mockPlans: ReviewPlan[] = [
  {
    id: "PLN-001",
    name: "Q4 Compliance Review",
    description: "Comprehensive quarterly compliance review covering all regulatory requirements",
    attached_reviews: "RVW-001",
    persons_concerned: ["John Smith", "Sarah Johnson", "Michael Brown", "Emily Davis", "David Wilson"],
    validation_status: "In Construction",
    tasks: planTasks["PLN-001"] || [],
  },
  {
    id: "PLN-002",
    name: "Data Security Assessment",
    description: "Complete evaluation of data security measures and privacy compliance",
    attached_reviews: "RVW-003",
    persons_concerned: ["Emily Davis", "David Wilson"],
    validation_status: "Validated",
    tasks: planTasks["PLN-002"] || [],
  },
  {
    id: "PLN-003",
    name: "Operational Risk Review",
    description: "Annual operational risk assessment and vendor management review",
    attached_reviews: "RVW-006",
    persons_concerned: ["John Smith", "Emily Davis", "Sarah Johnson"],
    validation_status: "Validated",
    tasks: planTasks["PLN-003"] || [],
  },
]

// Export all tasks for compatibility
export const mockTasks: Task[] = Object.values(planTasks).flat()
