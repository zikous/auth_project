export interface Review {
  id: string
  name: string
  description: string
  status?: "Draft" | "In Progress" | "Completed"
  created_at?: string
  updated_at?: string
}

export interface ReviewPlan {
  id: string
  name: string
  description: string
  attached_reviews: string | null
  persons_concerned: string[]
  validation_status: "In Construction" | "Validated"
  man_days?: number
  tasks: Task[]
}

export interface Discussion {
  id: string
  author: string
  message: string
  timestamp: string
  task_id: string
}

export interface Conclusion {
  id: string
  author: string
  message: string
  timestamp: string
  version: number
  task_id: string
}

export interface WorkingPaper {
  id: string
  name: string
  description: string
  file_name: string
  file_size: string
  uploaded_by: string
  uploaded_at: string
  task_id?: string
  plan_id?: string
  resolved: boolean
}

export interface Task {
  id: string
  name: string
  description: string
  plan_id: string
  parent_id: string | null
  assigned_to: string
  responsible_person?: string
  days_required: number
  difficulty: "Easy" | "Medium" | "Hard"
  completed: boolean
  discussions: Discussion[]
  conclusions: Conclusion[]
  is_folder?: boolean
}

export interface AIPrompt {
  id: string
  content: string
  timestamp: string
  author: string
  isDefault: boolean
}

export interface AIReport {
  id: string
  task_id: string
  content: string
  prompt: AIPrompt
  generated_at: string
  metadata: {
    discussion_count: number
    conclusion_count: number
    completion_rate: number
    confidence_level: "High" | "Medium" | "Low"
    aggregated_from_children: boolean
  }
}

export interface TaskAggregation {
  discussions: Discussion[]
  conclusions: Conclusion[]
  childTasks: Task[]
  totalDiscussions: number
  totalConclusions: number
}
