"use client"

import React, { useState, useCallback } from "react"
import type { ReviewPlan, Task, Discussion, Conclusion } from "@/lib/types"

export function usePlanTasks(initialPlan: ReviewPlan) {
  const [plan, setPlan] = useState<ReviewPlan>(initialPlan)
  const [selectedTask, setSelectedTask] = useState<Task | null>(null)

  const updatePlan = useCallback((updatedPlan: ReviewPlan) => {
    setPlan(updatedPlan)
  }, [])

  // Get all leaf tasks (executable tasks) under a parent
  const getLeafTasksUnderParent = useCallback((tasks: Task[], parentId: string): Task[] => {
    const getAllDescendants = (taskId: string): Task[] => {
      const children = tasks.filter((task) => task.parent_id === taskId)
      let allDescendants: Task[] = []

      children.forEach((child) => {
        const hasChildren = tasks.some((t) => t.parent_id === child.id)
        if (!hasChildren && !child.is_folder) {
          // This is a leaf task (executable task)
          allDescendants.push(child)
        } else {
          // This has children, get their descendants
          allDescendants = allDescendants.concat(getAllDescendants(child.id))
        }
      })

      return allDescendants
    }

    return getAllDescendants(parentId)
  }, [])

  // Calculate completion percentage for parent tasks based only on leaf tasks
  const calculateParentCompletion = useCallback(
    (tasks: Task[], parentId: string): number => {
      const leafTasks = getLeafTasksUnderParent(tasks, parentId)
      if (leafTasks.length === 0) return 0

      const completedLeafTasks = leafTasks.filter((task) => task.completed).length
      return Math.round((completedLeafTasks / leafTasks.length) * 100)
    },
    [getLeafTasksUnderParent],
  )

  // Calculate average difficulty for parent tasks based only on leaf tasks
  const calculateParentDifficulty = useCallback(
    (tasks: Task[], parentId: string): "Easy" | "Medium" | "Hard" | null => {
      const leafTasks = getLeafTasksUnderParent(tasks, parentId)
      if (leafTasks.length === 0) return null // No difficulty if no leaf tasks

      const difficultyValues = { Easy: 1, Medium: 2, Hard: 3 }
      const difficultyLabels = ["Easy", "Medium", "Hard"] as const

      const averageValue =
        leafTasks.reduce((sum, task) => sum + difficultyValues[task.difficulty], 0) / leafTasks.length
      const roundedValue = Math.round(averageValue)

      return difficultyLabels[Math.max(0, Math.min(2, roundedValue - 1))]
    },
    [getLeafTasksUnderParent],
  )

  // Calculate total days for parent tasks (sum of leaf task days only)
  const calculateParentDays = useCallback(
    (tasks: Task[], parentId: string): number => {
      const leafTasks = getLeafTasksUnderParent(tasks, parentId)
      return leafTasks.reduce((sum, task) => sum + task.days_required, 0)
    },
    [getLeafTasksUnderParent],
  )

  // Check if a task is a leaf task (has no children)
  const isLeafTask = useCallback((tasks: Task[], taskId: string): boolean => {
    const task = tasks.find((t) => t.id === taskId)
    if (task?.is_folder) return false // Folders are never leaf tasks
    return !tasks.some((task) => task.parent_id === taskId)
  }, [])

  // Update parent task properties based on children
  const updateParentTaskProperties = useCallback(
    (tasks: Task[]): Task[] => {
      // Create a map for faster lookups
      const taskMap = new Map(tasks.map((task) => [task.id, task]))
      const childrenMap = new Map<string, Task[]>()

      // Build children map
      tasks.forEach((task) => {
        if (task.parent_id) {
          if (!childrenMap.has(task.parent_id)) {
            childrenMap.set(task.parent_id, [])
          }
          childrenMap.get(task.parent_id)!.push(task)
        }
      })

      return tasks.map((task) => {
        const children = childrenMap.get(task.id) || []
        if (children.length > 0) {
          const leafTasks = getLeafTasksUnderParent(tasks, task.id)
          const completionPercentage = calculateParentCompletion(tasks, task.id)
          const allLeafTasksCompleted = leafTasks.length > 0 && leafTasks.every((t) => t.completed)
          const averageDifficulty = calculateParentDifficulty(tasks, task.id)
          const totalDays = calculateParentDays(tasks, task.id)

          return {
            ...task,
            completed: allLeafTasksCompleted,
            difficulty: averageDifficulty || "Medium", // Default to Medium if no leaf tasks
            days_required: totalDays,
          }
        }
        return task
      })
    },
    [calculateParentCompletion, calculateParentDifficulty, calculateParentDays, getLeafTasksUnderParent],
  )

  const createTask = useCallback(
    (taskData: Omit<Task, "id" | "plan_id" | "completed" | "discussions" | "conclusions" | "working_papers">) => {
      // Use React's startTransition to prevent blocking
      React.startTransition(() => {
        const newTask: Task = {
          id: taskData.is_folder
            ? `FLD-${String(plan.tasks.length + 1).padStart(3, "0")}`
            : `TSK-${String(plan.tasks.length + 1).padStart(3, "0")}`,
          plan_id: plan.id,
          completed: false,
          discussions: [],
          conclusions: [],
          working_papers: [],
          ...taskData,
        }

        const updatedTasks = updateParentTaskProperties([...plan.tasks, newTask])
        const updatedPlan = {
          ...plan,
          tasks: updatedTasks,
        }
        setPlan(updatedPlan)
      })
    },
    [plan, updateParentTaskProperties],
  )

  const updateTask = useCallback(
    (taskId: string, updates: Partial<Task>) => {
      const updatedTasks = plan.tasks.map((task) => (task.id === taskId ? { ...task, ...updates } : task))
      const finalTasks = updateParentTaskProperties(updatedTasks)
      const updatedPlan = { ...plan, tasks: finalTasks }
      setPlan(updatedPlan)

      if (selectedTask?.id === taskId) {
        const updatedSelectedTask = finalTasks.find((t) => t.id === taskId)
        setSelectedTask(updatedSelectedTask || null)
      }
    },
    [plan, selectedTask, updateParentTaskProperties],
  )

  const deleteTask = useCallback(
    (taskId: string) => {
      // Also delete all child tasks
      const getChildTaskIds = (parentId: string): string[] => {
        const children = plan.tasks.filter((task) => task.parent_id === parentId)
        let allChildIds = children.map((child) => child.id)
        children.forEach((child) => {
          allChildIds = allChildIds.concat(getChildTaskIds(child.id))
        })
        return allChildIds
      }

      const taskIdsToDelete = [taskId, ...getChildTaskIds(taskId)]
      const updatedTasks = plan.tasks.filter((task) => !taskIdsToDelete.includes(task.id))
      const finalTasks = updateParentTaskProperties(updatedTasks)
      const updatedPlan = { ...plan, tasks: finalTasks }
      setPlan(updatedPlan)

      if (selectedTask && taskIdsToDelete.includes(selectedTask.id)) {
        setSelectedTask(null)
      }
    },
    [plan, selectedTask, updateParentTaskProperties],
  )

  const toggleTaskCompletion = useCallback(
    (taskId: string) => {
      const task = plan.tasks.find((t) => t.id === taskId)
      if (!task) return

      // Only allow toggling completion for leaf tasks (tasks without children)
      const hasChildren = plan.tasks.some((t) => t.parent_id === taskId)
      if (hasChildren) return

      const newCompleted = !task.completed

      const updatedTasks = plan.tasks.map((t) => (t.id === taskId ? { ...t, completed: newCompleted } : t))
      const finalTasks = updateParentTaskProperties(updatedTasks)
      const updatedPlan = { ...plan, tasks: finalTasks }
      setPlan(updatedPlan)

      if (selectedTask?.id === taskId) {
        const updatedSelectedTask = finalTasks.find((t) => t.id === taskId)
        setSelectedTask(updatedSelectedTask || null)
      }
    },
    [plan, selectedTask, updateParentTaskProperties],
  )

  const addDiscussion = useCallback(
    (taskId: string, message: string) => {
      const newDiscussion: Discussion = {
        id: `DISC-${Date.now()}`,
        author: "Current User",
        message,
        timestamp: new Date().toISOString(),
        task_id: taskId,
      }

      const updatedTasks = plan.tasks.map((task) =>
        task.id === taskId ? { ...task, discussions: [...task.discussions, newDiscussion] } : task,
      )
      const updatedPlan = { ...plan, tasks: updatedTasks }
      setPlan(updatedPlan)

      if (selectedTask?.id === taskId) {
        setSelectedTask({ ...selectedTask, discussions: [...selectedTask.discussions, newDiscussion] })
      }
    },
    [plan, selectedTask],
  )

  const addConclusion = useCallback(
    (taskId: string, message: string) => {
      const task = plan.tasks.find((t) => t.id === taskId)
      const newConclusion: Conclusion = {
        id: `CONC-${Date.now()}`,
        author: "Current User",
        message,
        timestamp: new Date().toISOString(),
        version: (task?.conclusions.length || 0) + 1,
        task_id: taskId,
      }

      const updatedTasks = plan.tasks.map((task) =>
        task.id === taskId ? { ...task, conclusions: [...task.conclusions, newConclusion] } : task,
      )
      const updatedPlan = { ...plan, tasks: updatedTasks }
      setPlan(updatedPlan)

      if (selectedTask?.id === taskId) {
        setSelectedTask({ ...selectedTask, conclusions: [...selectedTask.conclusions, newConclusion] })
      }
    },
    [plan, selectedTask],
  )

  const selectTask = useCallback((task: Task) => {
    setSelectedTask(task)
  }, [])

  const getTaskCompletionPercentage = useCallback(
    (taskId: string): number => {
      return calculateParentCompletion(plan.tasks, taskId)
    },
    [plan.tasks, calculateParentCompletion],
  )

  const getTaskDifficulty = useCallback(
    (taskId: string): "Easy" | "Medium" | "Hard" | null => {
      const task = plan.tasks.find((t) => t.id === taskId)
      if (!task) return "Medium"

      const hasChildren = plan.tasks.some((t) => t.parent_id === taskId)
      if (hasChildren) {
        return calculateParentDifficulty(plan.tasks, taskId)
      }
      return task.difficulty
    },
    [plan.tasks, calculateParentDifficulty],
  )

  // Count only leaf tasks (executable tasks, not folders)
  const getLeafTaskCount = useCallback((): number => {
    return plan.tasks.filter((task) => {
      const hasChildren = plan.tasks.some((t) => t.parent_id === task.id)
      return !task.is_folder && !hasChildren
    }).length
  }, [plan.tasks])

  const getCompletedLeafTaskCount = useCallback((): number => {
    return plan.tasks.filter((task) => {
      const hasChildren = plan.tasks.some((t) => t.parent_id === task.id)
      return !task.is_folder && !hasChildren && task.completed
    }).length
  }, [plan.tasks])

  // Get leaf task count under a specific parent
  const getLeafTaskCountUnderParent = useCallback(
    (parentId: string): number => {
      return getLeafTasksUnderParent(plan.tasks, parentId).length
    },
    [plan.tasks, getLeafTasksUnderParent],
  )

  return {
    plan,
    selectedTask,
    updatePlan,
    createTask,
    updateTask,
    deleteTask,
    toggleTaskCompletion,
    addDiscussion,
    addConclusion,
    selectTask,
    getTaskCompletionPercentage,
    getTaskDifficulty,
    getLeafTaskCount,
    getCompletedLeafTaskCount,
    getLeafTaskCountUnderParent,
    isLeafTask: (taskId: string) => isLeafTask(plan.tasks, taskId),
  }
}
