"use client"

import { useState, useEffect } from "react"
import { api } from "@/lib/api/mock-api"
import type { ReviewPlan } from "@/lib/types"

export function usePlans() {
  const [plans, setPlans] = useState<ReviewPlan[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchPlans = async () => {
    try {
      setLoading(true)
      setError(null)
      const response = await api.plans.getAll()
      if (response.success) {
        setPlans(response.data)
      } else {
        setError(response.error || "Failed to fetch plans")
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unknown error occurred")
    } finally {
      setLoading(false)
    }
  }

  const createPlan = async (planData: Partial<ReviewPlan>) => {
    try {
      const response = await api.plans.create(planData)
      if (response.success) {
        setPlans((prev) => [...prev, response.data])
        return { success: true, data: response.data }
      } else {
        return { success: false, error: response.error }
      }
    } catch (err) {
      const error = err instanceof Error ? err.message : "Unknown error occurred"
      return { success: false, error }
    }
  }

  const updatePlan = async (id: string, updates: Partial<ReviewPlan>) => {
    try {
      const response = await api.plans.update(id, updates)
      if (response.success) {
        setPlans((prev) => prev.map((p) => (p.id === id ? response.data : p)))
        return { success: true, data: response.data }
      } else {
        return { success: false, error: response.error }
      }
    } catch (err) {
      const error = err instanceof Error ? err.message : "Unknown error occurred"
      return { success: false, error }
    }
  }

  const deletePlan = async (id: string) => {
    try {
      const response = await api.plans.delete(id)
      if (response.success) {
        setPlans((prev) => prev.filter((p) => p.id !== id))
        return { success: true }
      } else {
        return { success: false, error: response.error }
      }
    } catch (err) {
      const error = err instanceof Error ? err.message : "Unknown error occurred"
      return { success: false, error }
    }
  }

  const deleteMultiplePlans = async (ids: string[]) => {
    try {
      const results = await Promise.all(ids.map((id) => api.plans.delete(id)))
      const successful = results.filter((r) => r.success)
      if (successful.length > 0) {
        setPlans((prev) => prev.filter((p) => !ids.includes(p.id)))
      }
      return { success: successful.length === ids.length, deletedCount: successful.length }
    } catch (err) {
      const error = err instanceof Error ? err.message : "Unknown error occurred"
      return { success: false, error }
    }
  }

  const updatePlanStatus = async (id: string, status: ReviewPlan["validation_status"]) => {
    return updatePlan(id, { validation_status: status })
  }

  useEffect(() => {
    fetchPlans()
  }, [])

  return {
    plans,
    loading,
    error,
    createPlan,
    updatePlan,
    deletePlan,
    deleteMultiplePlans,
    updatePlanStatus,
    refetch: fetchPlans,
  }
}
