"use client"

import { useState } from "react"
import { DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Folder, FileText, MapPin } from "lucide-react"
import type { ReviewPlan } from "@/lib/types"

interface SimpleTaskCreatorProps {
  plan: ReviewPlan
  onCreateTask: (taskData: any) => Promise<any>
  onClose: () => void
  isLoading: boolean
  parentId: string | null
  parentName: string
}

export function SimpleTaskCreator({
  plan,
  onCreateTask,
  onClose,
  isLoading,
  parentId,
  parentName,
}: SimpleTaskCreatorProps) {
  const [itemType, setItemType] = useState<"folder" | "task">("folder")
  const [name, setName] = useState("")
  const [description, setDescription] = useState("")
  const [assignedTo, setAssignedTo] = useState("Unassigned")
  const [daysRequired, setDaysRequired] = useState(1)
  const [difficulty, setDifficulty] = useState<"Easy" | "Medium" | "Hard">("Medium")

  const handleSubmit = async () => {
    if (!name.trim()) return

    const taskData = {
      name: name.trim(),
      description: description.trim(),
      parent_id: parentId,
      assigned_to: assignedTo,
      responsible_person: itemType === "folder" ? assignedTo : undefined,
      days_required: itemType === "task" ? daysRequired : 0,
      difficulty: itemType === "task" ? difficulty : "Medium",
      is_folder: itemType === "folder",
    }

    await onCreateTask(taskData)
  }

  const isFormValid = name.trim().length > 0

  return (
    <>
      <DialogHeader>
        <DialogTitle className="flex items-center gap-2">
          {itemType === "folder" ? (
            <Folder className="h-5 w-5 text-blue-600" />
          ) : (
            <FileText className="h-5 w-5 text-green-600" />
          )}
          Create New {itemType === "folder" ? "Folder" : "Task"}
        </DialogTitle>
        <DialogDescription>Add a new {itemType} to organize your work</DialogDescription>
      </DialogHeader>

      <div className="space-y-6">
        {/* Location Badge */}
        <div className="flex items-center gap-2 p-3 bg-slate-50 rounded-lg">
          <MapPin className="h-4 w-4 text-slate-500" />
          <span className="text-sm text-slate-600">Creating in:</span>
          <Badge variant="outline" className="font-mono">
            {parentName}
          </Badge>
        </div>

        {/* Type Selection */}
        <div className="space-y-3">
          <Label>Item Type</Label>
          <div className="grid grid-cols-2 gap-3">
            <Button
              type="button"
              variant={itemType === "folder" ? "default" : "outline"}
              onClick={() => setItemType("folder")}
              className="h-auto p-4 flex flex-col items-center gap-2"
            >
              <Folder className="h-6 w-6" />
              <div className="text-center">
                <div className="font-medium">Folder</div>
                <div className="text-xs opacity-75">Organize tasks</div>
              </div>
            </Button>
            <Button
              type="button"
              variant={itemType === "task" ? "default" : "outline"}
              onClick={() => setItemType("task")}
              className="h-auto p-4 flex flex-col items-center gap-2"
            >
              <FileText className="h-6 w-6" />
              <div className="text-center">
                <div className="font-medium">Task</div>
                <div className="text-xs opacity-75">Executable work</div>
              </div>
            </Button>
          </div>
        </div>

        {/* Basic Information */}
        <div className="space-y-4">
          <div>
            <Label htmlFor="name">{itemType === "folder" ? "Folder" : "Task"} Name *</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder={`Enter ${itemType} name...`}
            />
          </div>

          <div>
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder={`Describe this ${itemType}...`}
              rows={2}
            />
          </div>

          <div>
            <Label>{itemType === "folder" ? "Responsible Person" : "Executor"}</Label>
            <Select value={assignedTo} onValueChange={setAssignedTo}>
              <SelectTrigger>
                <SelectValue placeholder={`Select ${itemType === "folder" ? "responsible person" : "executor"}...`} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Unassigned">
                  {itemType === "folder" ? "No responsible person" : "Unassigned"}
                </SelectItem>
                {plan.persons_concerned.map((person) => (
                  <SelectItem key={person} value={person}>
                    {person}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Task-specific fields */}
          {itemType === "task" && (
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="days">Days Required</Label>
                <Input
                  id="days"
                  type="number"
                  min="1"
                  value={daysRequired}
                  onChange={(e) => setDaysRequired(Number.parseInt(e.target.value) || 1)}
                />
              </div>
              <div>
                <Label>Difficulty</Label>
                <Select value={difficulty} onValueChange={(value: "Easy" | "Medium" | "Hard") => setDifficulty(value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Easy">Easy</SelectItem>
                    <SelectItem value="Medium">Medium</SelectItem>
                    <SelectItem value="Hard">Hard</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}
        </div>

        {/* Actions */}
        <div className="flex justify-end gap-3 pt-4 border-t">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={!isFormValid || isLoading}>
            {isLoading ? "Creating..." : `Create ${itemType === "folder" ? "Folder" : "Task"}`}
          </Button>
        </div>
      </div>
    </>
  )
}
