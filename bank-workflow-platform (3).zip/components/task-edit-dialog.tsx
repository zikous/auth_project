"use client"

import { useState, useEffect } from "react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { ReviewPlan, Task } from "@/lib/types"
import { useTaskHierarchy } from "@/hooks/use-task-hierarchy"

interface TaskEditDialogProps {
  task: Task | null
  onClose: () => void
  plan: ReviewPlan
  onUpdateTask: (taskId: string, updates: Partial<Task>) => Promise<any>
  isLoading: boolean
  isLeafTask: (taskId: string) => boolean
}

export function TaskEditDialog({ task, onClose, plan, onUpdateTask, isLoading, isLeafTask }: TaskEditDialogProps) {
  const [folderForm, setFolderForm] = useState({
    name: "",
    description: "",
    parent_id: null as string | null,
    responsible_person: "",
    organizational_purpose: "",
    scope_definition: "",
  })

  const [taskForm, setTaskForm] = useState({
    name: "",
    description: "",
    parent_id: null as string | null,
    assigned_to: "",
    days_required: 1,
    difficulty: "Medium" as "Easy" | "Medium" | "Hard",
    objective: "",
    deliverables: "",
    acceptance_criteria: "",
    prerequisites: "",
  })

  const { getOrganizationalFolders, getTaskPlacementOptions } = useTaskHierarchy({
    tasks: plan.tasks,
  })

  useEffect(() => {
    if (!task) return

    const taskIsLeaf = isLeafTask(task.id)
    const descriptionParts = task.description.split("\n\n")
    const baseDescription = descriptionParts[0] || ""

    if (taskIsLeaf) {
      // Parse task-specific fields
      let objective = "",
        deliverables = "",
        acceptanceCriteria = "",
        prerequisites = ""

      descriptionParts.forEach((part) => {
        if (part.startsWith("Objective:")) {
          objective = part.replace("Objective:", "").trim()
        } else if (part.startsWith("Deliverables:")) {
          deliverables = part.replace("Deliverables:", "").trim()
        } else if (part.startsWith("Acceptance Criteria:")) {
          acceptanceCriteria = part.replace("Acceptance Criteria:", "").trim()
        } else if (part.startsWith("Prerequisites:")) {
          prerequisites = part.replace("Prerequisites:", "").trim()
        }
      })

      setTaskForm({
        name: task.name,
        description: baseDescription,
        parent_id: task.parent_id || "root",
        assigned_to: task.assigned_to,
        days_required: task.days_required,
        difficulty: task.difficulty,
        objective,
        deliverables,
        acceptance_criteria: acceptanceCriteria,
        prerequisites,
      })
    } else {
      // Parse folder-specific fields
      let organizationalPurpose = "",
        scopeDefinition = ""

      descriptionParts.forEach((part) => {
        if (part.startsWith("Organizational Purpose:")) {
          organizationalPurpose = part.replace("Organizational Purpose:", "").trim()
        } else if (part.startsWith("Scope Definition:")) {
          scopeDefinition = part.replace("Scope Definition:", "").trim()
        }
      })

      setFolderForm({
        name: task.name,
        description: baseDescription,
        parent_id: task.parent_id,
        responsible_person: task.responsible_person || "",
        organizational_purpose: organizationalPurpose,
        scope_definition: scopeDefinition,
      })
    }
  }, [task, isLeafTask])

  const handleUpdateTask = async () => {
    if (!task) return

    const taskIsLeaf = isLeafTask(task.id)

    if (taskIsLeaf) {
      // Update task
      const updates = {
        name: taskForm.name,
        description:
          `${taskForm.description}\n\nObjective: ${taskForm.objective}\n\nDeliverables:\n${taskForm.deliverables}\n\nAcceptance Criteria:\n${taskForm.acceptance_criteria}${taskForm.prerequisites ? `\n\nPrerequisites:\n${taskForm.prerequisites}` : ""}`.trim(),
        parent_id: taskForm.parent_id === "root" ? null : taskForm.parent_id,
        assigned_to: taskForm.assigned_to,
        difficulty: taskForm.difficulty,
        days_required: taskForm.days_required,
      }
      const result = await onUpdateTask(task.id, updates)
      if (result) {
        onClose()
      }
    } else {
      // Update folder
      const updates = {
        name: folderForm.name,
        description:
          `${folderForm.description}\n\nOrganizational Purpose: ${folderForm.organizational_purpose}\n\nScope Definition: ${folderForm.scope_definition}`.trim(),
        parent_id: folderForm.parent_id,
        responsible_person: folderForm.responsible_person,
      }
      const result = await onUpdateTask(task.id, updates)
      if (result) {
        onClose()
      }
    }
  }

  if (!task) return null

  const taskIsLeaf = isLeafTask(task.id)

  return (
    <Dialog open={!!task} onOpenChange={() => onClose()}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Edit {taskIsLeaf ? "Task" : "Folder"}</DialogTitle>
          <DialogDescription>Update the item specifications</DialogDescription>
        </DialogHeader>

        {!taskIsLeaf ? (
          /* EDIT FOLDER */
          <div className="space-y-4">
            <div className="bg-blue-50 dark:bg-blue-950/20 p-4 rounded-lg">
              <h3 className="font-medium text-blue-900 dark:text-blue-300 mb-3">Folder Configuration</h3>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <div className="space-y-3">
                  <div>
                    <Label>Folder Name</Label>
                    <Input
                      value={folderForm.name}
                      onChange={(e) => setFolderForm({ ...folderForm, name: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label>Description</Label>
                    <Textarea
                      value={folderForm.description}
                      onChange={(e) => setFolderForm({ ...folderForm, description: e.target.value })}
                      rows={2}
                    />
                  </div>
                  <div>
                    <Label>Parent Folder</Label>
                    <Select
                      value={folderForm.parent_id || "root"}
                      onValueChange={(value) =>
                        setFolderForm({ ...folderForm, parent_id: value === "root" ? null : value })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="root">Root Level</SelectItem>
                        {getOrganizationalFolders()
                          .filter((folder) => folder.id !== task?.id)
                          .map((folder) => (
                            <SelectItem key={folder.id} value={folder.id}>
                              {"  ".repeat(folder.level)}
                              {folder.path}
                            </SelectItem>
                          ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-3">
                  <div>
                    <Label>Organizational Purpose</Label>
                    <Textarea
                      value={folderForm.organizational_purpose}
                      onChange={(e) => setFolderForm({ ...folderForm, organizational_purpose: e.target.value })}
                      rows={3}
                    />
                  </div>
                  <div>
                    <Label>Scope Definition</Label>
                    <Textarea
                      value={folderForm.scope_definition}
                      onChange={(e) => setFolderForm({ ...folderForm, scope_definition: e.target.value })}
                      rows={2}
                    />
                  </div>
                  <div>
                    <Label>Responsible Person</Label>
                    <Select
                      value={folderForm.responsible_person || "none"}
                      onValueChange={(value) =>
                        setFolderForm({ ...folderForm, responsible_person: value === "none" ? "" : value })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">No responsible person</SelectItem>
                        {plan.persons_concerned.map((person) => (
                          <SelectItem key={person} value={person}>
                            {person}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ) : (
          /* EDIT TASK */
          <div className="space-y-4">
            <div className="bg-green-50 dark:bg-green-950/20 p-4 rounded-lg">
              <h3 className="font-medium text-green-900 dark:text-green-300 mb-3">Task Specifications</h3>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <div className="space-y-3">
                  <div>
                    <Label>Task Name</Label>
                    <Input value={taskForm.name} onChange={(e) => setTaskForm({ ...taskForm, name: e.target.value })} />
                  </div>
                  <div>
                    <Label>Description</Label>
                    <Textarea
                      value={taskForm.description}
                      onChange={(e) => setTaskForm({ ...taskForm, description: e.target.value })}
                      rows={2}
                    />
                  </div>
                  <div>
                    <Label>Location</Label>
                    <Select
                      value={taskForm.parent_id || "root"}
                      onValueChange={(value) =>
                        setTaskForm({
                          ...taskForm,
                          parent_id: value === "root" ? null : value,
                        })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {getTaskPlacementOptions().map((option) => (
                          <SelectItem key={option.id} value={option.id}>
                            {"  ".repeat(option.level)}
                            {option.path}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <Label>Executor</Label>
                      <Select
                        value={taskForm.assigned_to || "none"}
                        onValueChange={(value) =>
                          setTaskForm({ ...taskForm, assigned_to: value === "none" ? "" : value })
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="none">Unassigned</SelectItem>
                          {plan.persons_concerned.map((person) => (
                            <SelectItem key={person} value={person}>
                              {person}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label>Difficulty</Label>
                      <Select
                        value={taskForm.difficulty}
                        onValueChange={(value: "Easy" | "Medium" | "Hard") =>
                          setTaskForm({ ...taskForm, difficulty: value })
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Easy">Easy</SelectItem>
                          <SelectItem value="Medium">Medium</SelectItem>
                          <SelectItem value="Hard">Hard</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div>
                    <Label>Days Required</Label>
                    <Input
                      type="number"
                      min="1"
                      value={taskForm.days_required}
                      onChange={(e) =>
                        setTaskForm({ ...taskForm, days_required: Number.parseInt(e.target.value) || 1 })
                      }
                    />
                  </div>
                </div>
                <div className="space-y-3">
                  <div>
                    <Label>Objective</Label>
                    <Textarea
                      value={taskForm.objective}
                      onChange={(e) => setTaskForm({ ...taskForm, objective: e.target.value })}
                      rows={2}
                    />
                  </div>
                  <div>
                    <Label>Deliverables</Label>
                    <Textarea
                      value={taskForm.deliverables}
                      onChange={(e) => setTaskForm({ ...taskForm, deliverables: e.target.value })}
                      rows={3}
                    />
                  </div>
                  <div>
                    <Label>Acceptance Criteria</Label>
                    <Textarea
                      value={taskForm.acceptance_criteria}
                      onChange={(e) => setTaskForm({ ...taskForm, acceptance_criteria: e.target.value })}
                      rows={3}
                    />
                  </div>
                  <div>
                    <Label>Prerequisites</Label>
                    <Textarea
                      value={taskForm.prerequisites}
                      onChange={(e) => setTaskForm({ ...taskForm, prerequisites: e.target.value })}
                      rows={2}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleUpdateTask} disabled={isLoading}>
            {isLoading ? "Updating..." : "Update"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
