"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { QuickActionButton } from "@/components/ui/quick-action-button"
import { StatusIndicator } from "@/components/ui/status-indicator"
import { Folder, FileText, ArrowRight, ArrowLeft, Check, X } from "lucide-react"
import type { ReviewPlan } from "@/lib/types"
import { useTaskHierarchy } from "@/hooks/use-task-hierarchy"

interface SimplifiedTaskCreationProps {
  plan: ReviewPlan
  onCreateTask: (taskData: any) => Promise<any>
  onClose: () => void
  isLoading: boolean
}

type CreationStep = "choose-type" | "basic-info" | "details" | "review"
type ItemType = "folder" | "task"

export function SimplifiedTaskCreation({ plan, onCreateTask, onClose, isLoading }: SimplifiedTaskCreationProps) {
  const [step, setStep] = useState<CreationStep>("choose-type")
  const [itemType, setItemType] = useState<ItemType | null>(null)
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    parent_id: null as string | null,
    assigned_to: "",
    responsible_person: "",
    days_required: 1,
    difficulty: "Medium" as "Easy" | "Medium" | "Hard",
    objective: "",
    deliverables: "",
    acceptance_criteria: "",
    organizational_purpose: "",
    scope_definition: "",
  })

  const { getOrganizationalFolders, getTaskPlacementOptions } = useTaskHierarchy({
    tasks: plan.tasks,
  })

  const resetForm = () => {
    setFormData({
      name: "",
      description: "",
      parent_id: null,
      assigned_to: "",
      responsible_person: "",
      days_required: 1,
      difficulty: "Medium",
      objective: "",
      deliverables: "",
      acceptance_criteria: "",
      organizational_purpose: "",
      scope_definition: "",
    })
    setStep("choose-type")
    setItemType(null)
  }

  const handleNext = () => {
    const steps: CreationStep[] = ["choose-type", "basic-info", "details", "review"]
    const currentIndex = steps.indexOf(step)
    if (currentIndex < steps.length - 1) {
      setStep(steps[currentIndex + 1])
    }
  }

  const handleBack = () => {
    const steps: CreationStep[] = ["choose-type", "basic-info", "details", "review"]
    const currentIndex = steps.indexOf(step)
    if (currentIndex > 0) {
      setStep(steps[currentIndex - 1])
    }
  }

  const handleCreate = async () => {
    if (!itemType) return

    const taskData = {
      name: formData.name,
      description:
        itemType === "folder"
          ? `${formData.description}\n\nOrganizational Purpose: ${formData.organizational_purpose}\n\nScope Definition: ${formData.scope_definition}`.trim()
          : `${formData.description}\n\nObjective: ${formData.objective}\n\nDeliverables:\n${formData.deliverables}\n\nAcceptance Criteria:\n${formData.acceptance_criteria}`.trim(),
      parent_id: formData.parent_id === "root" ? null : formData.parent_id,
      assigned_to: itemType === "task" ? formData.assigned_to : "",
      responsible_person: itemType === "folder" ? formData.responsible_person : "",
      days_required: itemType === "task" ? formData.days_required : 0,
      difficulty: formData.difficulty,
      is_folder: itemType === "folder",
    }

    const result = await onCreateTask(taskData)
    if (result) {
      resetForm()
      onClose()
    }
  }

  const canProceed = () => {
    switch (step) {
      case "choose-type":
        return itemType !== null
      case "basic-info":
        return formData.name.trim() !== "" && formData.parent_id !== null
      case "details":
        if (itemType === "folder") {
          return formData.organizational_purpose.trim() !== ""
        } else {
          return formData.objective.trim() !== ""
        }
      case "review":
        return true
      default:
        return false
    }
  }

  const getStepTitle = () => {
    switch (step) {
      case "choose-type":
        return "What would you like to create?"
      case "basic-info":
        return `${itemType === "folder" ? "Folder" : "Task"} Basic Information`
      case "details":
        return `${itemType === "folder" ? "Folder" : "Task"} Details`
      case "review":
        return "Review & Create"
      default:
        return ""
    }
  }

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader className="text-center border-b">
        <CardTitle className="text-xl">{getStepTitle()}</CardTitle>
        <div className="flex items-center justify-center gap-2 mt-4">
          {["choose-type", "basic-info", "details", "review"].map((s, index) => (
            <div
              key={s}
              className={`w-3 h-3 rounded-full transition-colors ${
                s === step
                  ? "bg-blue-600"
                  : index < ["choose-type", "basic-info", "details", "review"].indexOf(step)
                    ? "bg-green-500"
                    : "bg-slate-200"
              }`}
            />
          ))}
        </div>
      </CardHeader>

      <CardContent className="p-6">
        {step === "choose-type" && (
          <div className="space-y-6">
            <p className="text-center text-slate-600 mb-6">
              Choose what you'd like to create to organize your work effectively
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <QuickActionButton
                icon={Folder}
                label="Create Folder"
                description="Organize related tasks"
                variant="folder"
                onClick={() => {
                  setItemType("folder")
                  handleNext()
                }}
              />
              <QuickActionButton
                icon={FileText}
                label="Create Task"
                description="Define specific work"
                variant="task"
                onClick={() => {
                  setItemType("task")
                  handleNext()
                }}
              />
            </div>
            <div className="bg-slate-50 p-4 rounded-lg">
              <h4 className="font-medium text-slate-800 mb-2">Quick Guide:</h4>
              <ul className="text-sm text-slate-600 space-y-1">
                <li>
                  • <strong>Folders</strong> help organize and group related work
                </li>
                <li>
                  • <strong>Tasks</strong> are specific work items that can be completed
                </li>
                <li>• Create folders first, then add tasks inside them</li>
              </ul>
            </div>
          </div>
        )}

        {step === "basic-info" && (
          <div className="space-y-6">
            <div className="flex items-center gap-2 mb-4">
              {itemType === "folder" ? (
                <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                  <Folder className="h-3 w-3 mr-1" />
                  Folder
                </Badge>
              ) : (
                <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                  <FileText className="h-3 w-3 mr-1" />
                  Task
                </Badge>
              )}
            </div>

            <div className="space-y-4">
              <div>
                <Label htmlFor="name" className="text-base font-medium">
                  {itemType === "folder" ? "Folder" : "Task"} Name *
                </Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder={itemType === "folder" ? "e.g., Risk Assessment" : "e.g., Create Risk Matrix"}
                  className="mt-2"
                />
              </div>

              <div>
                <Label className="text-base font-medium">Location *</Label>
                <Select
                  value={formData.parent_id || "root"}
                  onValueChange={(value) => setFormData({ ...formData, parent_id: value === "root" ? null : value })}
                >
                  <SelectTrigger className="mt-2">
                    <SelectValue placeholder="Choose where to place this item" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="root">📁 Root Level</SelectItem>
                    {(itemType === "folder" ? getOrganizationalFolders() : getTaskPlacementOptions().slice(1)).map(
                      (option) => (
                        <SelectItem key={option.id} value={option.id}>
                          {"  ".repeat(option.level)}📁 {option.path}
                        </SelectItem>
                      ),
                    )}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="description" className="text-base font-medium">
                  Brief Description
                </Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder={`Brief overview of this ${itemType}`}
                  rows={3}
                  className="mt-2"
                />
              </div>
            </div>
          </div>
        )}

        {step === "details" && itemType === "folder" && (
          <div className="space-y-6">
            <StatusIndicator status="pending" message="Define the organizational purpose and scope for this folder" />

            <div className="space-y-4">
              <div>
                <Label htmlFor="org-purpose" className="text-base font-medium">
                  Organizational Purpose *
                </Label>
                <Textarea
                  id="org-purpose"
                  value={formData.organizational_purpose}
                  onChange={(e) => setFormData({ ...formData, organizational_purpose: e.target.value })}
                  placeholder="What is the main purpose of this folder? What does it represent organizationally?"
                  rows={3}
                  className="mt-2"
                />
              </div>

              <div>
                <Label htmlFor="scope-def" className="text-base font-medium">
                  Scope Definition
                </Label>
                <Textarea
                  id="scope-def"
                  value={formData.scope_definition}
                  onChange={(e) => setFormData({ ...formData, scope_definition: e.target.value })}
                  placeholder="What types of work or tasks belong in this folder?"
                  rows={2}
                  className="mt-2"
                />
              </div>

              <div>
                <Label className="text-base font-medium">Responsible Person</Label>
                <Select
                  value={formData.responsible_person || "none"}
                  onValueChange={(value) =>
                    setFormData({ ...formData, responsible_person: value === "none" ? "" : value })
                  }
                >
                  <SelectTrigger className="mt-2">
                    <SelectValue placeholder="Who is responsible for this folder?" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">No specific owner</SelectItem>
                    {plan.persons_concerned.map((person) => (
                      <SelectItem key={person} value={person}>
                        {person}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        )}

        {step === "details" && itemType === "task" && (
          <div className="space-y-6">
            <StatusIndicator status="pending" message="Define the work specifications and requirements for this task" />

            <div className="space-y-4">
              <div>
                <Label htmlFor="objective" className="text-base font-medium">
                  Primary Objective *
                </Label>
                <Textarea
                  id="objective"
                  value={formData.objective}
                  onChange={(e) => setFormData({ ...formData, objective: e.target.value })}
                  placeholder="What is the main goal of this task?"
                  rows={2}
                  className="mt-2"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label className="text-base font-medium">Assigned To</Label>
                  <Select
                    value={formData.assigned_to || "none"}
                    onValueChange={(value) => setFormData({ ...formData, assigned_to: value === "none" ? "" : value })}
                  >
                    <SelectTrigger className="mt-2">
                      <SelectValue placeholder="Select assignee" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="none">Unassigned</SelectItem>
                      {plan.persons_concerned.map((person) => (
                        <SelectItem key={person} value={person}>
                          {person}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-base font-medium">Difficulty</Label>
                  <Select
                    value={formData.difficulty}
                    onValueChange={(value: "Easy" | "Medium" | "Hard") =>
                      setFormData({ ...formData, difficulty: value })
                    }
                  >
                    <SelectTrigger className="mt-2">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Easy">🟢 Easy</SelectItem>
                      <SelectItem value="Medium">🟡 Medium</SelectItem>
                      <SelectItem value="Hard">🔴 Hard</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <Label htmlFor="deliverables" className="text-base font-medium">
                  Expected Deliverables
                </Label>
                <Textarea
                  id="deliverables"
                  value={formData.deliverables}
                  onChange={(e) => setFormData({ ...formData, deliverables: e.target.value })}
                  placeholder="• List specific outputs&#10;• Documents to be created&#10;• Results to be achieved"
                  rows={3}
                  className="mt-2"
                />
              </div>

              <div>
                <Label htmlFor="acceptance" className="text-base font-medium">
                  Acceptance Criteria
                </Label>
                <Textarea
                  id="acceptance"
                  value={formData.acceptance_criteria}
                  onChange={(e) => setFormData({ ...formData, acceptance_criteria: e.target.value })}
                  placeholder="• Conditions for completion&#10;• Quality standards&#10;• Approval requirements"
                  rows={3}
                  className="mt-2"
                />
              </div>
            </div>
          </div>
        )}

        {step === "review" && (
          <div className="space-y-6">
            <StatusIndicator
              status="success"
              message={`Ready to create ${itemType}. Please review the details below.`}
            />

            <div className="bg-slate-50 p-4 rounded-lg space-y-3">
              <div className="flex items-center gap-2">
                {itemType === "folder" ? (
                  <Badge className="bg-blue-100 text-blue-700">
                    <Folder className="h-3 w-3 mr-1" />
                    Folder
                  </Badge>
                ) : (
                  <Badge className="bg-green-100 text-green-700">
                    <FileText className="h-3 w-3 mr-1" />
                    Task
                  </Badge>
                )}
                <span className="font-medium">{formData.name}</span>
              </div>

              <div className="text-sm text-slate-600">
                <p>
                  <strong>Location:</strong>{" "}
                  {formData.parent_id
                    ? (itemType === "folder" ? getOrganizationalFolders() : getTaskPlacementOptions()).find(
                        (f) => f.id === formData.parent_id,
                      )?.path || "Unknown"
                    : "Root Level"}
                </p>

                {formData.description && (
                  <p>
                    <strong>Description:</strong> {formData.description}
                  </p>
                )}

                {itemType === "folder" && formData.organizational_purpose && (
                  <p>
                    <strong>Purpose:</strong> {formData.organizational_purpose}
                  </p>
                )}

                {itemType === "task" && formData.objective && (
                  <p>
                    <strong>Objective:</strong> {formData.objective}
                  </p>
                )}

                {itemType === "task" && formData.assigned_to && (
                  <p>
                    <strong>Assigned to:</strong> {formData.assigned_to}
                  </p>
                )}
              </div>
            </div>
          </div>
        )}

        <div className="flex justify-between items-center mt-8 pt-6 border-t">
          <div className="flex gap-2">
            {step !== "choose-type" && (
              <Button variant="outline" onClick={handleBack} disabled={isLoading}>
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back
              </Button>
            )}
            <Button variant="outline" onClick={onClose} disabled={isLoading}>
              <X className="h-4 w-4 mr-2" />
              Cancel
            </Button>
          </div>

          <div>
            {step !== "review" ? (
              <Button onClick={handleNext} disabled={!canProceed() || isLoading}>
                Next
                <ArrowRight className="h-4 w-4 ml-2" />
              </Button>
            ) : (
              <Button onClick={handleCreate} disabled={isLoading} className="bg-green-600 hover:bg-green-700">
                <Check className="h-4 w-4 mr-2" />
                {isLoading ? "Creating..." : `Create ${itemType === "folder" ? "Folder" : "Task"}`}
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
