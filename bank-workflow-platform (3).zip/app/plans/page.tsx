"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Plus, Search, Edit, Trash2, Users, CheckCircle, MoreHorizontal, Calendar, Loader2 } from "lucide-react"
import type { ReviewPlan } from "@/lib/types"
import Link from "next/link"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { usePlans } from "@/hooks/use-plans"
import { useReviews } from "@/hooks/use-reviews"
import { useToast } from "@/hooks/use-toast"

export default function PlansPage() {
  const { plans, loading, error, createPlan, updatePlan, deletePlan, deleteMultiplePlans, updatePlanStatus } =
    usePlans()
  const { reviews } = useReviews()
  const { toast } = useToast()

  const [searchTerm, setSearchTerm] = useState("")
  const [isCreateOpen, setIsCreateOpen] = useState(false)
  const [editingPlan, setEditingPlan] = useState<ReviewPlan | null>(null)
  const [selectedItems, setSelectedItems] = useState<string[]>([])
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    attached_reviews: null as string | null, // Changed from array to single string
    persons_concerned: [] as string[],
    man_days: 0,
  })

  const filteredPlans = plans.filter(
    (plan) =>
      plan.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      plan.id.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Validated":
        return "bg-green-100 text-green-700"
      default:
        return "bg-orange-100 text-orange-700" // For "In Construction"
    }
  }

  const getLeafTaskCounts = (plan: ReviewPlan) => {
    const leafTasks = plan.tasks.filter((task) => !plan.tasks.some((t) => t.parent_id === task.id))
    const completedLeafTasks = leafTasks.filter((task) => task.completed)
    return { total: leafTasks.length, completed: completedLeafTasks.length }
  }

  const handleCreate = async () => {
    if (!formData.name.trim()) {
      toast({
        title: "Validation Error",
        description: "Please enter a plan name",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)
    const result = await createPlan(formData)

    if (result.success) {
      toast({
        title: "Success",
        description: "Plan created successfully",
      })
      resetForm()
      setIsCreateOpen(false)
    } else {
      toast({
        title: "Error",
        description: result.error || "Failed to create plan",
        variant: "destructive",
      })
    }
    setIsSubmitting(false)
  }

  const handleEdit = (plan: ReviewPlan) => {
    setEditingPlan(plan)
    setFormData({
      name: plan.name,
      description: plan.description,
      attached_reviews: plan.attached_reviews,
      persons_concerned: plan.persons_concerned,
      man_days: plan.man_days || 0,
    })
  }

  const handleUpdate = async () => {
    if (!editingPlan || !formData.name.trim()) {
      toast({
        title: "Validation Error",
        description: "Please enter a plan name",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)
    const result = await updatePlan(editingPlan.id, formData)

    if (result.success) {
      toast({
        title: "Success",
        description: "Plan updated successfully",
      })
      setEditingPlan(null)
      resetForm()
    } else {
      toast({
        title: "Error",
        description: result.error || "Failed to update plan",
        variant: "destructive",
      })
    }
    setIsSubmitting(false)
  }

  const handleDelete = async (id: string) => {
    const result = await deletePlan(id)

    if (result.success) {
      toast({
        title: "Success",
        description: "Plan deleted successfully",
      })
      setSelectedItems(selectedItems.filter((item) => item !== id))
    } else {
      toast({
        title: "Error",
        description: result.error || "Failed to delete plan",
        variant: "destructive",
      })
    }
  }

  const handleStatusChange = async (id: string, newStatus: ReviewPlan["validation_status"]) => {
    const result = await updatePlanStatus(id, newStatus)

    if (result.success) {
      toast({
        title: "Success",
        description: `Plan status updated to ${newStatus}`,
      })
    } else {
      toast({
        title: "Error",
        description: result.error || "Failed to update plan status",
        variant: "destructive",
      })
    }
  }

  const resetForm = () => {
    setFormData({
      name: "",
      description: "",
      attached_reviews: null,
      persons_concerned: [],
      man_days: 0,
    })
  }

  const handleReviewSelect = (reviewId: string) => {
    setFormData({
      ...formData,
      attached_reviews: reviewId,
    })
  }

  const addPerson = (person: string) => {
    if (person && !formData.persons_concerned.includes(person)) {
      setFormData({
        ...formData,
        persons_concerned: [...formData.persons_concerned, person],
      })
    }
  }

  const removePerson = (person: string) => {
    setFormData({
      ...formData,
      persons_concerned: formData.persons_concerned.filter((p) => p !== person),
    })
  }

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedItems(filteredPlans.map((p) => p.id))
    } else {
      setSelectedItems([])
    }
  }

  const handleSelectItem = (id: string, checked: boolean) => {
    if (checked) {
      setSelectedItems([...selectedItems, id])
    } else {
      setSelectedItems(selectedItems.filter((item) => item !== id))
    }
  }

  const handleBulkDelete = async () => {
    const result = await deleteMultiplePlans(selectedItems)

    if (result.success) {
      toast({
        title: "Success",
        description: `${result.deletedCount} plans deleted successfully`,
      })
      setSelectedItems([])
    } else {
      toast({
        title: "Error",
        description: result.error || "Failed to delete plans",
        variant: "destructive",
      })
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="flex items-center space-x-2">
          <Loader2 className="h-6 w-6 animate-spin" />
          <span>Loading plans...</span>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-lg font-semibold text-red-600 mb-2">Error Loading Plans</h2>
          <p className="text-gray-600">{error}</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-full mx-auto p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-semibold text-gray-900">Plans</h1>
            <p className="text-gray-600 mt-1">{plans.length} total plans</p>
          </div>
          <div className="flex items-center space-x-3">
            {selectedItems.length > 0 && (
              <Button variant="outline" onClick={handleBulkDelete} className="text-red-600 hover:text-red-700">
                <Trash2 className="h-4 w-4 mr-2" />
                Delete ({selectedItems.length})
              </Button>
            )}
            <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
              <DialogTrigger asChild>
                <Button className="bg-green-600 hover:bg-green-700">
                  <Plus className="h-4 w-4 mr-2" />
                  New Plan
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle>New Plan</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div>
                    <Label htmlFor="name">Plan Name</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="Plan name"
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="description">Description</Label>
                    <Textarea
                      id="description"
                      value={formData.description}
                      onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                      placeholder="Brief description"
                      className="mt-1"
                      rows={3}
                    />
                  </div>
                  <div>
                    <Label htmlFor="man-days">Man Days</Label>
                    <Input
                      id="man-days"
                      type="number"
                      min="0"
                      value={formData.man_days}
                      onChange={(e) => setFormData({ ...formData, man_days: Number.parseInt(e.target.value) || 0 })}
                      placeholder="Estimated man days"
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label>Review</Label>
                    <div className="mt-2 max-h-32 overflow-y-auto border rounded p-3 space-y-2">
                      <div className="flex items-center space-x-2">
                        <input
                          type="radio"
                          id="no-review"
                          name="review"
                          checked={formData.attached_reviews === null}
                          onChange={() => setFormData({ ...formData, attached_reviews: null })}
                        />
                        <Label htmlFor="no-review" className="text-sm">
                          No review selected
                        </Label>
                      </div>
                      {reviews.map((review) => (
                        <div key={review.id} className="flex items-center space-x-2">
                          <input
                            type="radio"
                            id={review.id}
                            name="review"
                            checked={formData.attached_reviews === review.id}
                            onChange={() => handleReviewSelect(review.id)}
                          />
                          <Label htmlFor={review.id} className="text-sm">
                            {review.id} - {review.name}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div>
                    <Label>Team Members</Label>
                    <Select onValueChange={addPerson}>
                      <SelectTrigger className="mt-1">
                        <SelectValue placeholder="Add team member" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="John Smith">John Smith</SelectItem>
                        <SelectItem value="Sarah Johnson">Sarah Johnson</SelectItem>
                        <SelectItem value="Michael Brown">Michael Brown</SelectItem>
                        <SelectItem value="Emily Davis">Emily Davis</SelectItem>
                        <SelectItem value="David Wilson">David Wilson</SelectItem>
                      </SelectContent>
                    </Select>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {formData.persons_concerned.map((person) => (
                        <Badge key={person} variant="secondary" className="flex items-center gap-1">
                          {person}
                          <button onClick={() => removePerson(person)} className="ml-1 text-xs hover:text-red-500">
                            ×
                          </button>
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
                <DialogFooter>
                  <Button
                    variant="outline"
                    onClick={() => {
                      setIsCreateOpen(false)
                      resetForm()
                    }}
                  >
                    Cancel
                  </Button>
                  <Button onClick={handleCreate} disabled={isSubmitting}>
                    {isSubmitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                    Create
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Search */}
        <div className="mb-6">
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Search plans..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        {/* Table */}
        <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
          <div className="min-w-full">
            <table className="w-full table-fixed">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="w-12 px-4 py-3 text-left">
                    <Checkbox
                      checked={selectedItems.length === filteredPlans.length && filteredPlans.length > 0}
                      onCheckedChange={handleSelectAll}
                    />
                  </th>
                  <th className="w-32 px-4 py-3 text-left text-sm font-medium text-gray-900">ID</th>
                  <th className="w-48 px-4 py-3 text-left text-sm font-medium text-gray-900">Name</th>
                  <th className="w-32 px-4 py-3 text-left text-sm font-medium text-gray-900">Status</th>
                  <th className="w-32 px-4 py-3 text-left text-sm font-medium text-gray-900">Review</th>
                  <th className="w-24 px-4 py-3 text-left text-sm font-medium text-gray-900">Man Days</th>
                  <th className="w-32 px-4 py-3 text-left text-sm font-medium text-gray-900">Team</th>
                  <th className="w-32 px-4 py-3 text-center text-sm font-medium text-gray-900">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {filteredPlans.map((plan) => {
                  const leafTaskCounts = getLeafTaskCounts(plan)
                  const progressPercentage =
                    leafTaskCounts.total > 0 ? Math.round((leafTaskCounts.completed / leafTaskCounts.total) * 100) : 0

                  return (
                    <tr key={plan.id} className="hover:bg-gray-50 transition-colors">
                      <td className="px-4 py-4">
                        <Checkbox
                          checked={selectedItems.includes(plan.id)}
                          onCheckedChange={(checked) => handleSelectItem(plan.id, checked as boolean)}
                        />
                      </td>
                      <td className="px-4 py-4">
                        <div className="flex items-center space-x-2">
                          <div className="bg-green-100 rounded p-1">
                            <Users className="h-3 w-3 text-green-600" />
                          </div>
                          <span className="text-sm font-mono text-gray-900 truncate">{plan.id}</span>
                        </div>
                      </td>
                      <td className="px-4 py-4">
                        <div>
                          <span className="text-sm font-medium text-gray-900 block truncate">{plan.name}</span>
                          <p className="text-xs text-gray-500 mt-1 truncate">{plan.description}</p>
                        </div>
                      </td>
                      <td className="px-4 py-4">
                        <Badge className={getStatusColor(plan.validation_status)}>{plan.validation_status}</Badge>
                      </td>
                      <td className="px-4 py-4">
                        {plan.attached_reviews ? (
                          <div className="flex items-center space-x-2">
                            <div className="bg-blue-100 rounded p-1">
                              <Users className="h-3 w-3 text-blue-600" />
                            </div>
                            <span className="text-sm font-mono text-gray-900">{plan.attached_reviews}</span>
                          </div>
                        ) : (
                          <span className="text-xs text-gray-400">No review</span>
                        )}
                      </td>
                      <td className="px-4 py-4">
                        <div className="flex items-center space-x-1 text-sm text-gray-600">
                          <Calendar className="h-3 w-3 flex-shrink-0" />
                          <span className="truncate">{plan.man_days || 0}</span>
                        </div>
                      </td>
                      <td className="px-4 py-4">
                        <div className="flex -space-x-1">
                          {plan.persons_concerned.slice(0, 2).map((person, index) => (
                            <div
                              key={person}
                              className="w-6 h-6 rounded-full bg-blue-100 border-2 border-white flex items-center justify-center flex-shrink-0"
                              title={person}
                            >
                              <span className="text-xs font-medium text-blue-600">
                                {person
                                  .split(" ")
                                  .map((n) => n[0])
                                  .join("")}
                              </span>
                            </div>
                          ))}
                          {plan.persons_concerned.length > 2 && (
                            <div className="w-6 h-6 rounded-full bg-gray-100 border-2 border-white flex items-center justify-center flex-shrink-0">
                              <span className="text-xs font-medium text-gray-600">
                                +{plan.persons_concerned.length - 2}
                              </span>
                            </div>
                          )}
                        </div>
                      </td>
                      <td className="px-4 py-4">
                        <div className="flex items-center justify-center space-x-1">
                          <Link href={`/plans/${plan.id}`}>
                            <Button size="sm" variant="outline" className="text-xs px-2">
                              Tasks
                            </Button>
                          </Link>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => handleEdit(plan)}>
                                <Edit className="h-4 w-4 mr-2" />
                                Edit
                              </DropdownMenuItem>
                              {plan.validation_status === "In Construction" && (
                                <DropdownMenuItem onClick={() => handleStatusChange(plan.id, "Validated")}>
                                  <CheckCircle className="h-4 w-4 mr-2" />
                                  Validate
                                </DropdownMenuItem>
                              )}
                              <DropdownMenuItem onClick={() => handleDelete(plan.id)} className="text-red-600">
                                <Trash2 className="h-4 w-4 mr-2" />
                                Delete
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </div>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>

          {filteredPlans.length === 0 && (
            <div className="text-center py-12">
              <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No plans found</h3>
              <p className="text-gray-600 mb-4">
                {searchTerm ? "Try a different search term" : "Create your first plan to get started"}
              </p>
              {!searchTerm && (
                <Button onClick={() => setIsCreateOpen(true)} className="bg-green-600 hover:bg-green-700">
                  <Plus className="h-4 w-4 mr-2" />
                  New Plan
                </Button>
              )}
            </div>
          )}
        </div>

        {/* Edit Dialog */}
        <Dialog open={!!editingPlan} onOpenChange={() => setEditingPlan(null)}>
          <DialogContent className="max-w-lg max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Edit Plan</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div>
                <Label htmlFor="edit-name">Plan Name</Label>
                <Input
                  id="edit-name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="edit-description">Description</Label>
                <Textarea
                  id="edit-description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="mt-1"
                  rows={3}
                />
              </div>
              <div>
                <Label htmlFor="edit-man-days">Man Days</Label>
                <Input
                  id="edit-man-days"
                  type="number"
                  min="0"
                  value={formData.man_days}
                  onChange={(e) => setFormData({ ...formData, man_days: Number.parseInt(e.target.value) || 0 })}
                  className="mt-1"
                />
              </div>
              <div>
                <Label>Review</Label>
                <div className="mt-2 max-h-32 overflow-y-auto border rounded p-3 space-y-2">
                  <div className="flex items-center space-x-2">
                    <input
                      type="radio"
                      id="no-review"
                      name="review"
                      checked={formData.attached_reviews === null}
                      onChange={() => setFormData({ ...formData, attached_reviews: null })}
                    />
                    <Label htmlFor="no-review" className="text-sm">
                      No review selected
                    </Label>
                  </div>
                  {reviews.map((review) => (
                    <div key={review.id} className="flex items-center space-x-2">
                      <input
                        type="radio"
                        id={review.id}
                        name="review"
                        checked={formData.attached_reviews === review.id}
                        onChange={() => handleReviewSelect(review.id)}
                      />
                      <Label htmlFor={review.id} className="text-sm">
                        {review.id} - {review.name}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <Label>Team Members</Label>
                <Select onValueChange={addPerson}>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Add team member" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="John Smith">John Smith</SelectItem>
                    <SelectItem value="Sarah Johnson">Sarah Johnson</SelectItem>
                    <SelectItem value="Michael Brown">Michael Brown</SelectItem>
                    <SelectItem value="Emily Davis">Emily Davis</SelectItem>
                    <SelectItem value="David Wilson">David Wilson</SelectItem>
                  </SelectContent>
                </Select>
                <div className="flex flex-wrap gap-2 mt-2">
                  {formData.persons_concerned.map((person) => (
                    <Badge key={person} variant="secondary" className="flex items-center gap-1">
                      {person}
                      <button onClick={() => removePerson(person)} className="ml-1 text-xs hover:text-red-500">
                        ×
                      </button>
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setEditingPlan(null)}>
                Cancel
              </Button>
              <Button onClick={handleUpdate} disabled={isSubmitting}>
                {isSubmitting && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
                Save
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  )
}
