"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Users, Calendar, CheckCircle } from "lucide-react"
import Link from "next/link"
import { usePlans } from "@/hooks/use-plans"
import { useReviews } from "@/hooks/use-reviews"
import { useToast } from "@/hooks/use-toast"
import { PageLayout } from "@/components/common/page-layout"
import { DataTable } from "@/components/common/data-table"
import { FormDialog } from "@/components/common/form-dialog"
import { PlanForm } from "@/components/plans/plan-form"
import type { ReviewPlan } from "@/lib/types"

export default function PlansPage() {
  const { plans, loading, error, createPlan, updatePlan, deletePlan, deleteMultiplePlans, updatePlanStatus } =
    usePlans()
  const { reviews } = useReviews()
  const { toast } = useToast()

  const [selectedItems, setSelectedItems] = useState<string[]>([])
  const [isCreateOpen, setIsCreateOpen] = useState(false)
  const [editingPlan, setEditingPlan] = useState<ReviewPlan | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleFormSubmit = async (formData: {
    name: string
    description: string
    attached_reviews: string
    man_days: number
  }) => {
    if (!formData.name.trim() || !formData.attached_reviews) {
      toast({
        title: "Validation Error",
        description: "Please enter a plan name and select a review",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)
    const result = editingPlan ? await updatePlan(editingPlan.id, formData) : await createPlan(formData)

    if (result.success) {
      toast({ title: "Success", description: `Plan ${editingPlan ? "updated" : "created"} successfully` })
      setIsCreateOpen(false)
      setEditingPlan(null)
    } else {
      toast({ title: "Error", description: result.error || "Operation failed", variant: "destructive" })
    }
    setIsSubmitting(false)
  }

  const handleDelete = async (id: string) => {
    const result = await deletePlan(id)
    if (result.success) {
      toast({ title: "Success", description: "Plan deleted successfully" })
      setSelectedItems((prev) => prev.filter((item) => item !== id))
    } else {
      toast({ title: "Error", description: result.error || "Failed to delete plan", variant: "destructive" })
    }
  }

  const handleBulkDelete = async () => {
    const result = await deleteMultiplePlans(selectedItems)
    if (result.success) {
      toast({ title: "Success", description: `${result.deletedCount} plans deleted successfully` })
      setSelectedItems([])
    } else {
      toast({ title: "Error", description: result.error || "Failed to delete plans", variant: "destructive" })
    }
  }

  const handleStatusChange = async (id: string, newStatus: ReviewPlan["validation_status"]) => {
    const result = await updatePlanStatus(id, newStatus)
    if (result.success) {
      toast({ title: "Success", description: `Plan status updated to ${newStatus}` })
    } else {
      toast({ title: "Error", description: result.error || "Failed to update plan status", variant: "destructive" })
    }
  }

  const getStatusColor = (status: string) => {
    return status === "Validated" ? "bg-green-100 text-green-700" : "bg-orange-100 text-orange-700"
  }

  const columns = [
    {
      key: "id",
      header: "ID",
      render: (plan: ReviewPlan) => (
        <div className="flex items-center space-x-2">
          <div className="bg-green-100 rounded p-1">
            <Users className="h-3 w-3 text-green-600" />
          </div>
          <span className="text-sm font-mono text-gray-900">{plan.id}</span>
        </div>
      ),
    },
    {
      key: "name",
      header: "Name",
      render: (plan: ReviewPlan) => (
        <div>
          <span className="text-sm font-medium text-gray-900">{plan.name}</span>
          <p className="text-xs text-gray-500 mt-1">{plan.description}</p>
        </div>
      ),
    },
    {
      key: "validation_status",
      header: "Status",
      render: (plan: ReviewPlan) => (
        <Badge className={getStatusColor(plan.validation_status)}>{plan.validation_status}</Badge>
      ),
    },
    {
      key: "attached_reviews",
      header: "Review",
      render: (plan: ReviewPlan) =>
        plan.attached_reviews ? (
          <div className="flex items-center space-x-2">
            <div className="bg-blue-100 rounded p-1">
              <Users className="h-3 w-3 text-blue-600" />
            </div>
            <span className="text-sm font-mono text-gray-900">{plan.attached_reviews}</span>
          </div>
        ) : (
          <span className="text-xs text-gray-400">No review</span>
        ),
    },
    {
      key: "man_days",
      header: "Man Days",
      render: (plan: ReviewPlan) => (
        <div className="flex items-center space-x-1 text-sm text-gray-600">
          <Calendar className="h-3 w-3" />
          <span>{plan.man_days || 0}</span>
        </div>
      ),
    },
  ]

  const planActions = (plan: ReviewPlan) => (
    <div className="flex items-center space-x-1">
      <Link href={`/plans/${plan.id}`}>
        <Button size="sm" variant="outline" className="text-xs px-2 bg-transparent">
          Tasks
        </Button>
      </Link>
      {plan.validation_status === "In Construction" && (
        <Button
          size="sm"
          variant="ghost"
          onClick={() => handleStatusChange(plan.id, "Validated")}
          className="text-xs px-2"
        >
          <CheckCircle className="h-3 w-3" />
        </Button>
      )}
    </div>
  )

  const planForm = PlanForm({ plan: editingPlan, reviews, onSubmit: handleFormSubmit })

  return (
    <PageLayout
      title="Plans"
      data={plans}
      loading={loading}
      error={error}
      selectedItems={selectedItems}
      onSelectAll={(checked) => setSelectedItems(checked ? plans.map((p) => p.id) : [])}
      onSelectItem={(id, checked) =>
        setSelectedItems((prev) => (checked ? [...prev, id] : prev.filter((item) => item !== id)))
      }
      onBulkDelete={handleBulkDelete}
      onCreate={() => setIsCreateOpen(true)}
      createButtonText="New Plan"
      emptyIcon={<Users className="h-12 w-12 text-gray-400" />}
      emptyTitle="No plans found"
      emptyDescription="Create your first plan to get started"
      searchPlaceholder="Search plans..."
    >
      <DataTable
        data={plans}
        columns={columns}
        selectedItems={selectedItems}
        onSelectAll={(checked) => setSelectedItems(checked ? plans.map((p) => p.id) : [])}
        onSelectItem={(id, checked) =>
          setSelectedItems((prev) => (checked ? [...prev, id] : prev.filter((item) => item !== id)))
        }
        onEdit={setEditingPlan}
        onDelete={handleDelete}
        actions={planActions}
      />

      <FormDialog
        open={isCreateOpen || !!editingPlan}
        onOpenChange={(open) => {
          setIsCreateOpen(open)
          if (!open) setEditingPlan(null)
        }}
        title={editingPlan ? "Edit Plan" : "New Plan"}
        onSubmit={planForm.handleSubmit}
        onCancel={() => {
          setIsCreateOpen(false)
          setEditingPlan(null)
        }}
        isLoading={isSubmitting}
        isValid={planForm.isValid}
        submitLabel={editingPlan ? "Save" : "Create"}
      >
        {planForm.form}
      </FormDialog>
    </PageLayout>
  )
}
