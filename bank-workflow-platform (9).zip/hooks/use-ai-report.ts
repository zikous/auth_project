"use client"

import { useState } from "react"
import type { Task, ReviewPlan, AIReport, TaskAggregation } from "@/lib/types"

export function useAIReport(
  task: Task | null,
  plan: ReviewPlan | null,
  aggregation: TaskAggregation | null,
  getTaskCompletionPercentage: (taskId: string) => number,
) {
  const [isGenerating, setIsGenerating] = useState(false)
  const [customPrompt, setCustomPrompt] = useState("")
  const [isEditingPrompt, setIsEditingPrompt] = useState(false)

  // Safe property access with comprehensive fallbacks
  const safeTask = {
    id: task?.id || "Unknown",
    name: task?.name || "Unknown Task",
    description: task?.description || "No description available",
    assigned_to: task?.assigned_to || "Unassigned",
    completed: task?.completed || false,
    days_required: task?.days_required || 0,
    difficulty: task?.difficulty || "Medium",
    discussions: Array.isArray(task?.discussions) ? task.discussions : [],
    conclusions: Array.isArray(task?.conclusions) ? task.conclusions : [],
  }

  const safePlan = {
    name: plan?.name || "Unknown Plan",
    validation_status: plan?.validation_status || "Unknown",
  }

  const safeAggregation = aggregation
    ? {
        childTasks: Array.isArray(aggregation.childTasks) ? aggregation.childTasks : [],
        discussions: Array.isArray(aggregation.discussions) ? aggregation.discussions : [],
        conclusions: Array.isArray(aggregation.conclusions) ? aggregation.conclusions : [],
        totalDiscussions: aggregation.totalDiscussions || 0,
        totalConclusions: aggregation.totalConclusions || 0,
      }
    : {
        childTasks: [],
        discussions: [],
        conclusions: [],
        totalDiscussions: 0,
        totalConclusions: 0,
      }

  const isParentTask = safeAggregation.childTasks.length > 0
  const completionPercentage = isParentTask ? getTaskCompletionPercentage(safeTask.id) : 0

  const defaultPrompt = `Analyze the following task and generate a comprehensive report:

**Task Information:**
- Task ID: ${safeTask.id}
- Task Name: ${safeTask.name}
- Description: ${safeTask.description}
- Assigned to: ${safeTask.assigned_to}
- Status: ${safeTask.completed ? "Completed" : "In Progress"}
- Days Required: ${safeTask.days_required}
- Difficulty Level: ${safeTask.difficulty}
- Plan Context: ${safePlan.name} (Status: ${safePlan.validation_status})
- Task Type: ${isParentTask ? `Parent Task (${completionPercentage}% complete)` : "Leaf Task"}

${
  isParentTask
    ? `
**Parent Task Completion:**
- Overall Progress: ${completionPercentage}%
- Child Tasks Completed: ${safeAggregation.childTasks.filter((c) => c.completed).length}/${safeAggregation.childTasks.length}

**Child Tasks (${safeAggregation.childTasks.length} total):**
${safeAggregation.childTasks.map((child) => `- ${child.id}: ${child.name} (${child.completed ? "Completed" : "In Progress"}, ${child.difficulty})`).join("\n")}
`
    : ""
}

**Discussion Points (${safeAggregation.discussions.length} total${isParentTask ? " - aggregated from all child tasks" : ""}):**
${
  safeAggregation.discussions.length > 0
    ? safeAggregation.discussions
        .map(
          (d) =>
            `- ${d.author || "Unknown"} (${new Date(d.timestamp || Date.now()).toLocaleDateString()}): ${d.message || "No message"}${isParentTask ? ` [from ${d.task_id || "unknown"}]` : ""}`,
        )
        .join("\n")
    : "- No discussions recorded yet"
}

**Conclusions (${safeAggregation.conclusions.length} versions${isParentTask ? " - aggregated from all child tasks" : ""}):**
${
  safeAggregation.conclusions.length > 0
    ? safeAggregation.conclusions
        .map(
          (c) =>
            `- v${c.version || 1} by ${c.author || "Unknown"} (${new Date(c.timestamp || Date.now()).toLocaleDateString()}): ${c.message || "No message"}${isParentTask ? ` [from ${c.task_id || "unknown"}]` : ""}`,
        )
        .join("\n")
    : "- No conclusions documented yet"
}

Please provide:
1. Executive Summary
2. ${isParentTask ? `Parent Task Analysis (${completionPercentage}% Complete)` : "Task Analysis"}
3. Plan Status Impact (Current: ${safePlan.validation_status})
4. Discussion Analysis
5. Completed Actions
6. Key Conclusions
7. Risk Assessment (considering difficulty level: ${safeTask.difficulty})
8. Next Steps and Recommendations
9. Compliance Notes (if applicable)

${
  isParentTask
    ? `Note: This is a parent task report with ${completionPercentage}% completion rate. Provide insights on overall progress, coordination effectiveness, and child task management.`
    : "Note: This is a leaf task report focusing on specific task execution."
}

Format the response as a professional banking report with clear sections and actionable insights.`

  const currentPrompt = isEditingPrompt && customPrompt ? customPrompt : defaultPrompt

  const generateReport = (prompt: string): AIReport => {
    // Use aggregation data if available, otherwise use task data
    const discussions = safeAggregation.discussions.length > 0 ? safeAggregation.discussions : safeTask.discussions
    const conclusions = safeAggregation.conclusions.length > 0 ? safeAggregation.conclusions : safeTask.conclusions

    const discussionCount = discussions.length
    const conclusionCount = conclusions.length
    const completionRate = safeTask.completed ? 100 : Math.floor(Math.random() * 80) + 20

    const difficultyRisk =
      {
        Easy: "Low",
        Medium: "Medium",
        Hard: "High",
      }[safeTask.difficulty] || "Medium"

    const content = `# AI-Generated Task Analysis Report

**Generated on:** ${new Date().toLocaleString()}  
**Task:** ${safeTask.name} (${safeTask.id})  
**Review Plan:** ${safePlan.name} (Status: ${safePlan.validation_status})  
**Status:** ${safeTask.completed ? "✅ Completed" : "🔄 In Progress"}  
**Difficulty:** ${safeTask.difficulty}  
**Task Type:** ${isParentTask ? "🔗 Parent Task (Aggregated)" : "📋 Leaf Task"}

---

## 1. Executive Summary

This report analyzes ${isParentTask ? "parent task" : "task"} "${safeTask.name}" within the context of the "${safePlan.name}" review plan (Status: ${safePlan.validation_status}). ${
      isParentTask
        ? `This parent task coordinates ${safeAggregation.childTasks.length} child tasks and aggregates ${discussionCount} discussions and ${conclusionCount} conclusions from the entire task hierarchy.`
        : `The task is currently ${safeTask.completed ? "completed" : "in progress"} with ${discussionCount} discussion points and ${conclusionCount} documented conclusions.`
    }

**Key Metrics:**
- Completion Rate: ${completionRate}%
- Difficulty Level: ${safeTask.difficulty} (${difficultyRisk} Risk)
- Team Engagement: ${discussionCount > 3 ? "High" : discussionCount > 1 ? "Medium" : "Low"}
- Documentation Quality: ${conclusionCount > 0 ? "Good" : "Needs Improvement"}
- Plan Status Context: ${safePlan.validation_status}
${isParentTask ? `- Child Task Coordination: ${safeAggregation.childTasks.filter((c) => c.completed).length}/${safeAggregation.childTasks.length} child tasks completed (${completionPercentage}%)` : ""}

## 2. Task Analysis

**Current Status:** ${safeTask.completed ? "Task has been completed successfully" : "Task is currently in progress"}

**Scope & Complexity:**
- Estimated effort: ${safeTask.days_required} days
- Difficulty assessment: ${safeTask.difficulty}
- Risk level: ${difficultyRisk}

**Progress Indicators:**
${
  isParentTask
    ? `- Overall completion: ${completionPercentage}%
- Child tasks managed: ${safeAggregation.childTasks.length}
- Coordination effectiveness: ${completionPercentage > 75 ? "Excellent" : completionPercentage > 50 ? "Good" : "Needs attention"}`
    : `- Task completion: ${safeTask.completed ? "100%" : "In progress"}
- Documentation level: ${discussionCount + conclusionCount > 3 ? "Comprehensive" : "Basic"}`
}

## 3. Communication Analysis

**Discussion Activity:** ${discussionCount} recorded discussions
${
  discussionCount > 0
    ? `- Latest activity: ${discussions[0]?.timestamp ? new Date(discussions[0].timestamp).toLocaleDateString() : "Unknown"}
- Engagement level: ${discussionCount > 5 ? "Very Active" : discussionCount > 2 ? "Active" : "Limited"}
- Key themes: Progress updates, issue resolution, coordination`
    : "- No discussions recorded yet - consider initiating team communication"
}

**Decision Documentation:** ${conclusionCount} conclusions documented
${
  conclusionCount > 0
    ? `- Decision quality: ${conclusionCount > 3 ? "Comprehensive" : "Adequate"}
- Latest conclusion: ${conclusions[conclusions.length - 1]?.timestamp ? new Date(conclusions[conclusions.length - 1].timestamp).toLocaleDateString() : "Unknown"}
- Documentation trend: ${conclusionCount > discussionCount ? "Good closure rate" : "More discussions than conclusions"}`
    : "- No formal conclusions documented - ensure decisions are captured"
}

## 4. Risk Assessment

**Overall Risk Level:** ${difficultyRisk}

**Risk Factors:**
- Technical complexity: ${safeTask.difficulty}
- Resource allocation: ${safeTask.days_required > 5 ? "High resource requirement" : "Standard allocation"}
- Communication gaps: ${discussionCount < 2 ? "Limited team interaction" : "Adequate communication"}
- Documentation risks: ${conclusionCount === 0 ? "No decision records" : "Documented decisions available"}

## 5. Recommendations

**Immediate Actions:**
${
  safeTask.completed
    ? "- Archive task documentation\n- Share lessons learned\n- Update project metrics"
    : `- ${discussionCount === 0 ? "Initiate team discussions" : "Continue regular check-ins"}
- ${conclusionCount === 0 ? "Document key decisions" : "Maintain decision log"}
- Monitor progress against ${safeTask.days_required}-day timeline`
}

**Process Improvements:**
- ${discussionCount < conclusionCount ? "Increase team collaboration" : "Maintain communication rhythm"}
- ${conclusionCount === 0 ? "Implement decision documentation process" : "Continue structured decision making"}
- Regular progress reviews for ${safeTask.difficulty.toLowerCase()} difficulty tasks

## 6. Compliance & Quality

**Plan Alignment:** Task supports "${safePlan.name}" objectives
**Status Consistency:** ${safePlan.validation_status === "Validated" ? "Aligned with validated plan" : "Part of plan under construction"}
**Quality Indicators:** ${discussionCount + conclusionCount > 5 ? "High" : discussionCount + conclusionCount > 2 ? "Medium" : "Basic"} documentation quality

---

*Report generated by AI Analysis System - ${new Date().toLocaleString()}*`

    return {
      id: `RPT-${Date.now()}`,
      task_id: safeTask.id,
      content,
      prompt: {
        id: `PRM-${Date.now()}`,
        content: prompt,
        timestamp: new Date().toISOString(),
        author: "System",
        isDefault: !isEditingPrompt,
      },
      generated_at: new Date().toISOString(),
      metadata: {
        discussion_count: discussionCount,
        conclusion_count: conclusionCount,
        completion_rate: completionRate,
        confidence_level: discussionCount > 2 && conclusionCount > 0 ? "High" : "Medium",
        aggregated_from_children: isParentTask,
      },
    }
  }

  const handleGenerateReport = async () => {
    setIsGenerating(true)
    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, 2000))
    setIsGenerating(false)
  }

  const handleEditPrompt = (editing: boolean) => {
    setIsEditingPrompt(editing)
    if (editing && !customPrompt) {
      setCustomPrompt(defaultPrompt)
    }
  }

  const handleSavePrompt = () => {
    setIsEditingPrompt(false)
  }

  const handleCancelPrompt = () => {
    setIsEditingPrompt(false)
    setCustomPrompt("")
  }

  return {
    currentPrompt,
    customPrompt,
    setCustomPrompt,
    isEditingPrompt,
    isGenerating,
    generateReport,
    handleGenerateReport,
    handleEditPrompt,
    handleSavePrompt,
    handleCancelPrompt,
  }
}
