"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"
import { PageHeader } from "./page-header"
import { SearchBar } from "./search-bar"
import { LoadingState } from "./loading-state"
import { ErrorState } from "./error-state"
import { EmptyState } from "./empty-state"
import { BulkActions } from "./bulk-actions"
import type { ReactNode } from "react"

interface PageLayoutProps<T extends { id: string; name: string }> {
  title: string
  data: T[]
  loading: boolean
  error: string | null
  selectedItems: string[]
  onSelectAll: (checked: boolean) => void
  onSelectItem: (id: string, checked: boolean) => void
  onBulkDelete: () => void
  onCreate: () => void
  createButtonText: string
  emptyIcon: ReactNode
  emptyTitle: string
  emptyDescription: string
  children: ReactNode
  searchPlaceholder?: string
}

export function PageLayout<T extends { id: string; name: string }>({
  title,
  data,
  loading,
  error,
  selectedItems,
  onSelectAll,
  onSelectItem,
  onBulkDelete,
  onCreate,
  createButtonText,
  emptyIcon,
  emptyTitle,
  emptyDescription,
  children,
  searchPlaceholder = "Search...",
}: PageLayoutProps<T>) {
  const [searchTerm, setSearchTerm] = useState("")

  const filteredData = data.filter(
    (item) =>
      item.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.id.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  if (loading) return <LoadingState message={`Loading ${title.toLowerCase()}...`} />
  if (error) return <ErrorState title={`Error Loading ${title}`} message={error} />

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto p-6">
        <PageHeader title={title} subtitle={`${data.length} total ${title.toLowerCase()}`}>
          <BulkActions selectedCount={selectedItems.length} onDelete={onBulkDelete} />
          <Button onClick={onCreate} className="bg-blue-600 hover:bg-blue-700">
            <Plus className="h-4 w-4 mr-2" />
            {createButtonText}
          </Button>
        </PageHeader>

        <div className="mb-6">
          <SearchBar value={searchTerm} onChange={setSearchTerm} placeholder={searchPlaceholder} />
        </div>

        {filteredData.length === 0 ? (
          <EmptyState
            icon={emptyIcon}
            title={emptyTitle}
            description={searchTerm ? "Try a different search term" : emptyDescription}
            action={
              !searchTerm ? (
                <Button onClick={onCreate} className="bg-blue-600 hover:bg-blue-700">
                  <Plus className="h-4 w-4 mr-2" />
                  {createButtonText}
                </Button>
              ) : undefined
            }
          />
        ) : (
          children
        )}
      </div>
    </div>
  )
}
