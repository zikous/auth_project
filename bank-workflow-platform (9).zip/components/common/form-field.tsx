"use client"

import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { FormikProps } from "formik"

interface BaseFieldProps {
  name: string
  label: string
  required?: boolean
  className?: string
}

interface InputFieldProps extends BaseFieldProps {
  type?: "text" | "number" | "email"
  placeholder?: string
  formik: FormikProps<any>
}

interface TextareaFieldProps extends BaseFieldProps {
  placeholder?: string
  rows?: number
  formik: FormikProps<any>
}

interface SelectFieldProps extends BaseFieldProps {
  placeholder?: string
  options: { value: string; label: string; disabled?: boolean }[]
  formik: FormikProps<any>
}

export function InputField({ name, label, type = "text", placeholder, required, className, formik }: InputFieldProps) {
  const hasError = formik.touched[name] && formik.errors[name]

  return (
    <div className={className}>
      <Label htmlFor={name}>
        {label} {required && "*"}
      </Label>
      <Input
        id={name}
        name={name}
        type={type}
        placeholder={placeholder}
        value={formik.values[name] || ""}
        onChange={formik.handleChange}
        onBlur={formik.handleBlur}
        className={`mt-1 ${hasError ? "border-red-500" : ""}`}
      />
      {hasError && <p className="text-sm text-red-500 mt-1">{formik.errors[name] as string}</p>}
    </div>
  )
}

export function TextareaField({ name, label, placeholder, rows = 3, required, className, formik }: TextareaFieldProps) {
  const hasError = formik.touched[name] && formik.errors[name]

  return (
    <div className={className}>
      <Label htmlFor={name}>
        {label} {required && "*"}
      </Label>
      <Textarea
        id={name}
        name={name}
        placeholder={placeholder}
        rows={rows}
        value={formik.values[name] || ""}
        onChange={formik.handleChange}
        onBlur={formik.handleBlur}
        className={`mt-1 ${hasError ? "border-red-500" : ""}`}
      />
      {hasError && <p className="text-sm text-red-500 mt-1">{formik.errors[name] as string}</p>}
    </div>
  )
}

export function SelectField({ name, label, placeholder, options, required, className, formik }: SelectFieldProps) {
  const hasError = formik.touched[name] && formik.errors[name]

  return (
    <div className={className}>
      <Label htmlFor={name}>
        {label} {required && "*"}
      </Label>
      <Select
        value={formik.values[name] || ""}
        onValueChange={(value) => formik.setFieldValue(name, value)}
        onOpenChange={() => formik.setFieldTouched(name, true)}
      >
        <SelectTrigger className={`mt-1 ${hasError ? "border-red-500" : ""}`}>
          <SelectValue placeholder={placeholder} />
        </SelectTrigger>
        <SelectContent>
          {options.map((option) => (
            <SelectItem key={option.value} value={option.value || "none"} disabled={option.disabled}>
              {option.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
      {hasError && <p className="text-sm text-red-500 mt-1">{formik.errors[name] as string}</p>}
    </div>
  )
}
