"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Folder, FileText, Plus, X } from "lucide-react"
import type { ReviewPlan } from "@/lib/types"

interface SimpleTaskCreatorProps {
  plan: ReviewPlan
  onCreateTask: (taskData: any) => Promise<any>
  onClose: () => void
  isLoading: boolean
}

export function SimpleTaskCreator({ plan, onCreateTask, onClose, isLoading }: SimpleTaskCreatorProps) {
  const [taskType, setTaskType] = useState<"folder" | "task" | null>(null)
  const [name, setName] = useState("")
  const [description, setDescription] = useState("")
  const [parentId, setParentId] = useState<string | null>(null)
  const [assignedTo, setAssignedTo] = useState("")

  // Get available folders for placement
  const getFolders = () => {
    const folders = plan.tasks.filter((task) => task.is_folder || plan.tasks.some((t) => t.parent_id === task.id))
    return [
      { id: null, name: "Root Level", path: "📁 Root Level" },
      ...folders.map((folder) => ({
        id: folder.id,
        name: folder.name,
        path: `📁 ${folder.name}`,
      })),
    ]
  }

  const handleCreate = async () => {
    if (!name.trim() || !taskType) return

    const taskData = {
      name: name.trim(),
      description: description.trim(),
      parent_id: parentId,
      assigned_to: taskType === "task" ? assignedTo : "",
      responsible_person: taskType === "folder" ? assignedTo : "",
      days_required: taskType === "task" ? 1 : 0,
      difficulty: "Medium" as const,
      is_folder: taskType === "folder",
    }

    const result = await onCreateTask(taskData)
    if (result) {
      // Reset form
      setTaskType(null)
      setName("")
      setDescription("")
      setParentId(null)
      setAssignedTo("")
      onClose()
    }
  }

  const canCreate = name.trim() && taskType

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader className="text-center">
        <CardTitle className="text-xl">Add New Item</CardTitle>
        <p className="text-sm text-slate-600">Create a folder to organize work or a task to get things done</p>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Step 1: Choose Type */}
        {!taskType && (
          <div className="space-y-4">
            <Label className="text-base font-medium">What would you like to create?</Label>
            <div className="grid grid-cols-2 gap-4">
              <Button
                variant="outline"
                className="h-20 flex-col gap-2 hover:bg-blue-50 hover:border-blue-300"
                onClick={() => setTaskType("folder")}
              >
                <Folder className="h-6 w-6 text-blue-600" />
                <span className="font-medium">Folder</span>
                <span className="text-xs text-slate-500">Organize related work</span>
              </Button>
              <Button
                variant="outline"
                className="h-20 flex-col gap-2 hover:bg-green-50 hover:border-green-300"
                onClick={() => setTaskType("task")}
              >
                <FileText className="h-6 w-6 text-green-600" />
                <span className="font-medium">Task</span>
                <span className="text-xs text-slate-500">Specific work to do</span>
              </Button>
            </div>
          </div>
        )}

        {/* Step 2: Fill Details */}
        {taskType && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Badge
                  variant="outline"
                  className={taskType === "folder" ? "bg-blue-50 text-blue-700" : "bg-green-50 text-green-700"}
                >
                  {taskType === "folder" ? <Folder className="h-3 w-3 mr-1" /> : <FileText className="h-3 w-3 mr-1" />}
                  {taskType === "folder" ? "Folder" : "Task"}
                </Badge>
              </div>
              <Button variant="ghost" size="sm" onClick={() => setTaskType(null)}>
                Change Type
              </Button>
            </div>

            <div className="space-y-4">
              <div>
                <Label htmlFor="name" className="text-base font-medium">
                  {taskType === "folder" ? "Folder" : "Task"} Name *
                </Label>
                <Input
                  id="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder={taskType === "folder" ? "e.g., Risk Assessment" : "e.g., Create risk matrix"}
                  className="mt-1"
                />
              </div>

              <div>
                <Label htmlFor="location" className="text-base font-medium">
                  Where to place it?
                </Label>
                <Select
                  value={parentId || "root"}
                  onValueChange={(value) => setParentId(value === "root" ? null : value)}
                >
                  <SelectTrigger className="mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {getFolders().map((folder) => (
                      <SelectItem key={folder.id || "root"} value={folder.id || "root"}>
                        {folder.path}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="assignee" className="text-base font-medium">
                  {taskType === "folder" ? "Responsible Person" : "Assign To"}
                </Label>
                <Select value={assignedTo} onValueChange={setAssignedTo}>
                  <SelectTrigger className="mt-1">
                    <SelectValue placeholder="Select person (optional)" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="no-one-assigned">No one assigned</SelectItem>
                    {plan.persons_concerned?.map((person) => (
                      <SelectItem key={person} value={person}>
                        {person}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="description" className="text-base font-medium">
                  Description (optional)
                </Label>
                <Textarea
                  id="description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder={`Brief description of this ${taskType}`}
                  rows={3}
                  className="mt-1"
                />
              </div>
            </div>
          </div>
        )}

        {/* Actions */}
        <div className="flex justify-between items-center pt-4 border-t">
          <Button variant="outline" onClick={onClose}>
            <X className="h-4 w-4 mr-2" />
            Cancel
          </Button>

          {taskType && (
            <Button
              onClick={handleCreate}
              disabled={!canCreate || isLoading}
              className={taskType === "folder" ? "bg-blue-600 hover:bg-blue-700" : "bg-green-600 hover:bg-green-700"}
            >
              <Plus className="h-4 w-4 mr-2" />
              {isLoading ? "Creating..." : `Create ${taskType === "folder" ? "Folder" : "Task"}`}
            </Button>
          )}
        </div>

        {/* Quick Tips */}
        <div className="bg-slate-50 p-3 rounded-lg text-sm text-slate-600">
          <p className="font-medium mb-1">💡 Quick Tips:</p>
          <ul className="space-y-1 text-xs">
            <li>• Create folders first to organize your work</li>
            <li>• Tasks go inside folders for better organization</li>
            <li>• You can always edit details later</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  )
}
