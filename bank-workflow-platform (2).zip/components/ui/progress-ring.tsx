"use client"

import { cn } from "@/lib/utils"

interface ProgressRingProps {
  progress: number
  size?: "sm" | "md" | "lg"
  className?: string
  showText?: boolean
}

export function ProgressRing({ progress, size = "md", className, showText = true }: ProgressRingProps) {
  const sizes = {
    sm: { width: 32, height: 32, strokeWidth: 3, fontSize: "text-xs" },
    md: { width: 48, height: 48, strokeWidth: 4, fontSize: "text-sm" },
    lg: { width: 64, height: 64, strokeWidth: 5, fontSize: "text-base" },
  }

  const { width, height, strokeWidth, fontSize } = sizes[size]
  const radius = (width - strokeWidth) / 2
  const circumference = radius * 2 * Math.PI
  const strokeDasharray = circumference
  const strokeDashoffset = circumference - (progress / 100) * circumference

  const getColor = (progress: number) => {
    if (progress >= 80) return "text-green-600"
    if (progress >= 50) return "text-blue-600"
    if (progress >= 25) return "text-amber-600"
    return "text-slate-400"
  }

  return (
    <div className={cn("relative inline-flex items-center justify-center", className)}>
      <svg width={width} height={height} className="transform -rotate-90">
        <circle
          cx={width / 2}
          cy={height / 2}
          r={radius}
          stroke="currentColor"
          strokeWidth={strokeWidth}
          fill="transparent"
          className="text-slate-200"
        />
        <circle
          cx={width / 2}
          cy={height / 2}
          r={radius}
          stroke="currentColor"
          strokeWidth={strokeWidth}
          fill="transparent"
          strokeDasharray={strokeDasharray}
          strokeDashoffset={strokeDashoffset}
          className={cn("transition-all duration-300", getColor(progress))}
          strokeLinecap="round"
        />
      </svg>
      {showText && (
        <div
          className={cn(
            "absolute inset-0 flex items-center justify-center font-semibold",
            fontSize,
            getColor(progress),
          )}
        >
          {Math.round(progress)}%
        </div>
      )}
    </div>
  )
}
