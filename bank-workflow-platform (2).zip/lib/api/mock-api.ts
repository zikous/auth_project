"use client"

import type { Task, Discussion, Conclusion, ReviewPlan, Review } from "@/lib/types"

// Simulate network delay
const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms))

// Generate unique IDs
const generateId = () => Math.random().toString(36).substr(2, 9).toUpperCase()

// Mock API responses
interface ApiResponse<T> {
  success: boolean
  data: T
  message?: string
  error?: string
}

// Mock data storage
const mockReviewsData: Review[] = [
  {
    id: "RVW-001",
    name: "Quarterly Risk Assessment",
    description: "Comprehensive review of operational risk factors and mitigation strategies for Q4 2024",
    status: "In Progress",
    created_at: "2024-01-01T00:00:00Z",
    updated_at: "2024-01-01T00:00:00Z",
  },
  {
    id: "RVW-002",
    name: "Compliance Documentation Review",
    description: "Annual review of regulatory compliance documentation and procedures",
    status: "Draft",
    created_at: "2024-01-02T00:00:00Z",
    updated_at: "2024-01-02T00:00:00Z",
  },
  {
    id: "RVW-003",
    name: "Customer Data Privacy Audit",
    description: "GDPR compliance audit focusing on customer data handling and privacy controls",
    status: "Completed",
    created_at: "2024-01-03T00:00:00Z",
    updated_at: "2024-01-03T00:00:00Z",
  },
  {
    id: "RVW-004",
    name: "Financial Controls Assessment",
    description: "Internal audit of financial controls and reporting mechanisms",
    status: "In Progress",
    created_at: "2024-01-04T00:00:00Z",
    updated_at: "2024-01-04T00:00:00Z",
  },
  {
    id: "RVW-005",
    name: "Cybersecurity Framework Review",
    description: "Evaluation of current cybersecurity measures and incident response procedures",
    status: "Draft",
    created_at: "2024-01-05T00:00:00Z",
    updated_at: "2024-01-05T00:00:00Z",
  },
  {
    id: "RVW-006",
    name: "Vendor Risk Management",
    description: "Assessment of third-party vendor relationships and associated risks",
    status: "Completed",
    created_at: "2024-01-06T00:00:00Z",
    updated_at: "2024-01-06T00:00:00Z",
  },
]

const mockPlansData: ReviewPlan[] = [
  {
    id: "PLN-001",
    name: "Q4 Compliance Review",
    description: "Comprehensive quarterly compliance review covering all regulatory requirements",
    attached_reviews: ["RVW-001", "RVW-002", "RVW-004"],
    persons_concerned: ["John Smith", "Sarah Johnson", "Michael Brown", "Emily Davis", "David Wilson"],
    validation_status: "In Construction",
    man_days: 45,
    tasks: [],
  },
  {
    id: "PLN-002",
    name: "Data Security Assessment",
    description: "Complete evaluation of data security measures and privacy compliance",
    attached_reviews: ["RVW-003", "RVW-005"],
    persons_concerned: ["Emily Davis", "David Wilson"],
    validation_status: "Validated",
    man_days: 30,
    tasks: [],
  },
  {
    id: "PLN-003",
    name: "Operational Risk Review",
    description: "Annual operational risk assessment and vendor management review",
    attached_reviews: ["RVW-001", "RVW-006"],
    persons_concerned: ["John Smith", "Emily Davis", "Sarah Johnson"],
    validation_status: "Finished",
    man_days: 25,
    tasks: [],
  },
]

class MockAPI {
  private async simulateRequest<T>(operation: () => T, delayMs = 300, errorRate = 0.05): Promise<ApiResponse<T>> {
    await delay(delayMs)

    // Simulate occasional errors
    if (Math.random() < errorRate) {
      throw new Error("Network error occurred")
    }

    try {
      const data = operation()
      return {
        success: true,
        data,
        message: "Operation completed successfully",
      }
    } catch (error) {
      return {
        success: false,
        data: null as any,
        error: error instanceof Error ? error.message : "Unknown error",
      }
    }
  }

  // Task operations
  tasks = {
    create: async (taskData: Partial<Task>): Promise<ApiResponse<Task>> => {
      return this.simulateRequest(() => {
        const newTask: Task = {
          id: `T-${generateId()}`,
          name: taskData.name || "",
          description: taskData.description || "",
          plan_id: taskData.plan_id || "",
          parent_id: taskData.parent_id || null,
          assigned_to: taskData.assigned_to || "",
          responsible_person: taskData.responsible_person || "",
          days_required: taskData.days_required || 0,
          difficulty: taskData.difficulty || "Medium",
          completed: false,
          discussions: [],
          conclusions: [],
          is_folder: taskData.is_folder || false,
        }
        return newTask
      }, 500)
    },

    update: async (taskId: string, updates: Partial<Task>): Promise<ApiResponse<Task>> => {
      return this.simulateRequest(() => {
        const updatedTask: Task = {
          id: taskId,
          name: updates.name || "",
          description: updates.description || "",
          plan_id: updates.plan_id || "",
          parent_id: updates.parent_id || null,
          assigned_to: updates.assigned_to || "",
          responsible_person: updates.responsible_person || "",
          days_required: updates.days_required || 0,
          difficulty: updates.difficulty || "Medium",
          completed: updates.completed || false,
          discussions: updates.discussions || [],
          conclusions: updates.conclusions || [],
          is_folder: updates.is_folder || false,
        }
        return updatedTask
      }, 400)
    },

    delete: async (taskId: string): Promise<ApiResponse<boolean>> => {
      return this.simulateRequest(() => {
        return true
      }, 300)
    },

    toggleCompletion: async (taskId: string): Promise<ApiResponse<Task>> => {
      return this.simulateRequest(() => {
        const updatedTask: Task = {
          id: taskId,
          name: "Updated Task",
          description: "Task description",
          plan_id: "",
          parent_id: null,
          assigned_to: "",
          responsible_person: "",
          days_required: 1,
          difficulty: "Medium",
          completed: true,
          discussions: [],
          conclusions: [],
          is_folder: false,
        }
        return updatedTask
      }, 200)
    },

    addDiscussion: async (taskId: string, message: string): Promise<ApiResponse<Discussion>> => {
      return this.simulateRequest(() => {
        const newDiscussion: Discussion = {
          id: `D-${generateId()}`,
          task_id: taskId,
          author: "Current User",
          message,
          timestamp: new Date().toISOString(),
        }
        return newDiscussion
      }, 250)
    },

    addConclusion: async (taskId: string, message: string): Promise<ApiResponse<Conclusion>> => {
      return this.simulateRequest(() => {
        const newConclusion: Conclusion = {
          id: `C-${generateId()}`,
          task_id: taskId,
          author: "Current User",
          message,
          timestamp: new Date().toISOString(),
          version: 1,
        }
        return newConclusion
      }, 300)
    },
  }

  // Plan operations
  plans = {
    getAll: async (): Promise<ApiResponse<ReviewPlan[]>> => {
      return this.simulateRequest(() => {
        return [...mockPlansData]
      }, 400)
    },

    getById: async (planId: string): Promise<ApiResponse<ReviewPlan>> => {
      return this.simulateRequest(() => {
        const plan = mockPlansData.find((p) => p.id === planId)
        if (!plan) {
          throw new Error("Plan not found")
        }
        return plan
      }, 300)
    },

    create: async (planData: Partial<ReviewPlan>): Promise<ApiResponse<ReviewPlan>> => {
      return this.simulateRequest(() => {
        const newPlan: ReviewPlan = {
          id: `PLN-${String(mockPlansData.length + 1).padStart(3, "0")}`,
          name: planData.name || "",
          description: planData.description || "",
          attached_reviews: planData.attached_reviews || [],
          persons_concerned: planData.persons_concerned || [],
          validation_status: "In Construction",
          man_days: planData.man_days || 0,
          tasks: [],
        }
        mockPlansData.push(newPlan)
        return newPlan
      }, 500)
    },

    update: async (planId: string, updates: Partial<ReviewPlan>): Promise<ApiResponse<ReviewPlan>> => {
      return this.simulateRequest(() => {
        const planIndex = mockPlansData.findIndex((p) => p.id === planId)
        if (planIndex === -1) {
          throw new Error("Plan not found")
        }

        const updatedPlan = { ...mockPlansData[planIndex], ...updates }
        mockPlansData[planIndex] = updatedPlan
        return updatedPlan
      }, 400)
    },

    delete: async (planId: string): Promise<ApiResponse<boolean>> => {
      return this.simulateRequest(() => {
        const planIndex = mockPlansData.findIndex((p) => p.id === planId)
        if (planIndex === -1) {
          throw new Error("Plan not found")
        }
        mockPlansData.splice(planIndex, 1)
        return true
      }, 300)
    },
  }

  // Review operations
  reviews = {
    getAll: async (): Promise<ApiResponse<Review[]>> => {
      return this.simulateRequest(() => {
        return [...mockReviewsData]
      }, 350)
    },

    getById: async (reviewId: string): Promise<ApiResponse<Review>> => {
      return this.simulateRequest(() => {
        const review = mockReviewsData.find((r) => r.id === reviewId)
        if (!review) {
          throw new Error("Review not found")
        }
        return review
      }, 300)
    },

    create: async (reviewData: Partial<Review>): Promise<ApiResponse<Review>> => {
      return this.simulateRequest(() => {
        // Check if ID already exists
        if (reviewData.id && mockReviewsData.some((r) => r.id === reviewData.id)) {
          throw new Error("Review ID already exists")
        }

        const newReview: Review = {
          id: reviewData.id || `RVW-${String(mockReviewsData.length + 1).padStart(3, "0")}`,
          name: reviewData.name || "",
          description: reviewData.description || "",
          status: reviewData.status || "Draft",
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        }
        mockReviewsData.push(newReview)
        return newReview
      }, 450)
    },

    update: async (reviewId: string, updates: Partial<Review>): Promise<ApiResponse<Review>> => {
      return this.simulateRequest(() => {
        const reviewIndex = mockReviewsData.findIndex((r) => r.id === reviewId)
        if (reviewIndex === -1) {
          throw new Error("Review not found")
        }

        // Check if new ID already exists (and it's not the current review's ID)
        if (updates.id && updates.id !== reviewId && mockReviewsData.some((r) => r.id === updates.id)) {
          throw new Error("Review ID already exists")
        }

        const updatedReview = {
          ...mockReviewsData[reviewIndex],
          ...updates,
          updated_at: new Date().toISOString(),
        }

        // If ID is being changed, update it in the array
        if (updates.id && updates.id !== reviewId) {
          // Update any plans that reference the old ID
          mockPlansData.forEach((plan) => {
            const index = plan.attached_reviews.indexOf(reviewId)
            if (index !== -1) {
              plan.attached_reviews[index] = updates.id!
            }
          })
        }

        mockReviewsData[reviewIndex] = updatedReview
        return updatedReview
      }, 350)
    },

    delete: async (reviewId: string): Promise<ApiResponse<boolean>> => {
      return this.simulateRequest(() => {
        const reviewIndex = mockReviewsData.findIndex((r) => r.id === reviewId)
        if (reviewIndex === -1) {
          throw new Error("Review not found")
        }

        // Remove from any plans that reference it
        mockPlansData.forEach((plan) => {
          plan.attached_reviews = plan.attached_reviews.filter((id) => id !== reviewId)
        })

        mockReviewsData.splice(reviewIndex, 1)
        return true
      }, 250)
    },
  }
}

export const api = new MockAPI()
