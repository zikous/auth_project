"use client"

import { useMemo } from "react"
import type { Task } from "@/lib/types"

interface UseTaskHierarchyProps {
  tasks: Task[]
}

interface FolderInfo {
  id: string
  name: string
  level: number
  path: string
}

export function useTaskHierarchy({ tasks }: UseTaskHierarchyProps) {
  const hierarchy = useMemo(() => {
    // Calculate folder nesting level
    const getFolderLevel = (folderId: string): number => {
      const folder = tasks.find((t) => t.id === folderId)
      if (!folder || !folder.parent_id) return 0
      return 1 + getFolderLevel(folder.parent_id)
    }

    // Build complete folder path
    const getFolderPath = (folderId: string): string => {
      const folder = tasks.find((t) => t.id === folderId)
      if (!folder || !folder.parent_id) return folder?.name || ""
      const parentPath = getFolderPath(folder.parent_id)
      return parentPath ? `${parentPath} / ${folder.name}` : folder.name
    }

    // Get organizational folders only (not leaf tasks)
    const getOrganizationalFolders = (): FolderInfo[] => {
      return tasks
        .filter((task) => task.is_folder || tasks.some((t) => t.parent_id === task.id))
        .map((folder) => ({
          id: folder.id,
          name: folder.name,
          level: getFolderLevel(folder.id),
          path: getFolderPath(folder.id),
        }))
        .sort((a, b) => a.level - b.level)
    }

    // Get available placement locations for tasks (root + folders only)
    const getTaskPlacementOptions = () => {
      const folders = getOrganizationalFolders()
      return [
        { id: "root", name: "Root Level", path: "Root Level", level: 0 },
        ...folders.map((folder) => ({
          id: folder.id,
          name: folder.name,
          path: folder.path,
          level: folder.level,
        })),
      ]
    }

    // Build task tree structure
    const buildTaskTree = () => {
      const taskMap = new Map(tasks.map((task) => [task.id, task]))
      const rootTasks: Task[] = []
      const childrenMap = new Map<string, Task[]>()

      // Build children map
      tasks.forEach((task) => {
        if (task.parent_id) {
          if (!childrenMap.has(task.parent_id)) {
            childrenMap.set(task.parent_id, [])
          }
          childrenMap.get(task.parent_id)!.push(task)
        } else {
          rootTasks.push(task)
        }
      })

      return { taskMap, rootTasks, childrenMap }
    }

    return {
      getFolderLevel,
      getFolderPath,
      getOrganizationalFolders,
      getTaskPlacementOptions,
      buildTaskTree,
    }
  }, [tasks])

  return hierarchy
}
