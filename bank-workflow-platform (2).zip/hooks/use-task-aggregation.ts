"use client"

import { useMemo } from "react"
import type { Task, TaskAggregation, Discussion, Conclusion } from "@/lib/types"

export function useTaskAggregation(tasks: Task[], selectedTaskId?: string) {
  const taskMap = useMemo(() => {
    const map = new Map<string, Task>()
    tasks.forEach((task) => map.set(task.id, task))
    return map
  }, [tasks])

  const getChildTasks = useMemo(() => {
    return (parentId: string): Task[] => {
      return tasks.filter((task) => task.parent_id === parentId)
    }
  }, [tasks])

  const isLeafTask = useMemo(() => {
    return (taskId: string): boolean => {
      const task = taskMap.get(taskId)
      if (!task) return false

      // If explicitly marked as folder, it's not a leaf task
      if (task.is_folder === true) return false

      // If it has children, it's not a leaf task
      const hasChildren = tasks.some((t) => t.parent_id === taskId)
      return !hasChildren
    }
  }, [tasks, taskMap])

  const getAllDescendantTasks = useMemo(() => {
    return (parentId: string): Task[] => {
      const descendants: Task[] = []
      const visited = new Set<string>()

      const collectDescendants = (currentParentId: string) => {
        if (visited.has(currentParentId)) return // Prevent infinite loops
        visited.add(currentParentId)

        const children = getChildTasks(currentParentId)
        console.log(
          `Collecting descendants for ${currentParentId}:`,
          children.map((c) => c.id),
        )

        children.forEach((child) => {
          descendants.push(child)
          collectDescendants(child.id)
        })
      }

      collectDescendants(parentId)
      console.log(
        `All descendants for ${parentId}:`,
        descendants.map((d) => d.id),
      )
      return descendants
    }
  }, [getChildTasks])

  const getTaskAggregation = useMemo(() => {
    return (taskId: string): TaskAggregation => {
      console.log(`\n=== Getting aggregation for task: ${taskId} ===`)

      const task = taskMap.get(taskId)
      if (!task) {
        console.log(`Task ${taskId} not found in taskMap`)
        return {
          discussions: [],
          conclusions: [],
          childTasks: [],
          totalDiscussions: 0,
          totalConclusions: 0,
        }
      }

      const directChildren = getChildTasks(taskId)
      const isFolder = !isLeafTask(taskId)

      console.log(`Task ${taskId} analysis:`, {
        isFolder,
        isLeafTask: isLeafTask(taskId),
        taskIsFolder: task.is_folder,
        directChildrenCount: directChildren.length,
        directChildrenIds: directChildren.map((c) => c.id),
        taskOwnDiscussions: task.discussions?.length || 0,
        taskOwnConclusions: task.conclusions?.length || 0,
      })

      let allDiscussions: Discussion[] = []
      let allConclusions: Conclusion[] = []

      if (isFolder) {
        // For folders, collect from ALL descendant tasks (children, grandchildren, etc.)
        const allDescendants = getAllDescendantTasks(taskId)

        console.log(`Processing ${allDescendants.length} descendants for folder ${taskId}`)

        allDescendants.forEach((descendant) => {
          const descendantDiscussions = descendant.discussions || []
          const descendantConclusions = descendant.conclusions || []

          console.log(`Descendant ${descendant.id}:`, {
            discussions: descendantDiscussions.length,
            conclusions: descendantConclusions.length,
            discussionMessages: descendantDiscussions.map((d) => d.message?.substring(0, 50) + "..."),
          })

          if (descendantDiscussions.length > 0) {
            // Add task_id to each discussion for tracking
            const discussionsWithTaskId = descendantDiscussions.map((d) => ({
              ...d,
              task_id: d.task_id || descendant.id,
            }))
            allDiscussions.push(...discussionsWithTaskId)
          }

          if (descendantConclusions.length > 0) {
            // Add task_id to each conclusion for tracking
            const conclusionsWithTaskId = descendantConclusions.map((c) => ({
              ...c,
              task_id: c.task_id || descendant.id,
            }))
            allConclusions.push(...conclusionsWithTaskId)
          }
        })

        console.log(`Final aggregation for folder ${taskId}:`, {
          totalDiscussions: allDiscussions.length,
          totalConclusions: allConclusions.length,
          discussionSources: allDiscussions.map((d) => d.task_id),
          conclusionSources: allConclusions.map((c) => c.task_id),
        })
      } else {
        // For leaf tasks, use the task's own discussions and conclusions
        allDiscussions = [...(task.discussions || [])]
        allConclusions = [...(task.conclusions || [])]

        console.log(`Leaf task ${taskId} own content:`, {
          discussions: allDiscussions.length,
          conclusions: allConclusions.length,
        })
      }

      // Sort by timestamp (newest first for better UX)
      allDiscussions.sort((a, b) => {
        const dateA = a.timestamp ? new Date(a.timestamp).getTime() : 0
        const dateB = b.timestamp ? new Date(b.timestamp).getTime() : 0
        return dateB - dateA
      })

      allConclusions.sort((a, b) => {
        const dateA = a.timestamp ? new Date(a.timestamp).getTime() : 0
        const dateB = b.timestamp ? new Date(b.timestamp).getTime() : 0
        return dateB - dateA
      })

      const result = {
        discussions: allDiscussions,
        conclusions: allConclusions,
        childTasks: directChildren,
        totalDiscussions: allDiscussions.length,
        totalConclusions: allConclusions.length,
      }

      console.log(`=== Final result for ${taskId}:`, result)
      return result
    }
  }, [taskMap, getChildTasks, isLeafTask, getAllDescendantTasks])

  const selectedTaskAggregation = useMemo(() => {
    if (!selectedTaskId) {
      console.log("No selected task ID")
      return null
    }

    console.log(`\n🔍 Computing aggregation for selected task: ${selectedTaskId}`)
    const aggregation = getTaskAggregation(selectedTaskId)
    console.log(`✅ Selected task aggregation result:`, aggregation)
    return aggregation
  }, [selectedTaskId, getTaskAggregation])

  return {
    getChildTasks,
    isLeafTask,
    getTaskAggregation,
    getAllDescendantTasks,
    selectedTaskAggregation,
  }
}
