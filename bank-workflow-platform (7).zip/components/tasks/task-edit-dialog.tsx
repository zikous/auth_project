"use client"

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { TaskForm } from "@/components/tasks/task-form"
import { TaskUtils } from "@/lib/utils/task-utils"
import type { ReviewPlan, Task } from "@/lib/types"

interface TaskEditDialogProps {
  task: Task | null
  onClose: () => void
  plan: ReviewPlan
  isLoading: boolean
  isOpen: boolean
  onSubmit: (taskData: any) => void
  existingTasks: Task[]
}

export function TaskEditDialog({
  task,
  onClose,
  plan,
  isLoading,
  isOpen,
  onSubmit,
  existingTasks,
}: TaskEditDialogProps) {
  if (!task) return null

  const isFolder = TaskUtils.isFolder(task, existingTasks)

  const taskForm = TaskForm({
    task,
    plan,
    isFolder,
    onSubmit: (taskData) => {
      onSubmit(taskData)
      onClose()
    },
    parentOptions: [], // Not needed for simplified form
  })

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Edit {isFolder ? "Folder" : "Task"}</DialogTitle>
          <DialogDescription>Update the {isFolder ? "folder" : "task"} details</DialogDescription>
        </DialogHeader>

        <div className="py-4">{taskForm.form}</div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={taskForm.formik.handleSubmit} disabled={!taskForm.isValid || isLoading}>
            {isLoading ? "Updating..." : "Update"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
