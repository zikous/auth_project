"use client"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { Card, CardContent } from "@/components/ui/card"
import { CheckSquare, Edit, Trash2, Calendar, User, MessageSquare, GitCommit } from "lucide-react"
import type { Task } from "@/lib/types"

interface SimpleTaskListProps {
  tasks: Task[]
  selectedTaskId: string | null
  onTaskSelect: (taskId: string) => void
  onTaskEdit: (task: Task) => void
  onTaskDelete: (taskId: string) => void
  onTaskToggle: (taskId: string) => void
}

export function SimpleTaskList({
  tasks,
  selectedTaskId,
  onTaskSelect,
  onTaskEdit,
  onTaskDelete,
  onTaskToggle,
}: SimpleTaskListProps) {
  if (tasks.length === 0) {
    return (
      <div className="text-center py-12 text-slate-500">
        <CheckSquare className="h-12 w-12 mx-auto mb-4 opacity-30" />
        <p className="text-lg font-medium mb-2">No tasks yet</p>
        <p className="text-sm">Create your first task to get started</p>
      </div>
    )
  }

  return (
    <div className="space-y-3">
      {tasks.map((task) => (
        <Card
          key={task.id}
          className={`cursor-pointer transition-all hover:shadow-md ${
            selectedTaskId === task.id ? "ring-2 ring-blue-500 bg-blue-50" : ""
          }`}
          onClick={() => onTaskSelect(task.id)}
        >
          <CardContent className="p-4">
            <div className="flex items-start gap-3">
              {/* Checkbox */}
              <div className="mt-1">
                <Checkbox
                  checked={task.completed}
                  onCheckedChange={() => onTaskToggle(task.id)}
                  onClick={(e) => e.stopPropagation()}
                />
              </div>

              {/* Task Content */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-2">
                  <Badge variant="outline" className="text-xs font-mono">
                    {task.id}
                  </Badge>
                  <Badge
                    variant="secondary"
                    className={`text-xs ${
                      task.difficulty === "Easy"
                        ? "bg-green-100 text-green-700"
                        : task.difficulty === "Hard"
                          ? "bg-red-100 text-red-700"
                          : "bg-yellow-100 text-yellow-700"
                    }`}
                  >
                    {task.difficulty}
                  </Badge>
                  {task.completed && (
                    <Badge variant="default" className="text-xs bg-green-600">
                      Completed
                    </Badge>
                  )}
                </div>

                <h3 className={`font-medium mb-1 ${task.completed ? "line-through text-slate-500" : "text-slate-900"}`}>
                  {task.name}
                </h3>

                {task.description && <p className="text-sm text-slate-600 mb-3 line-clamp-2">{task.description}</p>}

                {/* Task Meta */}
                <div className="flex items-center gap-4 text-xs text-slate-500">
                  {task.days_required > 0 && (
                    <div className="flex items-center gap-1">
                      <Calendar className="h-3 w-3" />
                      <span>{task.days_required}d</span>
                    </div>
                  )}
                  {task.assigned_to && (
                    <div className="flex items-center gap-1">
                      <User className="h-3 w-3" />
                      <span>{task.assigned_to}</span>
                    </div>
                  )}
                  {task.discussions.length > 0 && (
                    <div className="flex items-center gap-1">
                      <MessageSquare className="h-3 w-3" />
                      <span>{task.discussions.length}</span>
                    </div>
                  )}
                  {task.conclusions.length > 0 && (
                    <div className="flex items-center gap-1">
                      <GitCommit className="h-3 w-3" />
                      <span>{task.conclusions.length}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center gap-1">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={(e) => {
                    e.stopPropagation()
                    onTaskEdit(task)
                  }}
                  className="h-8 w-8 p-0"
                >
                  <Edit className="h-4 w-4" />
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={(e) => {
                    e.stopPropagation()
                    onTaskDelete(task.id)
                  }}
                  className="h-8 w-8 p-0 text-red-600 hover:text-red-700"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
