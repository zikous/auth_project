"use client"

import { DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import {
  ChevronDown,
  ChevronRight,
  Edit,
  Trash2,
  CheckSquare,
  Square,
  Calendar,
  FolderOpen,
  FileText,
  MessageSquare,
  GitCommit,
  MoreHorizontal,
  Plus,
} from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu"
import type { Task } from "@/lib/types"

interface TaskTreeProps {
  tasks: Task[]
  onTaskSelect: (task: Task) => void
  onTaskEdit: (task: Task) => void
  onTaskDelete: (id: string) => void
  onTaskToggle: (id: string) => void
  onCreateInFolder?: (parentId: string | null, parentName?: string) => void
  selectedTaskId?: string
  getTaskCompletionPercentage: (taskId: string) => number
  getTaskDifficulty: (taskId: string) => "Easy" | "Medium" | "Hard" | null
  isLeafTask: (taskId: string) => boolean
}

export function TaskTree({
  tasks,
  onTaskSelect,
  onTaskEdit,
  onTaskDelete,
  onTaskToggle,
  onCreateInFolder,
  selectedTaskId,
  getTaskCompletionPercentage,
  isLeafTask,
}: TaskTreeProps) {
  const [expandedNodes, setExpandedNodes] = useState<Set<string>>(new Set())

  const toggleExpanded = (taskId: string) => {
    const newExpanded = new Set(expandedNodes)
    if (newExpanded.has(taskId)) {
      newExpanded.delete(taskId)
    } else {
      newExpanded.add(taskId)
    }
    setExpandedNodes(newExpanded)
  }

  const getChildTasks = (parentId: string | null) => {
    return tasks.filter((task) => task.parent_id === parentId)
  }

  const hasChildren = (taskId: string) => {
    return tasks.some((task) => task.parent_id === taskId)
  }

  const isFolder = (task: Task) => {
    return task.is_folder === true || hasChildren(task.id)
  }

  const isExecutableTask = (task: Task) => {
    return !task.is_folder && !hasChildren(task.id)
  }

  const renderTask = (task: Task, level = 0) => {
    const children = getChildTasks(task.id)
    const isExpanded = expandedNodes.has(task.id)
    const isSelected = selectedTaskId === task.id
    const isParent = hasChildren(task.id)
    const isFolderItem = isFolder(task)
    const isTaskItem = isExecutableTask(task)
    const completionPercentage = isParent ? getTaskCompletionPercentage(task.id) : 0

    return (
      <div key={task.id} className="w-full">
        <div
          className={`group flex items-center gap-3 p-3 cursor-pointer transition-colors ${
            isSelected ? "bg-slate-100" : "hover:bg-slate-50"
          }`}
          style={{ paddingLeft: `${level * 24 + 12}px` }}
          onClick={(e) => {
            e.preventDefault()
            e.stopPropagation()
            onTaskSelect(task)
          }}
        >
          {/* Expand/Collapse */}
          {isParent ? (
            <Button
              variant="ghost"
              size="sm"
              className="h-6 w-6 p-0"
              onClick={(e) => {
                e.preventDefault()
                e.stopPropagation()
                toggleExpanded(task.id)
              }}
            >
              {isExpanded ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
            </Button>
          ) : (
            <div className="w-6" />
          )}

          {/* Checkbox for tasks */}
          {isTaskItem && (
            <Button
              variant="ghost"
              size="sm"
              className="h-6 w-6 p-0"
              onClick={(e) => {
                e.preventDefault()
                e.stopPropagation()
                onTaskToggle(task.id)
              }}
            >
              {task.completed ? (
                <CheckSquare className="h-4 w-4 text-green-600" />
              ) : (
                <Square className="h-4 w-4 text-slate-400" />
              )}
            </Button>
          )}

          {/* Icon */}
          {isFolderItem ? (
            <FolderOpen className="h-4 w-4 text-blue-600 flex-shrink-0" />
          ) : (
            <FileText className="h-4 w-4 text-slate-600 flex-shrink-0" />
          )}

          {/* Content */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-500 font-mono">{task.id}</span>
              <span
                className={`text-sm font-medium ${task.completed ? "line-through text-slate-500" : "text-slate-900"}`}
              >
                {task.name}
              </span>
            </div>

            {/* Progress for folders */}
            {isFolderItem && children.length > 0 && (
              <div className="flex items-center gap-2 mt-1">
                <Progress value={completionPercentage} className="flex-1 h-1" />
                <span className="text-xs text-slate-500">{completionPercentage}%</span>
              </div>
            )}

            {/* Meta info */}
            <div className="flex items-center gap-3 mt-1 text-xs text-slate-500">
              {isTaskItem && task.days_required > 0 && (
                <div className="flex items-center gap-1">
                  <Calendar className="h-3 w-3" />
                  <span>{task.days_required}d</span>
                </div>
              )}
              {(task.discussions.length > 0 || task.conclusions.length > 0) && (
                <div className="flex items-center gap-2">
                  {task.discussions.length > 0 && (
                    <div className="flex items-center gap-1">
                      <MessageSquare className="h-3 w-3" />
                      <span>{task.discussions.length}</span>
                    </div>
                  )}
                  {task.conclusions.length > 0 && (
                    <div className="flex items-center gap-1">
                      <GitCommit className="h-3 w-3" />
                      <span>{task.conclusions.length}</span>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Actions */}
          <div className="opacity-0 group-hover:opacity-100 transition-opacity">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-6 w-6 p-0"
                  onClick={(e) => {
                    e.preventDefault()
                    e.stopPropagation()
                  }}
                >
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                {/* Add items to folder */}
                {isFolderItem && onCreateInFolder && (
                  <>
                    <DropdownMenuItem
                      onClick={(e) => {
                        e.preventDefault()
                        e.stopPropagation()
                        onCreateInFolder(task.id, task.name)
                      }}
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      Add to {task.name}
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                  </>
                )}

                <DropdownMenuItem
                  onClick={(e) => {
                    e.preventDefault()
                    e.stopPropagation()
                    onTaskEdit(task)
                  }}
                >
                  <Edit className="h-4 w-4 mr-2" />
                  Edit
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={(e) => {
                    e.preventDefault()
                    e.stopPropagation()
                    onTaskDelete(task.id)
                  }}
                  className="text-red-600"
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>

        {/* Children */}
        {isExpanded && children.length > 0 && (
          <div className="border-l border-slate-200 ml-6">{children.map((child) => renderTask(child, level + 1))}</div>
        )}
      </div>
    )
  }

  const rootTasks = getChildTasks(null)

  return (
    <div className="space-y-1">
      {/* Add to Root Level Button */}
      {onCreateInFolder && (
        <div className="p-2 border-b border-slate-200">
          <Button
            variant="outline"
            size="sm"
            onClick={() => onCreateInFolder(null, "Root Level")}
            className="w-full justify-start text-slate-600 hover:text-slate-900"
          >
            <Plus className="h-4 w-4 mr-2" />
            Add to Root Level
          </Button>
        </div>
      )}

      {rootTasks.length > 0 ? (
        rootTasks.map((task) => renderTask(task))
      ) : (
        <div className="text-center py-12 text-slate-500">
          <CheckSquare className="h-8 w-8 mx-auto mb-3 opacity-30" />
          <p className="text-sm">No tasks yet. Create your first task to get started.</p>
        </div>
      )}
    </div>
  )
}
