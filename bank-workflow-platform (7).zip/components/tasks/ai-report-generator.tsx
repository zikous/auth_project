"use client"

import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Separator } from "@/components/ui/separator"
import {
  Bot,
  Settings,
  RefreshCw,
  ChevronDown,
  ChevronRight,
  AlertTriangle,
  Sparkles,
  FileText,
  Copy,
  Users,
} from "lucide-react"
import type { Task, ReviewPlan, TaskAggregation } from "@/lib/types"
import { useAIReport } from "@/hooks/use-ai-report"
import { useState } from "react"

interface AIReportGeneratorProps {
  task: Task | null
  plan: ReviewPlan | null
  aggregation: TaskAggregation | null
  getTaskCompletionPercentage: (taskId: string) => number
}

export function AIReportGenerator({ task, plan, aggregation, getTaskCompletionPercentage }: AIReportGeneratorProps) {
  const [showPrompt, setShowPrompt] = useState(false)
  const [activeTab, setActiveTab] = useState("report")

  const {
    currentPrompt,
    customPrompt,
    setCustomPrompt,
    isEditingPrompt,
    isGenerating,
    generateReport,
    handleGenerateReport,
    handleEditPrompt,
    handleSavePrompt,
    handleCancelPrompt,
  } = useAIReport(task, plan, aggregation, getTaskCompletionPercentage)

  console.log("AIReportGenerator received:", {
    task: task ? { id: task.id, name: task.name } : null,
    plan: plan ? { id: plan.id, name: plan.name } : null,
    aggregation,
  })

  // Early return if no task - this was the main issue
  if (!task) {
    return (
      <div className="space-y-6">
        <Card>
          <CardContent className="flex items-center justify-center py-8">
            <div className="text-center space-y-2">
              <Bot className="h-8 w-8 text-muted-foreground mx-auto" />
              <p className="text-sm text-muted-foreground">Select a task to generate an AI report</p>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  // If we have a task but no plan, use a default plan structure
  const safePlan = plan || {
    id: "unknown",
    name: "Unknown Plan",
    description: "",
    attached_reviews: "",
    validation_status: "In Construction" as const,
    tasks: [],
  }

  // Always allow report generation if we have a task - even without discussions/conclusions
  const canGenerateReport = true
  const isParentTask = aggregation?.childTasks?.length ? aggregation.childTasks.length > 0 : false

  const report = generateReport(currentPrompt)

  const handleCopyReport = async () => {
    if (!report) return
    try {
      await navigator.clipboard.writeText(report.content)
    } catch (error) {
      console.error("Failed to copy report:", error)
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Bot className="h-5 w-5 text-purple-500" />
          <h4 className="text-sm font-medium">AI-Generated Report</h4>
          <Badge variant="outline" className="text-xs">
            {isEditingPrompt ? "Custom Prompt" : "Standard"}
          </Badge>
          {isParentTask && (
            <Badge variant="secondary" className="text-xs">
              <Users className="h-3 w-3 mr-1" />
              Aggregated
            </Badge>
          )}
        </div>
        <Button variant="ghost" size="sm" onClick={handleGenerateReport} disabled={isGenerating} className="text-xs">
          {isGenerating ? <RefreshCw className="h-3 w-3 mr-1 animate-spin" /> : <Sparkles className="h-3 w-3 mr-1" />}
          {isGenerating ? "Generating..." : "Generate Report"}
        </Button>
      </div>

      {/* Task Info Display */}
      <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
        <div className="flex items-center gap-2 mb-1">
          <FileText className="h-4 w-4 text-blue-600" />
          <span className="text-sm font-medium text-blue-800">Selected Task:</span>
          <Badge variant="outline" className="font-mono text-xs">
            {task.id}
          </Badge>
        </div>
        <p className="text-sm text-blue-700">{task.name}</p>
        <div className="flex items-center gap-4 mt-2 text-xs text-blue-600">
          <span>Discussions: {task.discussions?.length || 0}</span>
          <span>Conclusions: {task.conclusions?.length || 0}</span>
          <span>Status: {task.completed ? "Completed" : "In Progress"}</span>
        </div>
      </div>

      {/* Prompt Configuration */}
      <div className="space-y-3">
        <Button
          variant="outline"
          size="sm"
          className="w-full justify-between text-xs bg-transparent"
          onClick={() => setShowPrompt(!showPrompt)}
        >
          <div className="flex items-center gap-2">
            <Settings className="h-3 w-3" />
            AI Prompt Configuration
          </div>
          {showPrompt ? <ChevronDown className="h-3 w-3" /> : <ChevronRight className="h-3 w-3" />}
        </Button>

        {showPrompt && (
          <Card className="border-orange-200 bg-orange-50/50 dark:bg-orange-950/20 dark:border-orange-800">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Settings className="h-4 w-4" />
                  Prompt Settings
                </CardTitle>
                <div className="flex items-center gap-2">
                  {isEditingPrompt && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setCustomPrompt("")
                        handleEditPrompt(false)
                      }}
                      className="text-xs"
                    >
                      Reset to Default
                    </Button>
                  )}
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleEditPrompt(!isEditingPrompt)}
                    className="text-xs"
                  >
                    {isEditingPrompt ? "Cancel Edit" : "Edit Prompt"}
                  </Button>
                </div>
              </div>
              <CardDescription className="flex items-start gap-2">
                <AlertTriangle className="h-4 w-4 text-orange-500 mt-0.5 flex-shrink-0" />
                <span className="text-xs">
                  Modifying the AI prompt may affect report quality and consistency. Use the default prompt for
                  standardized reports across all tasks.
                </span>
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {isEditingPrompt ? (
                <div className="space-y-3">
                  <Label htmlFor="custom-prompt" className="text-sm">
                    Custom Prompt
                  </Label>
                  <Textarea
                    id="custom-prompt"
                    value={customPrompt}
                    onChange={(e) => setCustomPrompt(e.target.value)}
                    rows={6}
                    className="w-full text-xs font-mono resize-none"
                    placeholder="Enter your custom prompt..."
                  />
                  <div className="flex justify-between">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setCustomPrompt("")
                        handleEditPrompt(false)
                      }}
                      className="text-xs text-red-600 hover:text-red-700"
                    >
                      Reset to Default
                    </Button>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" onClick={handleCancelPrompt}>
                        Cancel
                      </Button>
                      <Button size="sm" onClick={handleSavePrompt}>
                        Apply Custom Prompt
                      </Button>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="space-y-2">
                  <Label className="text-sm">Current Prompt</Label>
                  <ScrollArea className="h-24 w-full rounded border bg-muted/50 p-2">
                    <pre className="text-xs text-muted-foreground whitespace-pre-wrap font-mono w-full">
                      {currentPrompt}
                    </pre>
                  </ScrollArea>
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </div>

      <Separator />

      {/* Report Content */}
      <div className="space-y-4">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <div className="flex items-center justify-between">
            <TabsList className="grid w-full max-w-md grid-cols-1">
              <TabsTrigger value="report" className="flex items-center gap-1 text-xs">
                <FileText className="h-3 w-3" />
                Generated Report
              </TabsTrigger>
            </TabsList>

            {activeTab === "report" && report && (
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm" onClick={handleCopyReport} className="text-xs bg-transparent">
                  <Copy className="h-3 w-3 mr-1" />
                  Copy
                </Button>
              </div>
            )}
          </div>

          <TabsContent value="report" className="mt-4">
            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm">Analysis Report</CardTitle>
                  {isParentTask && (
                    <Badge variant="default" className="text-xs bg-emerald-100 text-emerald-700 border-emerald-200">
                      Aggregated Data
                    </Badge>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-96 w-full">
                  <div className="prose prose-sm max-w-none dark:prose-invert">
                    {report ? (
                      <pre className="whitespace-pre-wrap text-xs bg-slate-50 text-slate-800 p-4 rounded-lg border border-slate-200 font-sans leading-relaxed">
                        {report.content}
                      </pre>
                    ) : (
                      <div className="text-center py-8">
                        <Bot className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                        <p className="text-gray-600 text-sm">Click "Generate Report" to create an AI analysis.</p>
                      </div>
                    )}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
