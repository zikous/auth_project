"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Progress } from "@/components/ui/progress"
import { FileText, MessageSquare, GitCommit, Send, Calendar, AlertCircle, Folder, Bot, Target } from "lucide-react"
import type { Task, ReviewPlan } from "@/lib/types"
import { AIReportGenerator } from "@/components/tasks/ai-report-generator"

interface SimpleTaskDetailsProps {
  task: Task | null
  plan: ReviewPlan
  onAddDiscussion: (taskId: string, message: string) => void
  onAddConclusion: (taskId: string, message: string) => void
  getChildTasks: (parentId: string | null) => Task[]
  isFolder: (taskId: string) => boolean
  getTaskProgress: (taskId: string) => number
  getAverageTaskDifficulty: (taskId: string) => string
}

export function SimpleTaskDetails({
  task,
  plan,
  onAddDiscussion,
  onAddConclusion,
  getChildTasks,
  isFolder,
  getTaskProgress,
  getAverageTaskDifficulty,
}: SimpleTaskDetailsProps) {
  const [newDiscussion, setNewDiscussion] = useState("")
  const [newConclusion, setNewConclusion] = useState("")

  if (!task) {
    return (
      <Card>
        <CardContent className="p-8 text-center text-slate-500">
          <AlertCircle className="h-12 w-12 mx-auto mb-4 opacity-30" />
          <p className="text-lg font-medium mb-2">No item selected</p>
          <p className="text-sm">Select a task or folder from the tree to view details</p>
        </CardContent>
      </Card>
    )
  }

  const isFolderItem = isFolder(task.id)
  const childTasks = getChildTasks(task.id)
  const progress = isFolderItem ? getTaskProgress(task.id) : 0
  const avgDifficulty = isFolderItem ? getAverageTaskDifficulty(task.id) : task.difficulty

  // Get aggregated discussions and conclusions for folders
  const getAggregatedData = () => {
    if (!isFolderItem) return { discussions: task.discussions, conclusions: task.conclusions }

    const allDiscussions: any[] = []
    const allConclusions: any[] = []

    const collectFromChildren = (parentId: string) => {
      const children = getChildTasks(parentId)
      children.forEach((child) => {
        if (!isFolder(child.id)) {
          // Only collect from actual tasks, not folders
          allDiscussions.push(...child.discussions.map((d) => ({ ...d, taskName: child.name, taskId: child.id })))
          allConclusions.push(...child.conclusions.map((c) => ({ ...c, taskName: child.name, taskId: child.id })))
        } else {
          // Recursively collect from child folders
          collectFromChildren(child.id)
        }
      })
    }

    collectFromChildren(task.id)

    // Sort by timestamp (newest first)
    allDiscussions.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
    allConclusions.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())

    return { discussions: allDiscussions, conclusions: allConclusions }
  }

  const { discussions, conclusions } = getAggregatedData()

  const handleAddDiscussion = () => {
    if (!newDiscussion.trim() || isFolderItem) return
    onAddDiscussion(task.id, newDiscussion.trim())
    setNewDiscussion("")
  }

  const handleAddConclusion = () => {
    if (!newConclusion.trim() || isFolderItem) return
    onAddConclusion(task.id, newConclusion.trim())
    setNewConclusion("")
  }

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Easy":
        return "border-green-500 text-green-700 bg-green-50"
      case "Hard":
        return "border-red-500 text-red-700 bg-red-50"
      case "Medium":
        return "border-yellow-500 text-yellow-700 bg-yellow-50"
      default:
        return "border-slate-500 text-slate-700 bg-slate-50"
    }
  }

  // Create aggregation object for AI report (only for individual tasks)
  const taskAggregation = !isFolderItem
    ? {
        discussions: task.discussions || [],
        conclusions: task.conclusions || [],
        childTasks: [],
        totalDiscussions: (task.discussions || []).length,
        totalConclusions: (task.conclusions || []).length,
      }
    : null

  const getTaskCompletionPercentage = (taskId: string) => {
    if (!isFolderItem) {
      return task.completed ? 100 : 0
    }
    return getTaskProgress(taskId)
  }

  return (
    <Card>
      <CardHeader className="border-b">
        <div className="flex items-start gap-3">
          {isFolderItem ? (
            <Folder className="h-5 w-5 text-blue-600 mt-1" />
          ) : (
            <FileText className="h-5 w-5 text-slate-600 mt-1" />
          )}
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <Badge variant="outline" className="font-mono text-xs">
                {task.id}
              </Badge>
              <Badge
                variant={isFolderItem ? "secondary" : task.completed ? "default" : "secondary"}
                className={isFolderItem ? "bg-blue-100 text-blue-700" : task.completed ? "bg-green-600" : ""}
              >
                {isFolderItem ? "Folder" : task.completed ? "Completed" : "In Progress"}
              </Badge>
              <Badge variant="outline" className={`text-xs ${getDifficultyColor(avgDifficulty)}`}>
                {avgDifficulty} {isFolderItem && childTasks.length > 0 ? "(avg)" : ""}
              </Badge>
            </div>
            <CardTitle className="text-lg">{task.name}</CardTitle>
            {task.description && <p className="text-sm text-slate-600 mt-2">{task.description}</p>}

            {/* Folder Progress */}
            {isFolderItem && childTasks.length > 0 && (
              <div className="mt-3 p-3 bg-blue-50 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-blue-800">Folder Progress</span>
                  <span className="text-sm font-bold text-blue-800">{progress}%</span>
                </div>
                <Progress value={progress} className="h-2" />
                <p className="text-xs text-blue-600 mt-1">
                  {childTasks.filter((t) => !isFolder(t.id) && t.completed).length} of{" "}
                  {childTasks.filter((t) => !isFolder(t.id)).length} tasks completed
                </p>
              </div>
            )}

            {/* Task Meta (only for actual tasks) */}
            {!isFolderItem && (
              <div className="flex items-center gap-4 mt-3 text-sm text-slate-500">
                {task.days_required > 0 && (
                  <div className="flex items-center gap-1">
                    <Calendar className="h-4 w-4" />
                    <span>{task.days_required} days</span>
                  </div>
                )}
              </div>
            )}

            {/* Folder Meta */}
            {isFolderItem && (
              <div className="flex items-center gap-4 mt-3 text-sm text-slate-500">
                <div className="flex items-center gap-1">
                  <Target className="h-4 w-4" />
                  <span>{childTasks.length} items</span>
                </div>
                <div className="flex items-center gap-1">
                  <MessageSquare className="h-4 w-4" />
                  <span>{discussions.length} discussions</span>
                </div>
                <div className="flex items-center gap-1">
                  <GitCommit className="h-4 w-4" />
                  <span>{conclusions.length} conclusions</span>
                </div>
              </div>
            )}
          </div>
        </div>
      </CardHeader>

      <CardContent className="p-6">
        <Tabs defaultValue="discussions" className="w-full">
          <TabsList className={`grid w-full ${isFolderItem ? "grid-cols-2" : "grid-cols-3"}`}>
            <TabsTrigger value="discussions">
              <MessageSquare className="h-4 w-4 mr-2" />
              {isFolderItem ? "All Discussions" : "Discussions"} ({discussions.length})
            </TabsTrigger>
            <TabsTrigger value="conclusions">
              <GitCommit className="h-4 w-4 mr-2" />
              {isFolderItem ? "All Conclusions" : "Conclusions"} ({conclusions.length})
            </TabsTrigger>
            {/* AI Report only for individual tasks */}
            {!isFolderItem && (
              <TabsTrigger value="ai-report">
                <Bot className="h-4 w-4 mr-2" />
                AI Report
              </TabsTrigger>
            )}
          </TabsList>

          <TabsContent value="discussions" className="mt-4 space-y-4">
            <ScrollArea className="h-64 border rounded p-3">
              {discussions.length > 0 ? (
                <div className="space-y-3">
                  {discussions.map((discussion, index) => (
                    <div key={discussion.id || index} className="pb-3 border-b last:border-b-0">
                      <div className="flex items-center gap-2 mb-1">
                        {isFolderItem && (
                          <Badge variant="outline" className="text-xs font-mono">
                            {discussion.taskId}
                          </Badge>
                        )}
                        <span className="text-xs text-slate-500">
                          {new Date(discussion.timestamp).toLocaleString()}
                        </span>
                      </div>
                      {isFolderItem && <p className="text-xs text-blue-600 mb-1">From: {discussion.taskName}</p>}
                      <p className="text-sm text-slate-700">{discussion.message}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-slate-500">
                  <MessageSquare className="h-8 w-8 mx-auto mb-2 opacity-30" />
                  <p className="text-sm">{isFolderItem ? "No discussions in child tasks yet" : "No discussions yet"}</p>
                </div>
              )}
            </ScrollArea>

            {/* Only allow adding discussions to actual tasks */}
            {!isFolderItem && (
              <div className="space-y-2">
                <Textarea
                  placeholder="Add a discussion point..."
                  value={newDiscussion}
                  onChange={(e) => setNewDiscussion(e.target.value)}
                  rows={3}
                />
                <Button onClick={handleAddDiscussion} disabled={!newDiscussion.trim()} className="w-full">
                  <Send className="h-4 w-4 mr-2" />
                  Add Discussion
                </Button>
              </div>
            )}

            {isFolderItem && (
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg">
                <p className="text-sm text-amber-800">
                  <AlertCircle className="h-4 w-4 inline mr-1" />
                  Discussions are added to individual tasks, not folders. Select a task to add discussions.
                </p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="conclusions" className="mt-4 space-y-4">
            <ScrollArea className="h-64 border rounded p-3">
              {conclusions.length > 0 ? (
                <div className="space-y-3">
                  {conclusions.map((conclusion, index) => (
                    <div key={conclusion.id || index} className="pb-3 border-b last:border-b-0">
                      <div className="flex items-center gap-2 mb-1">
                        {isFolderItem && (
                          <Badge variant="outline" className="text-xs font-mono">
                            {conclusion.taskId}
                          </Badge>
                        )}
                        <span className="text-sm font-medium">v{conclusion.version}</span>
                        <span className="text-xs text-slate-500">
                          {new Date(conclusion.timestamp).toLocaleString()}
                        </span>
                      </div>
                      {isFolderItem && <p className="text-xs text-green-600 mb-1">From: {conclusion.taskName}</p>}
                      <p className="text-sm text-slate-700">{conclusion.message}</p>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-slate-500">
                  <GitCommit className="h-8 w-8 mx-auto mb-2 opacity-30" />
                  <p className="text-sm">{isFolderItem ? "No conclusions in child tasks yet" : "No conclusions yet"}</p>
                </div>
              )}
            </ScrollArea>

            {/* Only allow adding conclusions to actual tasks */}
            {!isFolderItem && (
              <div className="space-y-2">
                <Textarea
                  placeholder="Add a conclusion..."
                  value={newConclusion}
                  onChange={(e) => setNewConclusion(e.target.value)}
                  rows={3}
                />
                <Button onClick={handleAddConclusion} disabled={!newConclusion.trim()} className="w-full">
                  <GitCommit className="h-4 w-4 mr-2" />
                  Add Conclusion
                </Button>
              </div>
            )}

            {isFolderItem && (
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg">
                <p className="text-sm text-amber-800">
                  <AlertCircle className="h-4 w-4 inline mr-1" />
                  Conclusions are added to individual tasks, not folders. Select a task to add conclusions.
                </p>
              </div>
            )}
          </TabsContent>

          {/* AI Report tab only for individual tasks */}
          {!isFolderItem && (
            <TabsContent value="ai-report" className="mt-4">
              <div className="w-full">
                <AIReportGenerator
                  task={task}
                  plan={plan}
                  aggregation={taskAggregation}
                  getTaskCompletionPercentage={getTaskCompletionPercentage}
                />
              </div>
            </TabsContent>
          )}
        </Tabs>
      </CardContent>
    </Card>
  )
}
