"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Plus, Target, CheckSquare, Clock, FileText, Folder } from "lucide-react"
import type { ReviewPlan } from "@/lib/types"
import { SimpleTaskTree } from "./simple-task-tree"
import { SimpleTaskDetails } from "./simple-task-details"
import { SimpleTaskForm } from "./simple-task-form"
import { ConfirmationDialog } from "@/components/confirmation-dialog"
import { useSimpleTasks } from "@/hooks/use-simple-tasks"
import { useToast } from "@/hooks/use-toast"

interface SimpleTaskPanelProps {
  initialPlan: ReviewPlan
}

export function SimpleTaskPanel({ initialPlan }: SimpleTaskPanelProps) {
  const [isCreateOpen, setIsCreateOpen] = useState(false)
  const [createParentId, setCreateParentId] = useState<string | null>(null)
  const [createParentName, setCreateParentName] = useState<string>("")
  const [editingTask, setEditingTask] = useState<any>(null)
  const [taskToDelete, setTaskToDelete] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)

  const { toast } = useToast()

  const {
    plan,
    tasks,
    selectedTask,
    setSelectedTaskId,
    createTask,
    updateTask,
    deleteTask,
    toggleTask,
    addDiscussion,
    addConclusion,
    getChildTasks,
    isFolder,
    getTaskProgress,
    getAverageTaskDifficulty,
    totalTasks,
    completedTasks,
    progress,
  } = useSimpleTasks(initialPlan)

  const handleCreateChild = (parentId: string | null) => {
    setCreateParentId(parentId)
    if (parentId) {
      const parent = tasks.find((t) => t.id === parentId)
      setCreateParentName(parent?.name || "Unknown")
    } else {
      setCreateParentName("Root Level")
    }
    setIsCreateOpen(true)
  }

  const handleCreateTask = async (taskData: any) => {
    setIsLoading(true)
    try {
      await createTask(taskData)
      setIsCreateOpen(false)
      setCreateParentId(null)
      setCreateParentName("")
      toast({ title: `${taskData.is_folder ? "Folder" : "Task"} created successfully` })
    } catch (error) {
      toast({ title: "Error creating task", variant: "destructive" })
    } finally {
      setIsLoading(false)
    }
  }

  const handleEditTask = async (taskData: any) => {
    if (!editingTask) return

    setIsLoading(true)
    try {
      updateTask(editingTask.id, taskData)
      setEditingTask(null)
      toast({ title: `${taskData.is_folder ? "Folder" : "Task"} updated successfully` })
    } catch (error) {
      toast({ title: "Error updating task", variant: "destructive" })
    } finally {
      setIsLoading(false)
    }
  }

  const handleDeleteTask = () => {
    if (!taskToDelete) return

    try {
      const task = tasks.find((t) => t.id === taskToDelete)
      const childCount = getChildTasks(taskToDelete).length

      deleteTask(taskToDelete)
      setTaskToDelete(null)

      const message =
        childCount > 0
          ? `${task?.is_folder ? "Folder" : "Task"} and ${childCount} child items deleted`
          : `${task?.is_folder ? "Folder" : "Task"} deleted successfully`

      toast({ title: message })
    } catch (error) {
      toast({ title: "Error deleting task", variant: "destructive" })
    }
  }

  // Count folders separately
  const folderCount = tasks.filter((t) => isFolder(t.id)).length

  return (
    <div className="space-y-6">
      {/* Plan Header */}
      <Card className="border-l-4 border-l-blue-500">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-blue-100 rounded-xl">
                <Target className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <CardTitle className="text-xl">{plan.name}</CardTitle>
                <p className="text-sm text-slate-600 mt-1">{plan.description}</p>
                <div className="flex items-center gap-2 mt-2">
                  <Badge variant="outline" className="text-xs">
                    {plan.id}
                  </Badge>
                  <Badge variant="secondary" className="text-xs">
                    {plan.validation_status}
                  </Badge>
                </div>
              </div>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Folder className="h-8 w-8 text-blue-600" />
              <div>
                <p className="text-sm text-slate-600">Folders</p>
                <p className="text-2xl font-bold">{folderCount}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <FileText className="h-8 w-8 text-slate-600" />
              <div>
                <p className="text-sm text-slate-600">Tasks</p>
                <p className="text-2xl font-bold">{totalTasks}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <CheckSquare className="h-8 w-8 text-green-600" />
              <div>
                <p className="text-sm text-slate-600">Completed</p>
                <p className="text-2xl font-bold">{completedTasks}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Clock className="h-8 w-8 text-orange-600" />
              <div>
                <p className="text-sm text-slate-600">Remaining</p>
                <p className="text-2xl font-bold">{totalTasks - completedTasks}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Progress */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium">Overall Progress</span>
            <span className="text-sm font-bold">{progress}%</span>
          </div>
          <Progress value={progress} className="h-2" />
        </CardContent>
      </Card>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Task Tree */}
        <Card>
          <CardHeader className="border-b">
            <div className="flex justify-between items-center">
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" />
                Project Structure
              </CardTitle>
              <Button onClick={() => handleCreateChild(null)}>
                <Plus className="h-4 w-4 mr-2" />
                New Item
              </Button>
            </div>
          </CardHeader>
          <CardContent className="p-4">
            <SimpleTaskTree
              tasks={tasks}
              selectedTaskId={selectedTask?.id || null}
              onTaskSelect={setSelectedTaskId}
              onTaskEdit={setEditingTask}
              onTaskDelete={setTaskToDelete}
              onTaskToggle={toggleTask}
              onCreateChild={handleCreateChild}
              getChildTasks={getChildTasks}
              isFolder={isFolder}
              getTaskProgress={getTaskProgress}
            />
          </CardContent>
        </Card>

        {/* Task Details */}
        <SimpleTaskDetails
          task={selectedTask}
          onAddDiscussion={addDiscussion}
          onAddConclusion={addConclusion}
          getChildTasks={getChildTasks}
          isFolder={isFolder}
          getTaskProgress={getTaskProgress}
          getAverageTaskDifficulty={getAverageTaskDifficulty}
        />
      </div>

      {/* Dialogs */}
      <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create New Item</DialogTitle>
          </DialogHeader>
          <SimpleTaskForm
            plan={plan}
            parentId={createParentId}
            parentName={createParentName}
            onSubmit={handleCreateTask}
            onCancel={() => {
              setIsCreateOpen(false)
              setCreateParentId(null)
              setCreateParentName("")
            }}
            isLoading={isLoading}
            getChildTasks={getChildTasks}
          />
        </DialogContent>
      </Dialog>

      <Dialog open={!!editingTask} onOpenChange={() => setEditingTask(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit {editingTask?.is_folder ? "Folder" : "Task"}</DialogTitle>
          </DialogHeader>
          <SimpleTaskForm
            task={editingTask}
            plan={plan}
            onSubmit={handleEditTask}
            onCancel={() => setEditingTask(null)}
            isLoading={isLoading}
            getChildTasks={getChildTasks}
          />
        </DialogContent>
      </Dialog>

      <ConfirmationDialog
        open={!!taskToDelete}
        onOpenChange={() => setTaskToDelete(null)}
        onConfirm={handleDeleteTask}
        title={`Delete ${tasks.find((t) => t.id === taskToDelete)?.is_folder ? "Folder" : "Task"}`}
        description={
          taskToDelete && getChildTasks(taskToDelete).length > 0
            ? "This will also delete all child items. Are you sure?"
            : "Are you sure you want to delete this item? This action cannot be undone."
        }
        confirmText="Delete"
        variant="destructive"
      />
    </div>
  )
}
