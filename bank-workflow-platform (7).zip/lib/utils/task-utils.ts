"use client"

import type { Task } from "@/lib/types"

// Task utility functions
export class TaskUtils {
  static isLeafTask(taskId: string, tasks: Task[]): boolean {
    const task = tasks.find((t) => t.id === taskId)
    if (!task) return false
    if (task.is_folder) return false
    return !tasks.some((t) => t.parent_id === taskId)
  }

  static isFolder(task: Task, tasks: Task[]): boolean {
    return task.is_folder === true || tasks.some((t) => t.parent_id === task.id)
  }

  static getChildTasks(parentId: string | null, tasks: Task[]): Task[] {
    return tasks.filter((task) => task.parent_id === parentId)
  }

  static getAllDescendants(parentId: string, tasks: Task[]): Task[] {
    const descendants: Task[] = []
    const visited = new Set<string>()

    const collectDescendants = (currentParentId: string) => {
      if (visited.has(currentParentId)) return
      visited.add(currentParentId)

      const children = this.getChildTasks(currentParentId, tasks)
      children.forEach((child) => {
        descendants.push(child)
        collectDescendants(child.id)
      })
    }

    collectDescendants(parentId)
    return descendants
  }

  static getLeafTasks(tasks: Task[]): Task[] {
    return tasks.filter((task) => this.isLeafTask(task.id, tasks))
  }

  static getCompletedLeafTasks(tasks: Task[]): Task[] {
    return this.getLeafTasks(tasks).filter((task) => task.completed)
  }

  static calculateCompletionPercentage(parentId: string, tasks: Task[]): number {
    const leafTasks = this.getAllDescendants(parentId, tasks).filter((task) => this.isLeafTask(task.id, tasks))
    if (leafTasks.length === 0) return 0

    const completedTasks = leafTasks.filter((task) => task.completed).length
    return Math.round((completedTasks / leafTasks.length) * 100)
  }

  static generateTaskId(isFolder: boolean, existingTasks: Task[]): string {
    const prefix = isFolder ? "FLD" : "TSK"
    const number = existingTasks.length + 1
    return `${prefix}-${String(number).padStart(3, "0")}`
  }

  static parseTaskDescription(description: string) {
    const parts = description.split("\n\n")
    const baseDescription = parts[0] || ""

    const parsed: Record<string, string> = { description: baseDescription }

    parts.slice(1).forEach((part) => {
      const colonIndex = part.indexOf(":")
      if (colonIndex > -1) {
        const key = part.substring(0, colonIndex).trim().toLowerCase().replace(/\s+/g, "_")
        const value = part.substring(colonIndex + 1).trim()
        parsed[key] = value
      }
    })

    return parsed
  }

  static buildTaskDescription(data: {
    description: string
    objective?: string
    deliverables?: string
    acceptance_criteria?: string
    prerequisites?: string
    organizational_purpose?: string
    scope_definition?: string
  }): string {
    let result = data.description

    if (data.objective) {
      result += `\n\nObjective: ${data.objective}`
    }
    if (data.deliverables) {
      result += `\n\nDeliverables:\n${data.deliverables}`
    }
    if (data.acceptance_criteria) {
      result += `\n\nAcceptance Criteria:\n${data.acceptance_criteria}`
    }
    if (data.prerequisites) {
      result += `\n\nPrerequisites:\n${data.prerequisites}`
    }
    if (data.organizational_purpose) {
      result += `\n\nOrganizational Purpose: ${data.organizational_purpose}`
    }
    if (data.scope_definition) {
      result += `\n\nScope Definition: ${data.scope_definition}`
    }

    return result.trim()
  }
}
