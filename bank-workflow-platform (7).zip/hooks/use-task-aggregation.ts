"use client"

import type { Task, TaskAggregation, Discussion, Conclusion } from "@/lib/types"

export function useTaskAggregation(tasks: Task[], selectedTaskId?: string | null) {
  // Ensure tasks is always an array
  const safeTasks = Array.isArray(tasks) ? tasks : []

  // Simple functions without memoization
  const getChildTasks = (parentId: string): Task[] => {
    try {
      return safeTasks.filter((task) => task && task.parent_id === parentId)
    } catch (error) {
      console.warn("Error getting child tasks:", error)
      return []
    }
  }

  const isLeafTask = (taskId: string): boolean => {
    try {
      const task = safeTasks.find((t) => t && t.id === taskId)
      if (!task) return false
      if (task.is_folder === true) return false
      return !safeTasks.some((t) => t && t.parent_id === taskId)
    } catch (error) {
      console.warn("Error checking if leaf task:", error)
      return false
    }
  }

  const getAllDescendantTasks = (parentId: string): Task[] => {
    try {
      const descendants: Task[] = []
      const visited = new Set<string>()

      const collectDescendants = (currentParentId: string) => {
        if (visited.has(currentParentId)) return
        visited.add(currentParentId)

        const children = getChildTasks(currentParentId)
        children.forEach((child) => {
          if (child && child.id) {
            descendants.push(child)
            collectDescendants(child.id)
          }
        })
      }

      collectDescendants(parentId)
      return descendants
    } catch (error) {
      console.warn("Error getting descendant tasks:", error)
      return []
    }
  }

  const getTaskAggregation = (taskId: string): TaskAggregation => {
    try {
      const task = safeTasks.find((t) => t && t.id === taskId)
      if (!task) {
        return {
          discussions: [],
          conclusions: [],
          childTasks: [],
          totalDiscussions: 0,
          totalConclusions: 0,
        }
      }

      const directChildren = getChildTasks(taskId)
      const isFolder = !isLeafTask(taskId)

      let allDiscussions: Discussion[] = []
      let allConclusions: Conclusion[] = []

      if (isFolder) {
        // For folders, collect from ALL descendant tasks
        const allDescendants = getAllDescendantTasks(taskId)

        allDescendants.forEach((descendant) => {
          if (!descendant || !descendant.id) return

          const descendantDiscussions = Array.isArray(descendant.discussions) ? descendant.discussions : []
          const descendantConclusions = Array.isArray(descendant.conclusions) ? descendant.conclusions : []

          if (descendantDiscussions.length > 0) {
            const discussionsWithTaskId = descendantDiscussions.map((d) => ({
              ...d,
              task_id: d.task_id || descendant.id,
            }))
            allDiscussions.push(...discussionsWithTaskId)
          }

          if (descendantConclusions.length > 0) {
            const conclusionsWithTaskId = descendantConclusions.map((c) => ({
              ...c,
              task_id: c.task_id || descendant.id,
            }))
            allConclusions.push(...conclusionsWithTaskId)
          }
        })
      } else {
        // For leaf tasks, use the task's own discussions and conclusions
        allDiscussions = Array.isArray(task.discussions) ? [...task.discussions] : []
        allConclusions = Array.isArray(task.conclusions) ? [...task.conclusions] : []
      }

      // Sort by timestamp (newest first)
      allDiscussions.sort((a, b) => {
        const dateA = a.timestamp ? new Date(a.timestamp).getTime() : 0
        const dateB = b.timestamp ? new Date(b.timestamp).getTime() : 0
        return dateB - dateA
      })

      allConclusions.sort((a, b) => {
        const dateA = a.timestamp ? new Date(a.timestamp).getTime() : 0
        const dateB = b.timestamp ? new Date(b.timestamp).getTime() : 0
        return dateB - dateA
      })

      return {
        discussions: allDiscussions,
        conclusions: allConclusions,
        childTasks: directChildren,
        totalDiscussions: allDiscussions.length,
        totalConclusions: allConclusions.length,
      }
    } catch (error) {
      console.warn("Error getting task aggregation:", error)
      return {
        discussions: [],
        conclusions: [],
        childTasks: [],
        totalDiscussions: 0,
        totalConclusions: 0,
      }
    }
  }

  // Simple computation without memoization
  const selectedTaskAggregation = (() => {
    try {
      if (!selectedTaskId) {
        return null
      }

      // Check if task still exists
      const taskExists = safeTasks.some((t) => t && t.id === selectedTaskId)
      if (!taskExists) {
        return null
      }

      return getTaskAggregation(selectedTaskId)
    } catch (error) {
      console.warn("Error getting selected task aggregation:", error)
      return null
    }
  })()

  return {
    getChildTasks,
    isLeafTask,
    getTaskAggregation,
    getAllDescendantTasks,
    selectedTaskAggregation,
  }
}
