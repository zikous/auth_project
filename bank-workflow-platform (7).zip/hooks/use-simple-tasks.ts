"use client"

import { useState, useCallback } from "react"
import type { ReviewPlan, Task } from "@/lib/types"

export function useSimpleTasks(initialPlan: ReviewPlan) {
  const [plan, setPlan] = useState<ReviewPlan>(initialPlan)
  const [selectedTaskId, setSelectedTaskId] = useState<string | null>(null)

  const selectedTask = plan.tasks.find((t) => t.id === selectedTaskId) || null

  const createTask = useCallback(
    (taskData: Partial<Task>) => {
      const newTask: Task = {
        id: `${taskData.is_folder ? "FLD" : "TSK"}-${Date.now()}`,
        name: taskData.name || "",
        description: taskData.description || "",
        plan_id: plan.id,
        parent_id: taskData.parent_id || null,
        assigned_to: "", // Always empty
        days_required: taskData.is_folder ? 0 : taskData.days_required || 1,
        difficulty: taskData.is_folder ? "Medium" : taskData.difficulty || "Medium",
        completed: false,
        discussions: [],
        conclusions: [],
        is_folder: taskData.is_folder || false,
      }

      setPlan((prev) => ({
        ...prev,
        tasks: [...prev.tasks, newTask],
      }))

      return newTask
    },
    [plan.id],
  )

  const updateTask = useCallback((taskId: string, updates: Partial<Task>) => {
    setPlan((prev) => ({
      ...prev,
      tasks: prev.tasks.map((task) => (task.id === taskId ? { ...task, ...updates } : task)),
    }))
  }, [])

  const deleteTask = useCallback(
    (taskId: string) => {
      const getChildIds = (parentId: string): string[] => {
        const children = plan.tasks.filter((t) => t.parent_id === parentId)
        let allIds = children.map((c) => c.id)
        children.forEach((child) => {
          allIds = allIds.concat(getChildIds(child.id))
        })
        return allIds
      }

      const idsToDelete = [taskId, ...getChildIds(taskId)]

      setPlan((prev) => ({
        ...prev,
        tasks: prev.tasks.filter((task) => !idsToDelete.includes(task.id)),
      }))

      if (selectedTaskId && idsToDelete.includes(selectedTaskId)) {
        setSelectedTaskId(null)
      }
    },
    [plan.tasks, selectedTaskId],
  )

  const toggleTask = useCallback(
    (taskId: string) => {
      const task = plan.tasks.find((t) => t.id === taskId)
      if (!task || task.is_folder) return

      updateTask(taskId, {
        completed: !task.completed,
      })
    },
    [plan.tasks, updateTask],
  )

  const addDiscussion = useCallback(
    (taskId: string, message: string) => {
      const task = plan.tasks.find((t) => t.id === taskId)
      if (!task || task.is_folder) return

      const newDiscussion = {
        id: `DISC-${Date.now()}`,
        message,
        timestamp: new Date().toISOString(),
        task_id: taskId,
      }

      updateTask(taskId, {
        discussions: [...task.discussions, newDiscussion],
      })
    },
    [plan.tasks, updateTask],
  )

  const addConclusion = useCallback(
    (taskId: string, message: string) => {
      const task = plan.tasks.find((t) => t.id === taskId)
      if (!task || task.is_folder) return

      const newConclusion = {
        id: `CONC-${Date.now()}`,
        message,
        timestamp: new Date().toISOString(),
        version: task.conclusions.length + 1,
        task_id: taskId,
      }

      updateTask(taskId, {
        conclusions: [...task.conclusions, newConclusion],
      })
    },
    [plan.tasks, updateTask],
  )

  const getChildTasks = useCallback(
    (parentId: string | null) => {
      return plan.tasks.filter((t) => t.parent_id === parentId)
    },
    [plan.tasks],
  )

  const isFolder = useCallback(
    (taskId: string) => {
      const task = plan.tasks.find((t) => t.id === taskId)
      return task?.is_folder === true || plan.tasks.some((t) => t.parent_id === taskId)
    },
    [plan.tasks],
  )

  const getTaskProgress = useCallback(
    (taskId: string) => {
      const getAllChildTasks = (parentId: string): Task[] => {
        const children = getChildTasks(parentId)
        let allTasks: Task[] = []

        children.forEach((child) => {
          if (!child.is_folder && !plan.tasks.some((t) => t.parent_id === child.id)) {
            allTasks.push(child)
          } else {
            allTasks = allTasks.concat(getAllChildTasks(child.id))
          }
        })

        return allTasks
      }

      const childTasks = getAllChildTasks(taskId)
      if (childTasks.length === 0) return 0
      const completed = childTasks.filter((t) => t.completed).length
      return Math.round((completed / childTasks.length) * 100)
    },
    [getChildTasks, plan.tasks],
  )

  const getAverageTaskDifficulty = useCallback(
    (taskId: string) => {
      const task = plan.tasks.find((t) => t.id === taskId)
      if (!task) return "Medium"

      if (!isFolder(taskId)) {
        return task.difficulty
      }

      const getAllChildTasks = (parentId: string): Task[] => {
        const children = getChildTasks(parentId)
        let allTasks: Task[] = []

        children.forEach((child) => {
          if (!child.is_folder && !plan.tasks.some((t) => t.parent_id === child.id)) {
            allTasks.push(child)
          } else {
            allTasks = allTasks.concat(getAllChildTasks(child.id))
          }
        })

        return allTasks
      }

      const childTasks = getAllChildTasks(taskId)
      if (childTasks.length === 0) return "Medium"

      const difficultyValues = { Easy: 1, Medium: 2, Hard: 3 }
      const totalDifficulty = childTasks.reduce((sum, task) => sum + difficultyValues[task.difficulty], 0)
      const averageDifficulty = totalDifficulty / childTasks.length

      if (averageDifficulty <= 1.5) return "Easy"
      if (averageDifficulty <= 2.5) return "Medium"
      return "Hard"
    },
    [getChildTasks, isFolder, plan.tasks],
  )

  const leafTasks = plan.tasks.filter((t) => !t.is_folder && !plan.tasks.some((child) => child.parent_id === t.id))
  const totalTasks = leafTasks.length
  const completedTasks = leafTasks.filter((t) => t.completed).length
  const progress = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0

  return {
    plan,
    tasks: plan.tasks,
    selectedTask,
    setSelectedTaskId,
    createTask,
    updateTask,
    deleteTask,
    toggleTask,
    addDiscussion,
    addConclusion,
    getChildTasks,
    isFolder,
    getTaskProgress,
    getAverageTaskDifficulty,
    totalTasks,
    completedTasks,
    progress,
  }
}
