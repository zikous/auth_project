"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { usePlans } from "@/hooks/use-plans"
import { useReviews } from "@/hooks/use-reviews"
import { useToast } from "@/hooks/use-toast"
import { PlanList } from "@/components/plans/plan-list"
import { PlanForm } from "@/components/plans/plan-form"
import { ConfirmationDialog } from "@/components/confirmation-dialog"

export default function PlansPage() {
  const { plans, loading, error, createPlan, deletePlan, updatePlanStatus } = usePlans()
  const { reviews } = useReviews()
  const { toast } = useToast()

  const [isCreateOpen, setIsCreateOpen] = useState(false)
  const [deletingId, setDeletingId] = useState<string | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSubmit = async (data: {
    name: string
    description: string
    attached_reviews: string
    man_days: number
  }) => {
    setIsSubmitting(true)
    try {
      const result = await createPlan(data)

      if (result.success) {
        toast({ title: "Plan created successfully" })
        setIsCreateOpen(false)
      } else {
        toast({ title: "Error", description: result.error, variant: "destructive" })
      }
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleDelete = async () => {
    if (!deletingId) return

    const result = await deletePlan(deletingId)
    if (result.success) {
      toast({ title: "Plan deleted successfully" })
    } else {
      toast({ title: "Error", description: result.error, variant: "destructive" })
    }
    setDeletingId(null)
  }

  const handleValidate = async (id: string) => {
    const result = await updatePlanStatus(id, "Validated")
    if (result.success) {
      toast({ title: "Plan validated successfully" })
    } else {
      toast({ title: "Error", description: result.error, variant: "destructive" })
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p>Loading plans...</p>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-red-600 mb-4">Error: {error}</p>
          <button onClick={() => window.location.reload()}>Retry</button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="container mx-auto p-6">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900">Plans</h1>
          <p className="text-gray-600">Manage your execution plans</p>
        </div>

        <PlanList
          plans={plans}
          onDelete={setDeletingId}
          onCreate={() => setIsCreateOpen(true)}
          onValidate={handleValidate}
        />

        {/* Create Dialog */}
        <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>New Plan</DialogTitle>
            </DialogHeader>
            <PlanForm
              reviews={reviews}
              onSubmit={handleSubmit}
              onCancel={() => setIsCreateOpen(false)}
              isLoading={isSubmitting}
            />
          </DialogContent>
        </Dialog>

        {/* Delete Confirmation */}
        <ConfirmationDialog
          open={!!deletingId}
          onOpenChange={() => setDeletingId(null)}
          onConfirm={handleDelete}
          title="Delete Plan"
          description="Are you sure you want to delete this plan? This action cannot be undone."
          confirmText="Delete"
          variant="destructive"
        />
      </div>
    </div>
  )
}
