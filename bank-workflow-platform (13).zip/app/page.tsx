import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { FileText, Users, ArrowRight, CheckCircle, Target } from "lucide-react"
import Link from "next/link"

export default function Dashboard() {
  return (
    <div className="container mx-auto px-6 py-8">
      {/* Header */}
      <div className="mb-8 text-center">
        <h1 className="text-4xl font-bold text-slate-900 mb-4">Banking Workflow Platform</h1>
        <p className="text-lg text-slate-600 max-w-2xl mx-auto">
          Streamline your banking operations with our comprehensive review and planning system. Manage compliance
          reviews and create detailed execution plans with ease.
        </p>
      </div>

      {/* What the app does */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
        <Card className="text-center">
          <CardHeader>
            <div className="mx-auto bg-blue-100 rounded-full p-3 w-fit mb-4">
              <FileText className="h-6 w-6 text-blue-600" />
            </div>
            <CardTitle className="text-xl">Review Management</CardTitle>
            <CardDescription>
              Track and manage individual review items with detailed status monitoring and progress tracking.
            </CardDescription>
          </CardHeader>
        </Card>

        <Card className="text-center">
          <CardHeader>
            <div className="mx-auto bg-green-100 rounded-full p-3 w-fit mb-4">
              <Users className="h-6 w-6 text-green-600" />
            </div>
            <CardTitle className="text-xl">Plan Creation</CardTitle>
            <CardDescription>
              Create comprehensive plans with hierarchical task structures and validation workflows.
            </CardDescription>
          </CardHeader>
        </Card>

        <Card className="text-center">
          <CardHeader>
            <div className="mx-auto bg-purple-100 rounded-full p-3 w-fit mb-4">
              <Target className="h-6 w-6 text-purple-600" />
            </div>
            <CardTitle className="text-xl">Task Execution</CardTitle>
            <CardDescription>
              Execute tasks with detailed tracking, progress monitoring, and completion validation.
            </CardDescription>
          </CardHeader>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card className="max-w-2xl mx-auto">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl">Quick Actions</CardTitle>
          <CardDescription>Get started with the most common banking workflow tasks</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Link href="/reviews">
            <Button variant="outline" className="w-full justify-between h-16 text-left">
              <div className="flex items-center gap-4">
                <div className="bg-blue-100 rounded-lg p-3">
                  <FileText className="h-6 w-6 text-blue-600" />
                </div>
                <div>
                  <div className="font-semibold">Manage Reviews</div>
                  <div className="text-sm text-muted-foreground">View and track individual review items</div>
                </div>
              </div>
              <ArrowRight className="h-5 w-5" />
            </Button>
          </Link>

          <Link href="/plans">
            <Button variant="outline" className="w-full justify-between h-16 text-left">
              <div className="flex items-center gap-4">
                <div className="bg-green-100 rounded-lg p-3">
                  <Users className="h-6 w-6 text-green-600" />
                </div>
                <div>
                  <div className="font-semibold">Create & Manage Plans</div>
                  <div className="text-sm text-muted-foreground">Build plans with tasks and track progress</div>
                </div>
              </div>
              <ArrowRight className="h-5 w-5" />
            </Button>
          </Link>
        </CardContent>
      </Card>

      {/* Key Features */}
      <div className="mt-16 max-w-4xl mx-auto">
        <h2 className="text-2xl font-bold text-center mb-8">Key Features</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="flex gap-4">
            <CheckCircle className="h-6 w-6 text-green-600 mt-1 flex-shrink-0" />
            <div>
              <h3 className="font-semibold mb-2">Hierarchical Task Management</h3>
              <p className="text-sm text-muted-foreground">
                Create complex task structures with parent-child relationships and folder organization.
              </p>
            </div>
          </div>

          <div className="flex gap-4">
            <CheckCircle className="h-6 w-6 text-green-600 mt-1 flex-shrink-0" />
            <div>
              <h3 className="font-semibold mb-2">Progress Tracking</h3>
              <p className="text-sm text-muted-foreground">
                Monitor completion status with real-time progress indicators and detailed analytics.
              </p>
            </div>
          </div>

          <div className="flex gap-4">
            <CheckCircle className="h-6 w-6 text-green-600 mt-1 flex-shrink-0" />
            <div>
              <h3 className="font-semibold mb-2">Validation Workflows</h3>
              <p className="text-sm text-muted-foreground">
                Built-in validation processes to ensure quality and compliance standards are met.
              </p>
            </div>
          </div>

          <div className="flex gap-4">
            <CheckCircle className="h-6 w-6 text-green-600 mt-1 flex-shrink-0" />
            <div>
              <h3 className="font-semibold mb-2">Detailed Reporting</h3>
              <p className="text-sm text-muted-foreground">
                Generate comprehensive reports on review status, plan progress, and task completion.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
