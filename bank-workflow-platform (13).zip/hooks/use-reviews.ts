"use client"

import { useState, useEffect } from "react"
import { api } from "@/lib/api/mock-api"
import type { Review } from "@/lib/types"

export function useReviews() {
  const [reviews, setReviews] = useState<Review[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchReviews = async () => {
      try {
        const response = await api.reviews.getAll()
        if (response.success) {
          setReviews(response.data)
        } else {
          setError(response.error || "Failed to fetch reviews")
        }
      } catch (err) {
        setError("Failed to fetch reviews")
      } finally {
        setLoading(false)
      }
    }
    fetchReviews()
  }, [])

  const createReview = async (data: Partial<Review>) => {
    const response = await api.reviews.create(data)
    if (response.success) {
      setReviews((prev) => [...prev, response.data])
    }
    return response
  }

  const deleteReview = async (id: string) => {
    const response = await api.reviews.delete(id)
    if (response.success) {
      setReviews((prev) => prev.filter((r) => r.id !== id))
    }
    return response
  }

  return { reviews, loading, error, createReview, deleteReview }
}
