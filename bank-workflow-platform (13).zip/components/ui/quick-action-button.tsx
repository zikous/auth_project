"use client"

import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import type { LucideIcon } from "lucide-react"

interface QuickActionButtonProps {
  icon: LucideIcon
  label: string
  description?: string
  onClick: () => void
  variant?: "default" | "folder" | "task"
  disabled?: boolean
  className?: string
}

export function QuickActionButton({
  icon: Icon,
  label,
  description,
  onClick,
  variant = "default",
  disabled = false,
  className,
}: QuickActionButtonProps) {
  const variants = {
    default: "bg-white hover:bg-slate-50 border-slate-200 text-slate-700",
    folder: "bg-blue-50 hover:bg-blue-100 border-blue-200 text-blue-700",
    task: "bg-green-50 hover:bg-green-100 border-green-200 text-green-700",
  }

  return (
    <Button
      variant="outline"
      onClick={onClick}
      disabled={disabled}
      className={cn(
        "h-auto p-4 flex flex-col items-center gap-2 border-2 transition-all duration-200",
        variants[variant],
        disabled && "opacity-50 cursor-not-allowed",
        className,
      )}
    >
      <Icon className="h-6 w-6" />
      <div className="text-center">
        <div className="font-medium text-sm">{label}</div>
        {description && <div className="text-xs opacity-75 mt-1">{description}</div>}
      </div>
    </Button>
  )
}
