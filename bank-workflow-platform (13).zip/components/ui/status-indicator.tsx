"use client"

import { cn } from "@/lib/utils"
import { CheckCircle, Clock, AlertCircle, XCircle } from "lucide-react"

interface StatusIndicatorProps {
  status: "success" | "pending" | "warning" | "error"
  message: string
  className?: string
}

export function StatusIndicator({ status, message, className }: StatusIndicatorProps) {
  const variants = {
    success: {
      icon: CheckCircle,
      className: "bg-green-50 text-green-700 border-green-200",
    },
    pending: {
      icon: Clock,
      className: "bg-blue-50 text-blue-700 border-blue-200",
    },
    warning: {
      icon: AlertCircle,
      className: "bg-amber-50 text-amber-700 border-amber-200",
    },
    error: {
      icon: XCircle,
      className: "bg-red-50 text-red-700 border-red-200",
    },
  }

  const { icon: Icon, className: variantClassName } = variants[status]

  return (
    <div className={cn("flex items-center gap-2 px-3 py-2 rounded-lg border text-sm", variantClassName, className)}>
      <Icon className="h-4 w-4 flex-shrink-0" />
      <span>{message}</span>
    </div>
  )
}
