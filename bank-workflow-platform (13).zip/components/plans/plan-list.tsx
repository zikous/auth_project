"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Badge } from "@/components/ui/badge"
import { Users, Trash2, Plus, ExternalLink, CheckCircle } from "lucide-react"
import Link from "next/link"
import type { ReviewPlan } from "@/lib/types"

interface PlanListProps {
  plans: ReviewPlan[]
  onDelete: (id: string) => void
  onCreate: () => void
  onValidate: (id: string) => void
}

export function PlanList({ plans, onDelete, onCreate, onValidate }: PlanListProps) {
  const [selectedIds, setSelectedIds] = useState<string[]>([])

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]))
  }

  const selectAll = () => {
    setSelectedIds(selectedIds.length === plans.length ? [] : plans.map((p) => p.id))
  }

  if (plans.length === 0) {
    return (
      <Card>
        <CardContent className="p-12 text-center">
          <Users className="h-16 w-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No plans yet</h3>
          <p className="text-gray-500 mb-6">Create your first plan to get started</p>
          <Button onClick={onCreate}>
            <Plus className="h-4 w-4 mr-2" />
            Create Plan
          </Button>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-4">
          <Checkbox checked={selectedIds.length === plans.length} onCheckedChange={selectAll} />
          <span className="text-sm text-gray-600">
            {selectedIds.length > 0 ? `${selectedIds.length} selected` : `${plans.length} plans`}
          </span>
        </div>
        <Button onClick={onCreate}>
          <Plus className="h-4 w-4 mr-2" />
          New Plan
        </Button>
      </div>

      {/* List */}
      <div className="space-y-2">
        {plans.map((plan) => (
          <Card key={plan.id} className="hover:shadow-md transition-shadow">
            <CardContent className="p-4">
              <div className="flex items-center gap-4">
                <Checkbox checked={selectedIds.includes(plan.id)} onCheckedChange={() => toggleSelect(plan.id)} />

                <div className="bg-green-100 p-2 rounded">
                  <Users className="h-4 w-4 text-green-600" />
                </div>

                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <Badge variant="outline" className="font-mono text-xs">
                      {plan.id}
                    </Badge>
                    <h3 className="font-medium">{plan.name}</h3>
                    <Badge
                      className={
                        plan.validation_status === "Validated"
                          ? "bg-green-100 text-green-700"
                          : "bg-orange-100 text-orange-700"
                      }
                    >
                      {plan.validation_status}
                    </Badge>
                  </div>
                  {plan.description && <p className="text-sm text-gray-600">{plan.description}</p>}
                  <div className="flex items-center gap-4 mt-2 text-xs text-gray-500">
                    <span>Review: {plan.attached_reviews}</span>
                    <span>Days: {plan.man_days || 0}</span>
                  </div>
                </div>

                <div className="flex gap-2">
                  <Link href={`/plans/${plan.id}`}>
                    <Button size="sm" variant="outline">
                      <ExternalLink className="h-4 w-4 mr-1" />
                      Tasks
                    </Button>
                  </Link>

                  {plan.validation_status === "In Construction" && (
                    <Button size="sm" variant="ghost" onClick={() => onValidate(plan.id)} className="text-green-600">
                      <CheckCircle className="h-4 w-4" />
                    </Button>
                  )}

                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => onDelete(plan.id)}
                    className="text-red-600 hover:text-red-700"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
