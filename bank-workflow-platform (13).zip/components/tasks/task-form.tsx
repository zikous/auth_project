"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Badge } from "@/components/ui/badge"
import { Folder, FileText, AlertCircle } from "lucide-react"
import type { Task, ReviewPlan } from "@/lib/types"

interface TaskFormProps {
  plan: ReviewPlan
  parentId?: string | null
  parentName?: string
  onSubmit: (taskData: any) => void
  onCancel: () => void
  isLoading?: boolean
  getChildTasks: (parentId: string | null) => Task[]
}

export function TaskForm({
  plan,
  parentId = null,
  parentName,
  onSubmit,
  onCancel,
  isLoading,
  getChildTasks,
}: TaskFormProps) {
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    days_required: 1,
    difficulty: "Medium" as "Easy" | "Medium" | "Hard",
    is_folder: false,
    parent_id: parentId,
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!formData.name.trim()) return
    onSubmit(formData)
  }

  // Get available parent options (only folders and root)
  const getParentOptions = () => {
    const options = [{ id: null, name: "Root Level" }]

    const addFolders = (parentId: string | null, prefix = "") => {
      const children = getChildTasks(parentId)
      children.forEach((child) => {
        if (child.is_folder) {
          options.push({ id: child.id, name: `${prefix}${child.name}` })
          addFolders(child.id, `${prefix}  `)
        }
      })
    }

    addFolders(null)
    return options
  }

  const parentOptions = getParentOptions()

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {/* Parent Selection */}
      {!parentId && (
        <div>
          <Label htmlFor="parent_id">Parent</Label>
          <Select
            value={formData.parent_id || "root"}
            onValueChange={(value) =>
              setFormData((prev) => ({
                ...prev,
                parent_id: value === "root" ? null : value,
              }))
            }
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {parentOptions.map((option) => (
                <SelectItem key={option.id || "root"} value={option.id || "root"}>
                  {option.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )}

      {/* Show parent if creating in specific folder */}
      {parentId && parentName && (
        <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
          <div className="flex items-center gap-2">
            <Folder className="h-4 w-4 text-blue-600" />
            <span className="text-sm text-blue-800">Creating in: </span>
            <Badge variant="outline" className="bg-blue-100 text-blue-700">
              {parentName}
            </Badge>
          </div>
        </div>
      )}

      {/* Task Type */}
      <div className="flex items-center space-x-2">
        <Checkbox
          id="is_folder"
          checked={formData.is_folder}
          onCheckedChange={(checked) =>
            setFormData((prev) => ({
              ...prev,
              is_folder: checked as boolean,
            }))
          }
        />
        <Label htmlFor="is_folder" className="flex items-center gap-2">
          {formData.is_folder ? (
            <Folder className="h-4 w-4 text-blue-600" />
          ) : (
            <FileText className="h-4 w-4 text-slate-600" />
          )}
          Create as folder (for organizing other tasks)
        </Label>
      </div>

      {/* Folder info */}
      {formData.is_folder && (
        <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg">
          <div className="flex items-start gap-2">
            <AlertCircle className="h-4 w-4 text-amber-600 mt-0.5 flex-shrink-0" />
            <div className="text-sm text-amber-800">
              <p className="font-medium mb-1">Folder Properties:</p>
              <ul className="text-xs space-y-1">
                <li>• Difficulty will be calculated as average of child tasks</li>
                <li>• Discussions and conclusions are aggregated from child tasks</li>
                <li>• Progress is calculated from child task completion</li>
              </ul>
            </div>
          </div>
        </div>
      )}

      <div>
        <Label htmlFor="name">{formData.is_folder ? "Folder" : "Task"} Name *</Label>
        <Input
          id="name"
          value={formData.name}
          onChange={(e) => setFormData((prev) => ({ ...prev, name: e.target.value }))}
          placeholder={`Enter ${formData.is_folder ? "folder" : "task"} name`}
          required
        />
      </div>

      <div>
        <Label htmlFor="description">Description</Label>
        <Textarea
          id="description"
          value={formData.description}
          onChange={(e) => setFormData((prev) => ({ ...prev, description: e.target.value }))}
          placeholder={`Enter ${formData.is_folder ? "folder" : "task"} description`}
          rows={3}
        />
      </div>

      {/* Task-specific fields (not for folders) */}
      {!formData.is_folder && (
        <>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="difficulty">Difficulty</Label>
              <Select
                value={formData.difficulty}
                onValueChange={(value: "Easy" | "Medium" | "Hard") =>
                  setFormData((prev) => ({ ...prev, difficulty: value }))
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Easy">Easy</SelectItem>
                  <SelectItem value="Medium">Medium</SelectItem>
                  <SelectItem value="Hard">Hard</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="days_required">Days Required</Label>
              <Input
                id="days_required"
                type="number"
                min="1"
                value={formData.days_required}
                onChange={(e) =>
                  setFormData((prev) => ({
                    ...prev,
                    days_required: Number.parseInt(e.target.value) || 1,
                  }))
                }
              />
            </div>
          </div>
        </>
      )}

      <div className="flex justify-end gap-3 pt-4">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit" disabled={!formData.name.trim() || isLoading}>
          {isLoading ? "Creating..." : `Create ${formData.is_folder ? "Folder" : "Task"}`}
        </Button>
      </div>
    </form>
  )
}
