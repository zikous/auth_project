"use client"

import { useState, useCallback } from "react"
import { TaskUtils } from "@/lib/utils/task-utils"
import type { ReviewPlan, Task, Discussion, Conclusion } from "@/lib/types"

export function useTaskManagement(initialPlan: ReviewPlan, onPlanUpdate?: (plan: ReviewPlan) => void) {
  const [plan, setPlan] = useState<ReviewPlan>(initialPlan)
  const [selectedTask, setSelectedTask] = useState<Task | null>(null)

  const updatePlan = useCallback(
    (updatedPlan: ReviewPlan) => {
      setPlan(updatedPlan)
      onPlanUpdate?.(updatedPlan)
    },
    [onPlanUpdate],
  )

  const createTask = useCallback(
    async (taskData: any) => {
      const newTask: Task = {
        id: TaskUtils.generateTaskId(taskData.is_folder, plan.tasks),
        plan_id: plan.id,
        completed: false,
        discussions: [],
        conclusions: [],
        ...taskData,
      }

      const updatedPlan = {
        ...plan,
        tasks: [...plan.tasks, newTask],
      }
      updatePlan(updatedPlan)
      return newTask
    },
    [plan, updatePlan],
  )

  const updateTask = useCallback(
    (taskId: string, updates: Partial<Task>) => {
      const updatedTasks = plan.tasks.map((task) => (task.id === taskId ? { ...task, ...updates } : task))
      const updatedPlan = { ...plan, tasks: updatedTasks }
      updatePlan(updatedPlan)

      if (selectedTask?.id === taskId) {
        const updatedSelectedTask = updatedTasks.find((t) => t.id === taskId)
        setSelectedTask(updatedSelectedTask || null)
      }
    },
    [plan, selectedTask, updatePlan],
  )

  const deleteTask = useCallback(
    (taskId: string) => {
      const taskIdsToDelete = [taskId, ...TaskUtils.getAllDescendants(taskId, plan.tasks).map((t) => t.id)]
      const updatedTasks = plan.tasks.filter((task) => !taskIdsToDelete.includes(task.id))
      const updatedPlan = { ...plan, tasks: updatedTasks }
      updatePlan(updatedPlan)

      if (selectedTask && taskIdsToDelete.includes(selectedTask.id)) {
        setSelectedTask(null)
      }
    },
    [plan, selectedTask, updatePlan],
  )

  const toggleTaskCompletion = useCallback(
    (taskId: string) => {
      const task = plan.tasks.find((t) => t.id === taskId)
      if (!task || !TaskUtils.isLeafTask(taskId, plan.tasks)) return

      const newCompleted = !task.completed
      updateTask(taskId, { completed: newCompleted })
    },
    [plan.tasks, updateTask],
  )

  const addDiscussion = useCallback(
    (taskId: string, message: string) => {
      const newDiscussion: Discussion = {
        id: `DISC-${Date.now()}`,
        message,
        timestamp: new Date().toISOString(),
        task_id: taskId,
      }

      const task = plan.tasks.find((t) => t.id === taskId)
      if (task) {
        updateTask(taskId, {
          discussions: [...(task.discussions || []), newDiscussion],
        })
      }
    },
    [plan.tasks, updateTask],
  )

  const addConclusion = useCallback(
    (taskId: string, message: string) => {
      const task = plan.tasks.find((t) => t.id === taskId)
      if (!task) return

      const newConclusion: Conclusion = {
        id: `CONC-${Date.now()}`,
        message,
        timestamp: new Date().toISOString(),
        version: (task.conclusions?.length || 0) + 1,
        task_id: taskId,
      }

      updateTask(taskId, {
        conclusions: [...(task.conclusions || []), newConclusion],
      })
    },
    [plan.tasks, updateTask],
  )

  // Computed values
  const getTaskCompletionPercentage = useCallback(
    (taskId: string) => TaskUtils.calculateCompletionPercentage(taskId, plan.tasks),
    [plan.tasks],
  )

  const getLeafTaskCount = useCallback(() => TaskUtils.getLeafTasks(plan.tasks).length, [plan.tasks])

  const getCompletedLeafTaskCount = useCallback(() => TaskUtils.getCompletedLeafTasks(plan.tasks).length, [plan.tasks])

  const isLeafTask = useCallback((taskId: string) => TaskUtils.isLeafTask(taskId, plan.tasks), [plan.tasks])

  return {
    plan,
    selectedTask,
    setSelectedTask,
    createTask,
    updateTask,
    deleteTask,
    toggleTaskCompletion,
    addDiscussion,
    addConclusion,
    getTaskCompletionPercentage,
    getLeafTaskCount,
    getCompletedLeafTaskCount,
    isLeafTask,
  }
}
