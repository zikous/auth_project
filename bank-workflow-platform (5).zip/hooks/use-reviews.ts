"use client"

import { useState, useEffect } from "react"
import { api } from "@/lib/api/mock-api"
import type { Review } from "@/lib/types"

export function useReviews() {
  const [reviews, setReviews] = useState<Review[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchReviews = async () => {
    try {
      setLoading(true)
      setError(null)
      const response = await api.reviews.getAll()
      if (response.success) {
        setReviews(response.data)
      } else {
        setError(response.error || "Failed to fetch reviews")
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unknown error occurred")
    } finally {
      setLoading(false)
    }
  }

  const createReview = async (reviewData: Partial<Review>) => {
    try {
      const response = await api.reviews.create(reviewData)
      if (response.success) {
        setReviews((prev) => [...prev, response.data])
        return { success: true, data: response.data }
      } else {
        return { success: false, error: response.error }
      }
    } catch (err) {
      const error = err instanceof Error ? err.message : "Unknown error occurred"
      return { success: false, error }
    }
  }

  const updateReview = async (id: string, updates: Partial<Review>) => {
    try {
      const response = await api.reviews.update(id, updates)
      if (response.success) {
        setReviews((prev) => prev.map((r) => (r.id === id ? response.data : r)))
        return { success: true, data: response.data }
      } else {
        return { success: false, error: response.error }
      }
    } catch (err) {
      const error = err instanceof Error ? err.message : "Unknown error occurred"
      return { success: false, error }
    }
  }

  const deleteReview = async (id: string) => {
    try {
      const response = await api.reviews.delete(id)
      if (response.success) {
        setReviews((prev) => prev.filter((r) => r.id !== id))
        return { success: true }
      } else {
        return { success: false, error: response.error }
      }
    } catch (err) {
      const error = err instanceof Error ? err.message : "Unknown error occurred"
      return { success: false, error }
    }
  }

  const deleteMultipleReviews = async (ids: string[]) => {
    try {
      const results = await Promise.all(ids.map((id) => api.reviews.delete(id)))
      const successful = results.filter((r) => r.success)
      if (successful.length > 0) {
        setReviews((prev) => prev.filter((r) => !ids.includes(r.id)))
      }
      return { success: successful.length === ids.length, deletedCount: successful.length }
    } catch (err) {
      const error = err instanceof Error ? err.message : "Unknown error occurred"
      return { success: false, error }
    }
  }

  useEffect(() => {
    fetchReviews()
  }, [])

  return {
    reviews,
    loading,
    error,
    createReview,
    updateReview,
    deleteReview,
    deleteMultipleReviews,
    refetch: fetchReviews,
  }
}
