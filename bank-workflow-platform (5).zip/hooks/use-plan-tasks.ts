"use client"

import React, { useState, useCallback } from "react"
import type { ReviewPlan, Task, Discussion, Conclusion } from "@/lib/types"

export function usePlanTasks(initialPlan: ReviewPlan) {
  const [plan, setPlan] = useState<ReviewPlan>(initialPlan)
  const [selectedTask, setSelectedTask] = useState<Task | null>(null)

  const updatePlan = useCallback((updatedPlan: ReviewPlan) => {
    setPlan(updatedPlan)
  }, [])

  // Get all leaf tasks (executable tasks) under a parent
  const getLeafTasksUnderParent = useCallback((tasks: Task[], parentId: string): Task[] => {
    const getAllDescendants = (taskId: string): Task[] => {
      const children = tasks.filter((task) => task.parent_id === taskId)
      let allDescendants: Task[] = []

      children.forEach((child) => {
        const hasChildren = tasks.some((t) => t.parent_id === child.id)
        if (!hasChildren && !child.is_folder) {
          allDescendants.push(child)
        } else {
          allDescendants = allDescendants.concat(getAllDescendants(child.id))
        }
      })

      return allDescendants
    }

    return getAllDescendants(parentId)
  }, [])

  // Calculate completion percentage for parent tasks based only on leaf tasks
  const calculateParentCompletion = useCallback(
    (tasks: Task[], parentId: string): number => {
      const leafTasks = getLeafTasksUnderParent(tasks, parentId)
      if (leafTasks.length === 0) return 0

      const completedLeafTasks = leafTasks.filter((task) => task.completed).length
      return Math.round((completedLeafTasks / leafTasks.length) * 100)
    },
    [getLeafTasksUnderParent],
  )

  const createTask = useCallback(
    (taskData: Omit<Task, "id" | "plan_id" | "completed" | "discussions" | "conclusions">) => {
      React.startTransition(() => {
        const newTask: Task = {
          id: taskData.is_folder
            ? `FLD-${String(plan.tasks.length + 1).padStart(3, "0")}`
            : `TSK-${String(plan.tasks.length + 1).padStart(3, "0")}`,
          plan_id: plan.id,
          completed: false,
          discussions: [],
          conclusions: [],
          ...taskData,
        }

        const updatedPlan = {
          ...plan,
          tasks: [...plan.tasks, newTask],
        }
        setPlan(updatedPlan)
      })
    },
    [plan],
  )

  const updateTask = useCallback(
    (taskId: string, updates: Partial<Task>) => {
      const updatedTasks = plan.tasks.map((task) => (task.id === taskId ? { ...task, ...updates } : task))
      const updatedPlan = { ...plan, tasks: updatedTasks }
      setPlan(updatedPlan)

      if (selectedTask?.id === taskId) {
        const updatedSelectedTask = updatedTasks.find((t) => t.id === taskId)
        setSelectedTask(updatedSelectedTask || null)
      }
    },
    [plan, selectedTask],
  )

  const deleteTask = useCallback(
    (taskId: string) => {
      const getChildTaskIds = (parentId: string): string[] => {
        const children = plan.tasks.filter((task) => task.parent_id === parentId)
        let allChildIds = children.map((child) => child.id)
        children.forEach((child) => {
          allChildIds = allChildIds.concat(getChildTaskIds(child.id))
        })
        return allChildIds
      }

      const taskIdsToDelete = [taskId, ...getChildTaskIds(taskId)]
      const updatedTasks = plan.tasks.filter((task) => !taskIdsToDelete.includes(task.id))
      const updatedPlan = { ...plan, tasks: updatedTasks }
      setPlan(updatedPlan)

      if (selectedTask && taskIdsToDelete.includes(selectedTask.id)) {
        setSelectedTask(null)
      }
    },
    [plan, selectedTask],
  )

  const toggleTaskCompletion = useCallback(
    (taskId: string) => {
      const task = plan.tasks.find((t) => t.id === taskId)
      if (!task) return

      const hasChildren = plan.tasks.some((t) => t.parent_id === taskId)
      if (hasChildren) return

      const newCompleted = !task.completed
      const updatedTasks = plan.tasks.map((t) => (t.id === taskId ? { ...t, completed: newCompleted } : t))
      const updatedPlan = { ...plan, tasks: updatedTasks }
      setPlan(updatedPlan)

      if (selectedTask?.id === taskId) {
        const updatedSelectedTask = updatedTasks.find((t) => t.id === taskId)
        setSelectedTask(updatedSelectedTask || null)
      }
    },
    [plan, selectedTask],
  )

  const addDiscussion = useCallback(
    (taskId: string, message: string) => {
      const newDiscussion: Discussion = {
        id: `DISC-${Date.now()}`,
        author: "Current User",
        message,
        timestamp: new Date().toISOString(),
        task_id: taskId,
      }

      const updatedTasks = plan.tasks.map((task) =>
        task.id === taskId ? { ...task, discussions: [...task.discussions, newDiscussion] } : task,
      )
      const updatedPlan = { ...plan, tasks: updatedTasks }
      setPlan(updatedPlan)

      if (selectedTask?.id === taskId) {
        setSelectedTask({ ...selectedTask, discussions: [...selectedTask.discussions, newDiscussion] })
      }
    },
    [plan, selectedTask],
  )

  const addConclusion = useCallback(
    (taskId: string, message: string) => {
      const task = plan.tasks.find((t) => t.id === taskId)
      const newConclusion: Conclusion = {
        id: `CONC-${Date.now()}`,
        author: "Current User",
        message,
        timestamp: new Date().toISOString(),
        version: (task?.conclusions.length || 0) + 1,
        task_id: taskId,
      }

      const updatedTasks = plan.tasks.map((task) =>
        task.id === taskId ? { ...task, conclusions: [...task.conclusions, newConclusion] } : task,
      )
      const updatedPlan = { ...plan, tasks: updatedTasks }
      setPlan(updatedPlan)

      if (selectedTask?.id === taskId) {
        setSelectedTask({ ...selectedTask, conclusions: [...selectedTask.conclusions, newConclusion] })
      }
    },
    [plan, selectedTask],
  )

  const selectTask = useCallback((task: Task) => {
    setSelectedTask(task)
  }, [])

  const getTaskCompletionPercentage = useCallback(
    (taskId: string): number => {
      return calculateParentCompletion(plan.tasks, taskId)
    },
    [plan.tasks, calculateParentCompletion],
  )

  const getLeafTaskCount = useCallback((): number => {
    return plan.tasks.filter((task) => {
      const hasChildren = plan.tasks.some((t) => t.parent_id === task.id)
      return !task.is_folder && !hasChildren
    }).length
  }, [plan.tasks])

  const getCompletedLeafTaskCount = useCallback((): number => {
    return plan.tasks.filter((task) => {
      const hasChildren = plan.tasks.some((t) => t.parent_id === task.id)
      return !task.is_folder && !hasChildren && task.completed
    }).length
  }, [plan.tasks])

  return {
    plan,
    selectedTask,
    updatePlan,
    createTask,
    updateTask,
    deleteTask,
    toggleTaskCompletion,
    addDiscussion,
    addConclusion,
    selectTask,
    getTaskCompletionPercentage,
    getLeafTaskCount,
    getCompletedLeafTaskCount,
  }
}
