"use client"

import { useState, useMemo } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { MessageSquare, GitCommit, AlertCircle, FolderOpen, FileText, Send, Bot } from "lucide-react"
import type { Task, ReviewPlan, TaskAggregation } from "@/lib/types"
import { AIReportGenerator } from "@/components/tasks/ai-report-generator"
import { useToast } from "@/hooks/use-toast"

interface TaskDetailsPanelProps {
  task: Task | null
  plan: ReviewPlan
  aggregation: TaskAggregation | null
  isLeafTask: boolean
  onAddDiscussion: (taskId: string, message: string) => void
  onAddConclusion: (taskId: string, message: string) => void
  getTaskCompletionPercentage: (taskId: string) => number
  getTaskDifficulty: (taskId: string) => "Easy" | "Medium" | "Hard" | null
}

export function TaskDetailsPanel({
  task,
  plan,
  aggregation,
  isLeafTask,
  onAddDiscussion,
  onAddConclusion,
  getTaskCompletionPercentage,
}: TaskDetailsPanelProps) {
  const [newDiscussion, setNewDiscussion] = useState("")
  const [newConclusion, setNewConclusion] = useState("")
  const { toast } = useToast()

  const computedValues = useMemo(() => {
    if (!task) {
      return {
        isFolder: false,
        discussions: [],
        conclusions: [],
        childTasks: [],
        completionPercentage: 0,
        discussionsByTask: null,
        conclusionsByTask: null,
      }
    }

    const isFolder = !isLeafTask
    const discussions = isFolder ? aggregation?.discussions || [] : task?.discussions || []
    const conclusions = isFolder ? aggregation?.conclusions || [] : task?.conclusions || []
    const childTasks = aggregation?.childTasks || []
    const completionPercentage = isFolder ? getTaskCompletionPercentage(task.id) : 0

    const discussionsByTask = isFolder
      ? discussions.reduce(
          (acc, discussion) => {
            const taskId = discussion?.task_id || "unknown"
            if (!acc[taskId]) {
              acc[taskId] = []
            }
            acc[taskId].push(discussion)
            return acc
          },
          {} as Record<string, typeof discussions>,
        )
      : null

    const conclusionsByTask = isFolder
      ? conclusions.reduce(
          (acc, conclusion) => {
            const taskId = conclusion?.task_id || "unknown"
            if (!acc[taskId]) {
              acc[taskId] = []
            }
            acc[taskId].push(conclusion)
            return acc
          },
          {} as Record<string, typeof conclusions>,
        )
      : null

    return {
      isFolder,
      discussions,
      conclusions,
      childTasks,
      completionPercentage,
      discussionsByTask,
      conclusionsByTask,
    }
  }, [task, isLeafTask, aggregation, getTaskCompletionPercentage])

  const { isFolder, discussions, conclusions, childTasks, completionPercentage, discussionsByTask, conclusionsByTask } =
    computedValues

  const handleAddDiscussion = () => {
    if (!newDiscussion.trim() || !task?.id) return
    onAddDiscussion(task.id, newDiscussion.trim())
    setNewDiscussion("")
    toast({ title: "Discussion added" })
  }

  const handleAddConclusion = () => {
    if (!newConclusion.trim() || !task?.id) return
    onAddConclusion(task.id, newConclusion.trim())
    setNewConclusion("")
    toast({ title: "Conclusion added" })
  }

  if (!task) {
    return (
      <Card className="w-full">
        <CardContent className="p-8 text-center text-slate-500">
          <AlertCircle className="h-8 w-8 mx-auto mb-3 opacity-30" />
          <p>Select a task to view details</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className="w-full">
      <CardHeader className="border-b">
        <div className="flex items-start gap-3 w-full">
          {isLeafTask ? (
            <FileText className="h-5 w-5 text-slate-600 mt-0.5 flex-shrink-0" />
          ) : (
            <FolderOpen className="h-5 w-5 text-blue-600 mt-0.5 flex-shrink-0" />
          )}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1 flex-wrap">
              <span className="text-sm font-mono text-slate-500">{task.id}</span>
              <Badge
                variant="outline"
                className={isLeafTask ? "bg-green-50 text-green-700" : "bg-blue-50 text-blue-700"}
              >
                {isLeafTask ? "Task" : "Folder"}
              </Badge>
              {isFolder && (
                <>
                  <Badge variant="secondary" className="bg-slate-100 text-slate-700">
                    {childTasks.length} items
                  </Badge>
                  {discussions.length > 0 && (
                    <Badge variant="secondary" className="bg-orange-100 text-orange-700">
                      <MessageSquare className="h-3 w-3 mr-1" />
                      {discussions.length} discussions
                    </Badge>
                  )}
                  {conclusions.length > 0 && (
                    <Badge variant="secondary" className="bg-purple-100 text-purple-700">
                      <GitCommit className="h-3 w-3 mr-1" />
                      {conclusions.length} conclusions
                    </Badge>
                  )}
                </>
              )}
            </div>
            <CardTitle className="text-lg break-words">{task.name}</CardTitle>
            <p className="text-sm text-slate-600 mt-1 break-words">{task.description}</p>
          </div>
        </div>
      </CardHeader>

      <CardContent className="p-6 w-full">
        {/* Progress for folders */}
        {!isLeafTask && (
          <div className="mb-6 p-4 bg-slate-50 rounded-lg w-full">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium">Progress</span>
              <span className="text-sm text-slate-600">{completionPercentage}%</span>
            </div>
            <Progress value={completionPercentage} className="h-2 w-full" />
            <p className="text-xs text-slate-500 mt-1">{childTasks.length} child items</p>
          </div>
        )}

        {/* Aggregation Status for Folders */}
        {isFolder && (
          <div className="mb-4 p-3 bg-blue-50 rounded-lg border border-blue-200 w-full">
            <div className="flex items-center gap-2 mb-1">
              <FolderOpen className="h-4 w-4 text-blue-600" />
              <span className="text-sm font-medium text-blue-800">Aggregated View</span>
            </div>
            <p className="text-xs text-blue-700">
              Showing {discussions.length} discussions and {conclusions.length} conclusions from all child tasks
            </p>
          </div>
        )}

        {/* Tabs */}
        <div className="w-full">
          <Tabs defaultValue="discussion" className="w-full">
            <TabsList className={`grid w-full ${isLeafTask ? "grid-cols-3" : "grid-cols-2"}`}>
              <TabsTrigger value="discussion">
                <MessageSquare className="h-4 w-4 mr-1" />
                Discussion ({discussions.length})
              </TabsTrigger>
              <TabsTrigger value="conclusions">
                <GitCommit className="h-4 w-4 mr-1" />
                Conclusions ({conclusions.length})
              </TabsTrigger>
              {/* Only show AI Report tab for individual tasks, not folders */}
              {isLeafTask && (
                <TabsTrigger value="ai-report">
                  <Bot className="h-4 w-4 mr-1" />
                  AI Report
                </TabsTrigger>
              )}
            </TabsList>

            <TabsContent value="discussion" className="mt-4 w-full">
              <div className="space-y-4 w-full">
                <div className="flex justify-between items-center">
                  <h4 className="font-medium">
                    {isFolder ? "Aggregated Discussions from Child Tasks" : "Task Discussions"}
                  </h4>
                </div>

                <ScrollArea className="h-64 border rounded p-3 w-full">
                  {discussions.length > 0 ? (
                    <div className="space-y-3 w-full">
                      {isFolder && discussionsByTask
                        ? Object.entries(discussionsByTask).map(([taskId, taskDiscussions]) => (
                            <div key={taskId} className="space-y-2 w-full">
                              <div className="flex items-center gap-2 py-1">
                                <Badge variant="outline" className="text-xs font-mono bg-blue-50 text-blue-700">
                                  {taskId}
                                </Badge>
                                <span className="text-xs text-slate-500">
                                  {taskDiscussions.length} discussion{taskDiscussions.length !== 1 ? "s" : ""}
                                </span>
                              </div>
                              {taskDiscussions.map((discussion, index) => (
                                <div
                                  key={discussion?.id || `${taskId}-${index}`}
                                  className="ml-4 pb-2 border-l-2 border-blue-200 pl-3 w-full"
                                >
                                  <div className="flex items-center gap-2 mb-1">
                                    <span className="text-xs text-slate-500">
                                      {discussion?.timestamp
                                        ? new Date(discussion.timestamp).toLocaleString()
                                        : "Unknown time"}
                                    </span>
                                  </div>
                                  <p className="text-sm text-slate-700 break-words">
                                    {discussion?.message || "No message"}
                                  </p>
                                </div>
                              ))}
                              <Separator className="my-3" />
                            </div>
                          ))
                        : discussions.map((discussion, index) => (
                            <div key={discussion?.id || index} className="pb-3 border-b last:border-b-0 w-full">
                              <div className="flex items-center gap-2 mb-1">
                                <span className="text-xs text-slate-500">
                                  {discussion?.timestamp
                                    ? new Date(discussion.timestamp).toLocaleString()
                                    : "Unknown time"}
                                </span>
                              </div>
                              <p className="text-sm text-slate-700 break-words">
                                {discussion?.message || "No message"}
                              </p>
                            </div>
                          ))}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-slate-500">
                      <MessageSquare className="h-8 w-8 mx-auto mb-2 opacity-30" />
                      <p className="text-sm">{isFolder ? "No discussions in child tasks yet" : "No discussions yet"}</p>
                      <p className="text-xs mt-1">
                        {isFolder
                          ? "Discussions from child tasks will appear here"
                          : "Start a conversation to track progress"}
                      </p>
                    </div>
                  )}
                </ScrollArea>

                {isLeafTask && (
                  <div className="space-y-2 w-full">
                    <Textarea
                      placeholder="Add a discussion point..."
                      value={newDiscussion}
                      onChange={(e) => setNewDiscussion(e.target.value)}
                      rows={3}
                      className="w-full resize-none"
                    />
                    <Button onClick={handleAddDiscussion} disabled={!newDiscussion.trim()} className="w-full">
                      <Send className="h-4 w-4 mr-2" />
                      Add Discussion
                    </Button>
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="conclusions" className="mt-4 w-full">
              <div className="space-y-4 w-full">
                <div className="flex justify-between items-center">
                  <h4 className="font-medium">
                    {isFolder ? "Aggregated Conclusions from Child Tasks" : "Task Conclusions"}
                  </h4>
                </div>

                <ScrollArea className="h-64 border rounded p-3 w-full">
                  {conclusions.length > 0 ? (
                    <div className="space-y-3 w-full">
                      {isFolder && conclusionsByTask
                        ? Object.entries(conclusionsByTask).map(([taskId, taskConclusions]) => (
                            <div key={taskId} className="space-y-2 w-full">
                              <div className="flex items-center gap-2 py-1">
                                <Badge variant="outline" className="text-xs font-mono bg-green-50 text-green-700">
                                  {taskId}
                                </Badge>
                                <span className="text-xs text-slate-500">
                                  {taskConclusions.length} conclusion{taskConclusions.length !== 1 ? "s" : ""}
                                </span>
                              </div>
                              {taskConclusions.map((conclusion, index) => (
                                <div
                                  key={conclusion?.id || `${taskId}-${index}`}
                                  className="ml-4 pb-2 border-l-2 border-green-200 pl-3 w-full"
                                >
                                  <div className="flex items-center gap-2 mb-1">
                                    <span className="text-sm font-medium">v{conclusion?.version || index + 1}</span>
                                    <span className="text-xs text-slate-500">
                                      {conclusion?.timestamp
                                        ? new Date(conclusion.timestamp).toLocaleString()
                                        : "Unknown time"}
                                    </span>
                                  </div>
                                  <p className="text-sm text-slate-700 break-words">
                                    {conclusion?.message || "No message"}
                                  </p>
                                </div>
                              ))}
                              <Separator className="my-3" />
                            </div>
                          ))
                        : conclusions.map((conclusion, index) => (
                            <div key={conclusion?.id || index} className="pb-3 border-b last:border-b-0 w-full">
                              <div className="flex items-center gap-2 mb-1">
                                <span className="text-sm font-medium">v{conclusion?.version || index + 1}</span>
                                <span className="text-xs text-slate-500">
                                  {conclusion?.timestamp
                                    ? new Date(conclusion.timestamp).toLocaleString()
                                    : "Unknown time"}
                                </span>
                              </div>
                              <p className="text-sm text-slate-700 break-words">
                                {conclusion?.message || "No message"}
                              </p>
                            </div>
                          ))}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-slate-500">
                      <GitCommit className="h-8 w-8 mx-auto mb-2 opacity-30" />
                      <p className="text-sm">{isFolder ? "No conclusions in child tasks yet" : "No conclusions yet"}</p>
                      <p className="text-xs mt-1">
                        {isFolder
                          ? "Conclusions from child tasks will appear here"
                          : "Document key decisions and outcomes"}
                      </p>
                    </div>
                  )}
                </ScrollArea>

                {isLeafTask && (
                  <div className="space-y-2 w-full">
                    <Textarea
                      placeholder="Add a conclusion..."
                      value={newConclusion}
                      onChange={(e) => setNewConclusion(e.target.value)}
                      rows={3}
                      className="w-full resize-none"
                    />
                    <Button onClick={handleAddConclusion} disabled={!newConclusion.trim()} className="w-full">
                      <GitCommit className="h-4 w-4 mr-2" />
                      Add Conclusion
                    </Button>
                  </div>
                )}
              </div>
            </TabsContent>

            {/* Only render AI Report tab content for individual tasks */}
            {isLeafTask && (
              <TabsContent value="ai-report" className="mt-4 w-full">
                <div className="w-full">
                  <AIReportGenerator
                    task={task}
                    plan={plan}
                    aggregation={aggregation}
                    getTaskCompletionPercentage={getTaskCompletionPercentage}
                  />
                </div>
              </TabsContent>
            )}
          </Tabs>
        </div>
      </CardContent>
    </Card>
  )
}
