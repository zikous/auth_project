"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ProgressRing } from "@/components/ui/progress-ring"
import {
  ChevronDown,
  ChevronRight,
  Edit,
  Trash2,
  CheckSquare,
  Square,
  Calendar,
  MessageSquare,
  GitCommit,
  FolderOpen,
  FileText,
  MoreHorizontal,
  Play,
  Pause,
} from "lucide-react"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import type { Task } from "@/lib/types"

interface EnhancedTaskTreeProps {
  tasks: Task[]
  onTaskSelect: (task: Task) => void
  onTaskEdit: (task: Task) => void
  onTaskDelete: (id: string) => void
  onTaskToggle: (id: string) => void
  selectedTaskId?: string
  getTaskCompletionPercentage: (taskId: string) => number
  getTaskDifficulty: (taskId: string) => "Easy" | "Medium" | "Hard" | null
  isLeafTask: (taskId: string) => boolean
}

export function EnhancedTaskTree({
  tasks,
  onTaskSelect,
  onTaskEdit,
  onTaskDelete,
  onTaskToggle,
  selectedTaskId,
  getTaskCompletionPercentage,
  getTaskDifficulty,
  isLeafTask,
}: EnhancedTaskTreeProps) {
  const [expandedNodes, setExpandedNodes] = useState<Set<string>>(new Set())

  const toggleExpanded = (taskId: string) => {
    const newExpanded = new Set(expandedNodes)
    if (newExpanded.has(taskId)) {
      newExpanded.delete(taskId)
    } else {
      newExpanded.add(taskId)
    }
    setExpandedNodes(newExpanded)
  }

  const getChildTasks = (parentId: string | null) => {
    return tasks.filter((task) => task.parent_id === parentId)
  }

  const hasChildren = (taskId: string) => {
    return tasks.some((task) => task.parent_id === taskId)
  }

  const isFolder = (task: Task) => {
    return task.is_folder === true || hasChildren(task.id)
  }

  const isExecutableTask = (task: Task) => {
    return !task.is_folder && !hasChildren(task.id)
  }

  // Get aggregated discussion/conclusion counts for folders
  const getAggregatedCounts = (taskId: string) => {
    const getAllDescendants = (parentId: string): Task[] => {
      const descendants: Task[] = []
      const children = getChildTasks(parentId)

      children.forEach((child) => {
        descendants.push(child)
        descendants.push(...getAllDescendants(child.id))
      })

      return descendants
    }

    const descendants = getAllDescendants(taskId)
    const totalDiscussions = descendants.reduce((sum, task) => sum + (task.discussions?.length || 0), 0)
    const totalConclusions = descendants.reduce((sum, task) => sum + (task.conclusions?.length || 0), 0)

    return { totalDiscussions, totalConclusions }
  }

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Easy":
        return "bg-emerald-100 text-emerald-700 border-emerald-200"
      case "Medium":
        return "bg-amber-100 text-amber-700 border-amber-200"
      case "Hard":
        return "bg-red-100 text-red-700 border-red-200"
      default:
        return "bg-gray-100 text-gray-700 border-gray-200"
    }
  }

  const getDifficultyEmoji = (difficulty: string) => {
    switch (difficulty) {
      case "Easy":
        return "🟢"
      case "Medium":
        return "🟡"
      case "Hard":
        return "🔴"
      default:
        return "⚪"
    }
  }

  const renderTask = (task: Task, level = 0) => {
    const children = getChildTasks(task.id)
    const isExpanded = expandedNodes.has(task.id)
    const isSelected = selectedTaskId === task.id
    const isParent = hasChildren(task.id)
    const isFolderItem = isFolder(task)
    const isTaskItem = isExecutableTask(task)
    const completionPercentage = isParent ? getTaskCompletionPercentage(task.id) : 0
    const taskDifficulty = getTaskDifficulty(task.id)

    // Get aggregated counts for folders
    const { totalDiscussions, totalConclusions } = isFolderItem
      ? getAggregatedCounts(task.id)
      : {
          totalDiscussions: task.discussions?.length || 0,
          totalConclusions: task.conclusions?.length || 0,
        }

    return (
      <div key={task.id} className="w-full">
        <div
          className={`group relative flex items-center gap-3 p-4 rounded-xl transition-all duration-200 cursor-pointer border-2 hover:shadow-md ${
            isSelected
              ? "bg-blue-50 border-blue-200 shadow-lg ring-2 ring-blue-100"
              : "border-transparent hover:border-slate-200 hover:bg-slate-50"
          } ${isFolderItem ? "bg-gradient-to-r from-blue-50/50 to-blue-100/50" : ""}`}
          style={{ marginLeft: `${level * 24}px` }}
          onClick={() => onTaskSelect(task)}
        >
          {/* Expand/Collapse Button */}
          <div className="flex items-center">
            {isParent ? (
              <Button
                variant="ghost"
                size="sm"
                className="h-8 w-8 p-0 hover:bg-slate-200 rounded-full"
                onClick={(e) => {
                  e.stopPropagation()
                  toggleExpanded(task.id)
                }}
              >
                {isExpanded ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
              </Button>
            ) : (
              <div className="w-8" />
            )}
          </div>

          {/* Item Icon & Progress */}
          <div className="flex items-center gap-2">
            {isFolderItem ? (
              <div className="flex items-center gap-2">
                <FolderOpen className="h-5 w-5 text-blue-600" />
                {isParent && <ProgressRing progress={completionPercentage} size="sm" showText={false} />}
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <FileText className="h-5 w-5 text-green-600" />
                {/* Completion Checkbox */}
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-6 w-6 p-0 hover:bg-slate-200 rounded"
                  onClick={(e) => {
                    e.stopPropagation()
                    onTaskToggle(task.id)
                  }}
                >
                  {task.completed ? (
                    <CheckSquare className="h-4 w-4 text-green-600" />
                  ) : (
                    <Square className="h-4 w-4 text-slate-400" />
                  )}
                </Button>
              </div>
            )}
          </div>

          {/* Task Content */}
          <div className="flex-1 min-w-0 space-y-2">
            {/* Task Header */}
            <div className="flex items-center gap-2 flex-wrap">
              <Badge variant="outline" className="text-xs font-mono bg-white">
                {task.id}
              </Badge>

              <span
                className={`text-sm font-semibold truncate ${
                  task.completed ? "line-through text-muted-foreground" : "text-slate-900"
                }`}
              >
                {task.name}
              </span>

              {/* Type Badge */}
              {isFolderItem ? (
                <Badge className="text-xs bg-blue-100 text-blue-700 border-blue-200">📁 Folder</Badge>
              ) : (
                <Badge className="text-xs bg-green-100 text-green-700 border-green-200">📋 Task</Badge>
              )}

              {/* Difficulty Badge */}
              {taskDifficulty && (
                <Badge className={`text-xs ${getDifficultyColor(taskDifficulty)}`}>
                  {getDifficultyEmoji(taskDifficulty)} {taskDifficulty}
                </Badge>
              )}

              {/* Status Badge */}
              {task.completed && (
                <Badge className="text-xs bg-green-100 text-green-700 border-green-200">✅ Complete</Badge>
              )}
            </div>

            {/* Progress Bar for Folders */}
            {isFolderItem && isParent && (
              <div className="flex items-center gap-3">
                <div className="flex-1 bg-slate-200 rounded-full h-2">
                  <div
                    className="bg-gradient-to-r from-blue-500 to-green-500 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${completionPercentage}%` }}
                  />
                </div>
                <span className="text-xs font-semibold text-slate-600 min-w-[3rem]">{completionPercentage}%</span>
              </div>
            )}

            {/* Item Details */}
            <div className="flex items-center gap-4 text-xs text-muted-foreground">
              {/* Days Required */}
              {isTaskItem && task.days_required > 0 && (
                <div className="flex items-center gap-1">
                  <Calendar className="h-3 w-3" />
                  <span>{task.days_required}d</span>
                </div>
              )}

              {/* Discussion and Conclusion Counts with aggregation indicator */}
              {totalDiscussions > 0 && (
                <div className="flex items-center gap-1">
                  <MessageSquare className="h-3 w-3 text-blue-500" />
                  <span>{totalDiscussions}</span>
                  {isFolderItem && <span className="text-xs opacity-75">(agg)</span>}
                </div>
              )}

              {totalConclusions > 0 && (
                <div className="flex items-center gap-1">
                  <GitCommit className="h-3 w-3 text-green-500" />
                  <span>{totalConclusions}</span>
                  {isFolderItem && <span className="text-xs opacity-75">(agg)</span>}
                </div>
              )}
            </div>
          </div>

          {/* Action Menu */}
          <div className="opacity-0 group-hover:opacity-100 transition-opacity">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="h-8 w-8 p-0 hover:bg-slate-200">
                  <MoreHorizontal className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                <DropdownMenuItem
                  onClick={(e) => {
                    e.stopPropagation()
                    onTaskEdit(task)
                  }}
                >
                  <Edit className="h-4 w-4 mr-2" />
                  Edit {isFolderItem ? "Folder" : "Task"}
                </DropdownMenuItem>

                {isTaskItem && (
                  <DropdownMenuItem
                    onClick={(e) => {
                      e.stopPropagation()
                      onTaskToggle(task.id)
                    }}
                  >
                    {task.completed ? (
                      <>
                        <Pause className="h-4 w-4 mr-2" />
                        Mark Incomplete
                      </>
                    ) : (
                      <>
                        <Play className="h-4 w-4 mr-2" />
                        Mark Complete
                      </>
                    )}
                  </DropdownMenuItem>
                )}

                <DropdownMenuSeparator />

                <DropdownMenuItem
                  onClick={(e) => {
                    e.stopPropagation()
                    onTaskDelete(task.id)
                  }}
                  className="text-red-600 focus:text-red-600"
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete {isFolderItem ? "Folder" : "Task"}
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>

        {/* Child Tasks */}
        {isExpanded && children.length > 0 && (
          <div className="mt-2 space-y-2">{children.map((child) => renderTask(child, level + 1))}</div>
        )}
      </div>
    )
  }

  const rootTasks = getChildTasks(null)

  return (
    <div className="space-y-3">
      {rootTasks.length > 0 ? (
        rootTasks.map((task) => renderTask(task))
      ) : (
        <div className="text-center py-16 text-muted-foreground">
          <div className="bg-gradient-to-br from-slate-100 to-slate-200 rounded-full w-24 h-24 flex items-center justify-center mx-auto mb-6">
            <CheckSquare className="h-12 w-12 opacity-50" />
          </div>
          <h3 className="text-lg font-semibold mb-2">Ready to get started?</h3>
          <p className="text-sm mb-4">Create your first folder or task to organize your work</p>
          <div className="flex justify-center gap-2">
            <Badge variant="outline" className="text-xs">
              💡 Tip: Start with folders to organize your work
            </Badge>
          </div>
        </div>
      )}
    </div>
  )
}
