"use client"

import { useState } from "react"
import { DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Folder, FileText, MapPin } from "lucide-react"
import { TaskForm } from "@/components/tasks/task-form"
import type { ReviewPlan } from "@/lib/types"

interface SimpleTaskCreatorProps {
  plan: ReviewPlan
  onCreateTask: (taskData: any) => Promise<any>
  onClose: () => void
  isLoading: boolean
  parentId: string | null
  parentName: string
}

export function SimpleTaskCreator({
  plan,
  onCreateTask,
  onClose,
  isLoading,
  parentId,
  parentName,
}: SimpleTaskCreatorProps) {
  const [itemType, setItemType] = useState<"folder" | "task">("task")

  const taskForm = TaskForm({
    plan,
    isFolder: itemType === "folder",
    onSubmit: async (taskData) => {
      await onCreateTask({ ...taskData, parent_id: parentId })
      onClose()
    },
    parentOptions: [], // Not needed for simplified form
  })

  return (
    <>
      <DialogHeader>
        <DialogTitle className="flex items-center gap-2">
          {itemType === "folder" ? (
            <Folder className="h-5 w-5 text-blue-600" />
          ) : (
            <FileText className="h-5 w-5 text-green-600" />
          )}
          Create New {itemType === "folder" ? "Folder" : "Task"}
        </DialogTitle>
        <DialogDescription>Add a new {itemType} to organize your work</DialogDescription>
      </DialogHeader>

      <div className="space-y-6">
        {/* Location Badge */}
        <div className="flex items-center gap-2 p-3 bg-slate-50 rounded-lg">
          <MapPin className="h-4 w-4 text-slate-500" />
          <span className="text-sm text-slate-600">Creating in:</span>
          <Badge variant="outline" className="font-mono">
            {parentName}
          </Badge>
        </div>

        {/* Type Selection */}
        <div className="space-y-3">
          <label className="text-sm font-medium">Item Type</label>
          <div className="grid grid-cols-2 gap-3">
            <Button
              type="button"
              variant={itemType === "folder" ? "default" : "outline"}
              onClick={() => setItemType("folder")}
              className="h-auto p-4 flex flex-col items-center gap-2"
            >
              <Folder className="h-6 w-6" />
              <div className="text-center">
                <div className="font-medium">Folder</div>
                <div className="text-xs opacity-75">Organize tasks</div>
              </div>
            </Button>
            <Button
              type="button"
              variant={itemType === "task" ? "default" : "outline"}
              onClick={() => setItemType("task")}
              className="h-auto p-4 flex flex-col items-center gap-2"
            >
              <FileText className="h-6 w-6" />
              <div className="text-center">
                <div className="font-medium">Task</div>
                <div className="text-xs opacity-75">Executable work</div>
              </div>
            </Button>
          </div>
        </div>

        {/* Simplified Form */}
        {taskForm.form}

        {/* Actions */}
        <div className="flex justify-end gap-3 pt-4 border-t">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={taskForm.formik.handleSubmit} disabled={!taskForm.isValid || isLoading}>
            {isLoading ? "Creating..." : `Create ${itemType === "folder" ? "Folder" : "Task"}`}
          </Button>
        </div>
      </div>
    </>
  )
}
