"use client"

import { useEffect } from "react"
import { InputField, TextareaField } from "@/components/common/form-field"
import { useFormikForm } from "@/lib/hooks/use-formik-form"
import * as Yup from "yup"
import type { Task, ReviewPlan } from "@/lib/types"

interface TaskFormProps {
  task?: Task | null
  plan: ReviewPlan
  isFolder: boolean
  onSubmit: (data: any) => void
  parentOptions: { value: string; label: string; level: number }[]
}

// Simplified validation schema
const simpleTaskValidationSchema = Yup.object({
  name: Yup.string().required("Name is required"),
  description: Yup.string(),
})

export function TaskForm({ task, plan, isFolder, onSubmit, parentOptions }: TaskFormProps) {
  const initialValues = {
    name: task?.name || "",
    description: task?.description || "",
  }

  const formik = useFormikForm({
    initialValues,
    validationSchema: simpleTaskValidationSchema,
    onSubmit: (values) => {
      onSubmit({
        ...values,
        parent_id: task?.parent_id || null,
        assigned_to: task?.assigned_to || "",
        responsible_person: task?.responsible_person || "",
        days_required: task?.days_required || 1,
        difficulty: task?.difficulty || "Medium",
        is_folder: isFolder,
      })
    },
  })

  useEffect(() => {
    if (task) {
      formik.setValues({
        name: task.name,
        description: task.description,
      })
    }
  }, [task])

  return {
    formik,
    isValid: formik.isValid,
    form: (
      <div className="space-y-4">
        <InputField
          name="name"
          label={`${isFolder ? "Folder" : "Task"} Name`}
          placeholder={`Enter ${isFolder ? "folder" : "task"} name`}
          required
          formik={formik}
        />
        <TextareaField
          name="description"
          label="Description"
          placeholder="Brief description"
          rows={4}
          formik={formik}
        />
      </div>
    ),
  }
}
