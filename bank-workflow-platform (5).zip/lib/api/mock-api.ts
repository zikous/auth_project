"use client"

import type { Task, Discussion, Conclusion, ReviewPlan, Review, ApiResponse } from "@/lib/types"

// Simulate network delay
const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms))

// Generate unique IDs
const generateId = (prefix: string) => `${prefix}-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`

// Mock data storage - in a real app, this would be your database
const mockReviewsData: Review[] = [
  {
    id: "RVW-001",
    name: "Quarterly Risk Assessment",
    description: "Comprehensive review of operational risk factors and mitigation strategies for Q4 2024",
    status: "In Progress",
    created_at: "2024-01-01T00:00:00Z",
    updated_at: "2024-01-01T00:00:00Z",
  },
  {
    id: "RVW-002",
    name: "Compliance Documentation Review",
    description: "Annual review of regulatory compliance documentation and procedures",
    status: "Draft",
    created_at: "2024-01-02T00:00:00Z",
    updated_at: "2024-01-02T00:00:00Z",
  },
  {
    id: "RVW-003",
    name: "Customer Data Privacy Audit",
    description: "GDPR compliance audit focusing on customer data handling and privacy controls",
    status: "Completed",
    created_at: "2024-01-03T00:00:00Z",
    updated_at: "2024-01-03T00:00:00Z",
  },
]

const mockPlansData: ReviewPlan[] = [
  {
    id: "PLN-001",
    name: "Q4 Compliance Review",
    description: "Comprehensive quarterly compliance review covering all regulatory requirements",
    attached_reviews: "RVW-001",
    persons_concerned: ["John Smith", "Sarah Johnson", "Michael Brown", "Emily Davis", "David Wilson"],
    validation_status: "In Construction",
    man_days: 45,
    tasks: [
      {
        id: "FLD-001",
        name: "Risk Assessment Framework",
        description:
          "Complete risk assessment and framework development\n\nOrganizational Purpose: Create structured approach to risk assessment\n\nScope Definition: Define methodologies and standards for risk evaluation",
        plan_id: "PLN-001",
        parent_id: null,
        assigned_to: "John Smith",
        responsible_person: "John Smith",
        days_required: 0,
        difficulty: "Medium",
        completed: false,
        discussions: [],
        conclusions: [],
        is_folder: true,
      },
      {
        id: "TSK-001",
        name: "Define Risk Categories",
        description:
          "Categorize different types of credit risks\n\nObjective: Create comprehensive taxonomy of credit risks\n\nDeliverables:\n• Risk category matrix\n• Risk definition document\n• Classification guidelines\n\nAcceptance Criteria:\n• All major risk types identified\n• Clear definitions provided\n• Approved by risk committee",
        plan_id: "PLN-001",
        parent_id: "FLD-001",
        assigned_to: "John Smith",
        days_required: 3,
        difficulty: "Medium",
        completed: true,
        discussions: [
          {
            id: "DISC-001",
            author: "John Smith",
            message: "Initial risk categories identified based on industry standards",
            timestamp: "2024-01-15T10:30:00Z",
            task_id: "TSK-001",
          },
        ],
        conclusions: [
          {
            id: "CONC-001",
            author: "John Smith",
            message: "Risk categories finalized and approved by committee",
            timestamp: "2024-01-17T16:00:00Z",
            version: 1,
            task_id: "TSK-001",
          },
        ],
        is_folder: false,
      },
    ],
  },
]

class MockAPI {
  private async simulateRequest<T>(
    operation: () => T | Promise<T>,
    delayMs = 300,
    errorRate = 0.02,
  ): Promise<ApiResponse<T>> {
    await delay(delayMs)

    // Simulate occasional errors
    if (Math.random() < errorRate) {
      return {
        success: false,
        data: null as any,
        error: "Network error occurred",
      }
    }

    try {
      const data = await operation()
      return {
        success: true,
        data,
        message: "Operation completed successfully",
      }
    } catch (error) {
      return {
        success: false,
        data: null as any,
        error: error instanceof Error ? error.message : "Unknown error",
      }
    }
  }

  // Review operations
  reviews = {
    getAll: (): Promise<ApiResponse<Review[]>> => {
      return this.simulateRequest(() => [...mockReviewsData], 350)
    },

    getById: (reviewId: string): Promise<ApiResponse<Review>> => {
      return this.simulateRequest(() => {
        const review = mockReviewsData.find((r) => r.id === reviewId)
        if (!review) {
          throw new Error("Review not found")
        }
        return review
      }, 300)
    },

    create: (reviewData: Partial<Review>): Promise<ApiResponse<Review>> => {
      return this.simulateRequest(() => {
        if (reviewData.id && mockReviewsData.some((r) => r.id === reviewData.id)) {
          throw new Error("Review ID already exists")
        }

        const newReview: Review = {
          id: reviewData.id || `RVW-${String(mockReviewsData.length + 1).padStart(3, "0")}`,
          name: reviewData.name || "",
          description: reviewData.description || "",
          status: reviewData.status || "Draft",
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        }

        mockReviewsData.push(newReview)
        return newReview
      }, 450)
    },

    update: (reviewId: string, updates: Partial<Review>): Promise<ApiResponse<Review>> => {
      return this.simulateRequest(() => {
        const reviewIndex = mockReviewsData.findIndex((r) => r.id === reviewId)
        if (reviewIndex === -1) {
          throw new Error("Review not found")
        }

        if (updates.id && updates.id !== reviewId && mockReviewsData.some((r) => r.id === updates.id)) {
          throw new Error("Review ID already exists")
        }

        const updatedReview = {
          ...mockReviewsData[reviewIndex],
          ...updates,
          updated_at: new Date().toISOString(),
        }

        mockReviewsData[reviewIndex] = updatedReview
        return updatedReview
      }, 350)
    },

    delete: (reviewId: string): Promise<ApiResponse<boolean>> => {
      return this.simulateRequest(() => {
        const reviewIndex = mockReviewsData.findIndex((r) => r.id === reviewId)
        if (reviewIndex === -1) {
          throw new Error("Review not found")
        }

        mockReviewsData.splice(reviewIndex, 1)
        return true
      }, 250)
    },
  }

  // Plan operations
  plans = {
    getAll: (): Promise<ApiResponse<ReviewPlan[]>> => {
      return this.simulateRequest(() => [...mockPlansData], 400)
    },

    getById: (planId: string): Promise<ApiResponse<ReviewPlan>> => {
      return this.simulateRequest(() => {
        const plan = mockPlansData.find((p) => p.id === planId)
        if (!plan) {
          throw new Error("Plan not found")
        }
        return plan
      }, 300)
    },

    create: (planData: Partial<ReviewPlan>): Promise<ApiResponse<ReviewPlan>> => {
      return this.simulateRequest(() => {
        const newPlan: ReviewPlan = {
          id: `PLN-${String(mockPlansData.length + 1).padStart(3, "0")}`,
          name: planData.name || "",
          description: planData.description || "",
          attached_reviews: planData.attached_reviews || "",
          persons_concerned: planData.persons_concerned || [],
          validation_status: "In Construction",
          man_days: planData.man_days || 0,
          tasks: [],
        }
        mockPlansData.push(newPlan)
        return newPlan
      }, 500)
    },

    update: (planId: string, updates: Partial<ReviewPlan>): Promise<ApiResponse<ReviewPlan>> => {
      return this.simulateRequest(() => {
        const planIndex = mockPlansData.findIndex((p) => p.id === planId)
        if (planIndex === -1) {
          throw new Error("Plan not found")
        }

        const updatedPlan = { ...mockPlansData[planIndex], ...updates }
        mockPlansData[planIndex] = updatedPlan
        return updatedPlan
      }, 400)
    },

    delete: (planId: string): Promise<ApiResponse<boolean>> => {
      return this.simulateRequest(() => {
        const planIndex = mockPlansData.findIndex((p) => p.id === planId)
        if (planIndex === -1) {
          throw new Error("Plan not found")
        }
        mockPlansData.splice(planIndex, 1)
        return true
      }, 300)
    },
  }

  // Task operations
  tasks = {
    create: (taskData: Partial<Task>): Promise<ApiResponse<Task>> => {
      return this.simulateRequest(() => {
        const newTask: Task = {
          id: taskData.is_folder ? generateId("FLD") : generateId("TSK"),
          name: taskData.name || "",
          description: taskData.description || "",
          plan_id: taskData.plan_id || "",
          parent_id: taskData.parent_id || null,
          assigned_to: taskData.assigned_to || "",
          responsible_person: taskData.responsible_person || "",
          days_required: taskData.days_required || 0,
          difficulty: taskData.difficulty || "Medium",
          completed: false,
          discussions: [],
          conclusions: [],
          is_folder: taskData.is_folder || false,
        }
        return newTask
      }, 500)
    },

    update: (taskId: string, updates: Partial<Task>): Promise<ApiResponse<Task>> => {
      return this.simulateRequest(() => {
        // In a real implementation, you'd update the task in the database
        const updatedTask: Task = {
          id: taskId,
          name: updates.name || "",
          description: updates.description || "",
          plan_id: updates.plan_id || "",
          parent_id: updates.parent_id || null,
          assigned_to: updates.assigned_to || "",
          responsible_person: updates.responsible_person || "",
          days_required: updates.days_required || 0,
          difficulty: updates.difficulty || "Medium",
          completed: updates.completed || false,
          discussions: updates.discussions || [],
          conclusions: updates.conclusions || [],
          is_folder: updates.is_folder || false,
        }
        return updatedTask
      }, 400)
    },

    delete: (taskId: string): Promise<ApiResponse<boolean>> => {
      return this.simulateRequest(() => {
        // In a real implementation, you'd delete the task from the database
        return true
      }, 300)
    },

    toggleCompletion: (taskId: string): Promise<ApiResponse<Task>> => {
      return this.simulateRequest(() => {
        // In a real implementation, you'd toggle the task completion in the database
        const updatedTask: Task = {
          id: taskId,
          name: "Updated Task",
          description: "Task description",
          plan_id: "",
          parent_id: null,
          assigned_to: "",
          responsible_person: "",
          days_required: 1,
          difficulty: "Medium",
          completed: true,
          discussions: [],
          conclusions: [],
          is_folder: false,
        }
        return updatedTask
      }, 200)
    },

    addDiscussion: (taskId: string, message: string): Promise<ApiResponse<Discussion>> => {
      return this.simulateRequest(() => {
        const newDiscussion: Discussion = {
          id: generateId("DISC"),
          task_id: taskId,
          author: "Current User",
          message,
          timestamp: new Date().toISOString(),
        }
        return newDiscussion
      }, 250)
    },

    addConclusion: (taskId: string, message: string): Promise<ApiResponse<Conclusion>> => {
      return this.simulateRequest(() => {
        const newConclusion: Conclusion = {
          id: generateId("CONC"),
          task_id: taskId,
          author: "Current User",
          message,
          timestamp: new Date().toISOString(),
          version: 1,
        }
        return newConclusion
      }, 300)
    },
  }
}

export const api = new MockAPI()
