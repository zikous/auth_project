"use client"

import type { Task, Discussion, Conclusion, ReviewPlan, Review } from "@/lib/types"

// Simulate network delay
const delay = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms))

// Generate unique IDs
const generateId = () => Math.random().toString(36).substr(2, 9).toUpperCase()

// Mock API responses
interface ApiResponse<T> {
  success: boolean
  data: T
  message?: string
  error?: string
}

class MockAPI {
  private async simulateRequest<T>(operation: () => T, delayMs = 300, errorRate = 0.05): Promise<ApiResponse<T>> {
    await delay(delayMs)

    // Simulate occasional errors
    if (Math.random() < errorRate) {
      throw new Error("Network error occurred")
    }

    try {
      const data = operation()
      return {
        success: true,
        data,
        message: "Operation completed successfully",
      }
    } catch (error) {
      return {
        success: false,
        data: null as any,
        error: error instanceof Error ? error.message : "Unknown error",
      }
    }
  }

  // Task operations
  tasks = {
    create: async (taskData: Partial<Task>): Promise<ApiResponse<Task>> => {
      return this.simulateRequest(() => {
        const newTask: Task = {
          id: `T-${generateId()}`,
          name: taskData.name || "",
          description: taskData.description || "",
          parent_id: taskData.parent_id || null,
          assigned_to: taskData.assigned_to || "",
          responsible_person: taskData.responsible_person || "",
          days_required: taskData.days_required || 0,
          difficulty: taskData.difficulty || "Medium",
          completed: false,
          discussions: [],
          conclusions: [],
          working_papers: [],
          is_folder: taskData.is_folder || false,
        }
        return newTask
      }, 500)
    },

    update: async (taskId: string, updates: Partial<Task>): Promise<ApiResponse<Task>> => {
      return this.simulateRequest(() => {
        // In a real app, this would update the task in the database
        const updatedTask: Task = {
          id: taskId,
          name: updates.name || "",
          description: updates.description || "",
          parent_id: updates.parent_id || null,
          assigned_to: updates.assigned_to || "",
          responsible_person: updates.responsible_person || "",
          days_required: updates.days_required || 0,
          difficulty: updates.difficulty || "Medium",
          completed: updates.completed || false,
          discussions: updates.discussions || [],
          conclusions: updates.conclusions || [],
          working_papers: updates.working_papers || [],
          is_folder: updates.is_folder || false,
        }
        return updatedTask
      }, 400)
    },

    delete: async (taskId: string): Promise<ApiResponse<boolean>> => {
      return this.simulateRequest(() => {
        // In a real app, this would delete the task from the database
        return true
      }, 300)
    },

    toggleCompletion: async (taskId: string): Promise<ApiResponse<Task>> => {
      return this.simulateRequest(() => {
        // In a real app, this would toggle the task completion status
        const updatedTask: Task = {
          id: taskId,
          name: "Updated Task",
          description: "Task description",
          parent_id: null,
          assigned_to: "",
          responsible_person: "",
          days_required: 1,
          difficulty: "Medium",
          completed: true, // Toggle this based on current state
          discussions: [],
          conclusions: [],
          working_papers: [],
          is_folder: false,
        }
        return updatedTask
      }, 200)
    },

    addDiscussion: async (taskId: string, message: string): Promise<ApiResponse<Discussion>> => {
      return this.simulateRequest(() => {
        const newDiscussion: Discussion = {
          id: `D-${generateId()}`,
          task_id: taskId,
          author: "Current User", // In a real app, get from auth context
          message,
          timestamp: new Date().toISOString(),
        }
        return newDiscussion
      }, 250)
    },

    addConclusion: async (taskId: string, message: string): Promise<ApiResponse<Conclusion>> => {
      return this.simulateRequest(() => {
        const newConclusion: Conclusion = {
          id: `C-${generateId()}`,
          task_id: taskId,
          author: "Current User", // In a real app, get from auth context
          message,
          timestamp: new Date().toISOString(),
          version: 1, // In a real app, increment based on existing conclusions
        }
        return newConclusion
      }, 300)
    },
  }

  // Plan operations
  plans = {
    getAll: async (): Promise<ApiResponse<ReviewPlan[]>> => {
      return this.simulateRequest(() => {
        // Return mock plans
        return []
      }, 400)
    },

    getById: async (planId: string): Promise<ApiResponse<ReviewPlan>> => {
      return this.simulateRequest(() => {
        // Return mock plan
        const plan: ReviewPlan = {
          id: planId,
          name: "Mock Plan",
          description: "Mock plan description",
          validation_status: "In Construction",
          attached_reviews: [],
          persons_concerned: [],
          tasks: [],
        }
        return plan
      }, 300)
    },

    update: async (planId: string, updates: Partial<ReviewPlan>): Promise<ApiResponse<ReviewPlan>> => {
      return this.simulateRequest(() => {
        // Return updated plan
        const updatedPlan: ReviewPlan = {
          id: planId,
          name: updates.name || "Updated Plan",
          description: updates.description || "Updated description",
          validation_status: updates.validation_status || "In Construction",
          attached_reviews: updates.attached_reviews || [],
          persons_concerned: updates.persons_concerned || [],
          tasks: updates.tasks || [],
        }
        return updatedPlan
      }, 400)
    },
  }

  // Review operations
  reviews = {
    getAll: async (): Promise<ApiResponse<Review[]>> => {
      return this.simulateRequest(() => {
        // Return mock reviews
        return []
      }, 350)
    },

    getById: async (reviewId: string): Promise<ApiResponse<Review>> => {
      return this.simulateRequest(() => {
        // Return mock review
        const review: Review = {
          id: reviewId,
          name: "Mock Review",
          description: "Mock review description",
          status: "In Progress",
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        }
        return review
      }, 300)
    },

    create: async (reviewData: Partial<Review>): Promise<ApiResponse<Review>> => {
      return this.simulateRequest(() => {
        const newReview: Review = {
          id: `R-${generateId()}`,
          name: reviewData.name || "",
          description: reviewData.description || "",
          status: reviewData.status || "Draft",
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        }
        return newReview
      }, 450)
    },

    update: async (reviewId: string, updates: Partial<Review>): Promise<ApiResponse<Review>> => {
      return this.simulateRequest(() => {
        const updatedReview: Review = {
          id: reviewId,
          name: updates.name || "Updated Review",
          description: updates.description || "Updated description",
          status: updates.status || "In Progress",
          created_at: updates.created_at || new Date().toISOString(),
          updated_at: new Date().toISOString(),
        }
        return updatedReview
      }, 350)
    },

    delete: async (reviewId: string): Promise<ApiResponse<boolean>> => {
      return this.simulateRequest(() => {
        return true
      }, 250)
    },
  }
}

export const api = new MockAPI()
