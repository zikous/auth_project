"use client"

import { useState, useCallback, useMemo } from "react"
import type { Task, ReviewPlan, AIReport, TaskAggregation } from "@/lib/types"

export function useAIReport(
  task: Task | null,
  plan: ReviewPlan | null,
  aggregation: TaskAggregation | null,
  getTaskCompletionPercentage: (taskId: string) => number,
) {
  const [isGenerating, setIsGenerating] = useState(false)
  const [customPrompt, setCustomPrompt] = useState("")
  const [isEditingPrompt, setIsEditingPrompt] = useState(false)

  // Early return if required data is missing
  if (!task || !plan) {
    return {
      currentPrompt: "",
      customPrompt: "",
      setCustomPrompt: () => {},
      isEditingPrompt: false,
      isGenerating: false,
      generateReport: () => ({
        id: "",
        task_id: "",
        content: "Unable to generate report: Missing task or plan data",
        prompt: { id: "", content: "", timestamp: "", author: "", isDefault: true },
        generated_at: "",
        metadata: {
          discussion_count: 0,
          conclusion_count: 0,
          completion_rate: 0,
          confidence_level: "Low",
          aggregated_from_children: false,
        },
      }),
      handleGenerateReport: async () => {},
      handleEditPrompt: () => {},
      handleSavePrompt: () => {},
      handleCancelPrompt: () => {},
    }
  }

  // Safe property access with comprehensive fallbacks
  const safeTask = {
    id: task?.id || "Unknown",
    name: task?.name || "Unknown Task",
    description: task?.description || "No description available",
    assigned_to: task?.assigned_to || "Unassigned",
    completed: task?.completed || false,
    days_required: task?.days_required || 0,
    difficulty: task?.difficulty || "Medium",
    discussions: Array.isArray(task?.discussions) ? task.discussions : [],
    conclusions: Array.isArray(task?.conclusions) ? task.conclusions : [],
    working_papers: Array.isArray(task?.working_papers) ? task.working_papers : [],
  }

  const safePlan = {
    name: plan?.name || "Unknown Plan",
    validation_status: plan?.validation_status || "Unknown",
  }

  const safeAggregation = aggregation
    ? {
        childTasks: Array.isArray(aggregation.childTasks)
          ? aggregation.childTasks.map((child) => ({
              id: child?.id || "Unknown",
              name: child?.name || "Unknown",
              completed: child?.completed || false,
              difficulty: child?.difficulty || "Medium",
              assigned_to: child?.assigned_to || "Unassigned",
              discussions: Array.isArray(child?.discussions) ? child.discussions : [],
              conclusions: Array.isArray(child?.conclusions) ? child.conclusions : [],
            }))
          : [],
        discussions: Array.isArray(aggregation.discussions)
          ? aggregation.discussions.map((d) => ({
              author: d?.author || "Unknown",
              message: d?.message || "No message",
              timestamp: d?.timestamp || new Date().toISOString(),
              task_id: d?.task_id || "Unknown",
            }))
          : [],
        conclusions: Array.isArray(aggregation.conclusions)
          ? aggregation.conclusions.map((c) => ({
              version: c?.version || 1,
              author: c?.author || "Unknown",
              message: c?.message || "No message",
              timestamp: c?.timestamp || new Date().toISOString(),
              task_id: c?.task_id || "Unknown",
            }))
          : [],
        totalDiscussions: aggregation.totalDiscussions || 0,
        totalConclusions: aggregation.totalConclusions || 0,
      }
    : {
        childTasks: [],
        discussions: [],
        conclusions: [],
        totalDiscussions: 0,
        totalConclusions: 0,
      }

  const isParentTask = safeAggregation.childTasks.length > 0
  const completionPercentage = useMemo(() => {
    return isParentTask ? getTaskCompletionPercentage(safeTask.id) : 0
  }, [isParentTask, safeTask.id, getTaskCompletionPercentage])

  const defaultPrompt = useMemo(() => {
    // Use aggregation data if available, otherwise use task data
    const discussions = safeAggregation.discussions.length > 0 ? safeAggregation.discussions : safeTask.discussions
    const conclusions = safeAggregation.conclusions.length > 0 ? safeAggregation.conclusions : safeTask.conclusions
    const childTasks = safeAggregation.childTasks

    return `Analyze the following task and generate a comprehensive report:

**Task Information:**
- Task ID: ${safeTask.id}
- Task Name: ${safeTask.name}
- Description: ${safeTask.description}
- Assigned to: ${safeTask.assigned_to}
- Status: ${safeTask.completed ? "Completed" : "In Progress"}
- Days Required: ${safeTask.days_required}
- Difficulty Level: ${safeTask.difficulty}
- Plan Context: ${safePlan.name} (Status: ${safePlan.validation_status})
- Task Type: ${isParentTask ? `Parent Task (${completionPercentage}% complete)` : "Leaf Task"}

${
  isParentTask
    ? `
**Parent Task Completion:**
- Overall Progress: ${completionPercentage}%
- Child Tasks Completed: ${childTasks.filter((c) => c.completed).length}/${childTasks.length}

**Child Tasks (${childTasks.length} total):**
${childTasks.map((child) => `- ${child.id}: ${child.name} (${child.completed ? "Completed" : "In Progress"}, ${child.difficulty})`).join("\n")}
`
    : ""
}

**Discussion Points (${discussions.length} total${isParentTask ? " - aggregated from all child tasks" : ""}):**
${discussions.map((d) => `- ${d.author} (${new Date(d.timestamp).toLocaleDateString()}): ${d.message}${isParentTask ? ` [from ${d.task_id}]` : ""}`).join("\n")}

**Conclusions (${conclusions.length} versions${isParentTask ? " - aggregated from all child tasks" : ""}):**
${conclusions.map((c) => `- v${c.version} by ${c.author} (${new Date(c.timestamp).toLocaleDateString()}): ${c.message}${isParentTask ? ` [from ${c.task_id}]` : ""}`).join("\n")}

Please provide:
1. Executive Summary
2. ${isParentTask ? `Parent Task Analysis (${completionPercentage}% Complete)` : "Task Analysis"}
3. Plan Status Impact (Current: ${safePlan.validation_status})
4. Discussion Analysis
5. Completed Actions
6. Key Conclusions
7. Risk Assessment (considering difficulty level: ${safeTask.difficulty})
8. Next Steps and Recommendations
9. Compliance Notes (if applicable)

${
  isParentTask
    ? `Note: This is a parent task report with ${completionPercentage}% completion rate. Provide insights on overall progress, coordination effectiveness, and child task management.`
    : "Note: This is a leaf task report focusing on specific task execution."
}

Format the response as a professional banking report with clear sections and actionable insights.`
  }, [safeAggregation, isParentTask, completionPercentage])

  const currentPrompt = useMemo(() => {
    return isEditingPrompt && customPrompt ? customPrompt : defaultPrompt
  }, [isEditingPrompt, customPrompt, defaultPrompt])

  const generateReport = useCallback(
    (prompt: string): AIReport => {
      // Use aggregation data if available, otherwise use task data
      const discussions = safeAggregation.discussions.length > 0 ? safeAggregation.discussions : safeTask.discussions
      const conclusions = safeAggregation.conclusions.length > 0 ? safeAggregation.conclusions : safeTask.conclusions
      const childTasks = safeAggregation.childTasks

      const discussionCount = discussions.length
      const conclusionCount = conclusions.length
      const lastConclusion = conclusions.length > 0 ? conclusions[conclusions.length - 1] : null
      const completionRate = safeTask.completed ? 100 : Math.floor(Math.random() * 80) + 20

      const difficultyRisk =
        {
          Easy: "Low",
          Medium: "Medium",
          Hard: "High",
        }[safeTask.difficulty] || "Medium"

      const content = `# AI-Generated Task Analysis Report

**Generated on:** ${new Date().toLocaleString()}  
**Task:** ${safeTask.name} (${safeTask.id})  
**Review Plan:** ${safePlan.name} (Status: ${safePlan.validation_status})  
**Status:** ${safeTask.completed ? "✅ Completed" : "🔄 In Progress"}  
**Difficulty:** ${safeTask.difficulty}  
**Task Type:** ${isParentTask ? "🔗 Parent Task (Aggregated)" : "📋 Leaf Task"}

---

## 1. Executive Summary

This report analyzes ${isParentTask ? "parent task" : "task"} "${safeTask.name}" within the context of the "${safePlan.name}" review plan (Status: ${safePlan.validation_status}). ${
        isParentTask
          ? `This parent task coordinates ${childTasks.length} child tasks and aggregates ${discussionCount} discussions and ${conclusionCount} conclusions from the entire task hierarchy.`
          : `The task is currently ${safeTask.completed ? "completed" : "in progress"} with ${discussionCount} discussion points and ${conclusionCount} documented conclusions.`
      }

**Key Metrics:**
- Completion Rate: ${completionRate}%
- Difficulty Level: ${safeTask.difficulty} (${difficultyRisk} Risk)
- Team Engagement: ${discussionCount > 3 ? "High" : discussionCount > 1 ? "Medium" : "Low"}
- Documentation Quality: ${conclusionCount > 0 ? "Good" : "Needs Improvement"}
- Plan Status Context: ${safePlan.validation_status}
${
  isParentTask
    ? `- Child Task Coordination: ${childTasks.filter((c) => c.completed).length}/${childTasks.length} child tasks completed (${completionPercentage}%)`
    : ""
}

---

## 2. ${isParentTask ? "Parent Task Analysis" : "Task Analysis"}

${
  isParentTask
    ? `
**Parent Task Overview:**
This parent task "${safeTask.name}" serves as a coordination point for ${childTasks.length} child tasks with ${completionPercentage}% overall completion. The task operates under the plan status "${safePlan.validation_status}" which provides the overarching context for all task activities.

**Child Task Breakdown:**
${childTasks
  .map(
    (child) => `
- **${child.id}**: ${child.name}
  - Status: ${child.completed ? "✅ Completed" : "🔄 In Progress"}
  - Difficulty: ${child.difficulty}
  - Assigned to: ${child.assigned_to}
  - Discussions: ${child.discussions.length}
  - Conclusions: ${child.conclusions.length}`,
  )
  .join("\n")}

**Coordination Effectiveness:** ${childTasks.length > 0 ? (childTasks.filter((c) => c.completed).length / childTasks.length > 0.5 ? "Good progress across child tasks" : "Some child tasks need attention") : "No child tasks defined"}
`
    : `
**Task Details:**
- **Difficulty Level:** ${safeTask.difficulty} - This indicates a ${difficultyRisk.toLowerCase()} complexity task requiring ${safeTask.difficulty === "Hard" ? "specialized expertise and careful planning" : safeTask.difficulty === "Medium" ? "moderate expertise and coordination" : "standard execution with minimal complexity"}
- **Resource Allocation:** ${safeTask.days_required} days allocated
- **Assignment:** Currently assigned to ${safeTask.assigned_to}
- **Plan Context:** Operating under "${safePlan.validation_status}" plan status
`
}

---

## 3. Plan Status Impact

**Current Plan Status:** ${safePlan.validation_status}

This task operates within the broader context of the plan's "${safePlan.validation_status}" status, which means:
${
  safePlan.validation_status === "In Construction"
    ? "- The plan is still being developed and refined\n- Task requirements may evolve as the plan matures\n- Focus should be on establishing clear foundations"
    : safePlan.validation_status === "To Validate"
      ? "- The plan is ready for validation review\n- Tasks should be well-documented and ready for assessment\n- Quality assurance is critical at this stage"
      : safePlan.validation_status === "Pending"
        ? "- The plan is awaiting approval or next steps\n- Tasks may be on hold pending plan approval\n- Preparation for execution should be maintained"
        : "- The plan has been completed or suspended\n- Tasks should be in final stages or archived\n- Focus on documentation and lessons learned"
}

**Impact on Task Execution:**
- Task status is managed at the plan level for consistency
- Individual task completion contributes to overall plan progress
- ${isParentTask ? "Parent task coordination aligns with plan objectives" : "Leaf task execution supports plan deliverables"}

---

## 4. Discussion Analysis

**Total Discussions:** ${discussions.length}${isParentTask ? " (aggregated from all child tasks)" : ""}  
**Primary Contributors:** ${discussions.length > 0 ? [...new Set(discussions.map((d) => d.author))].join(", ") : "None"}

${
  discussionCount > 0
    ? `
**Key Discussion Themes:**
${discussions
  .slice(0, 5)
  .map(
    (d) =>
      `- **${d.author}:** ${d.message.substring(0, 100)}${d.message.length > 100 ? "..." : ""}${isParentTask ? ` [${d.task_id}]` : ""}`,
  )
  .join("\n")}

**Communication Pattern:** ${discussionCount > 5 ? "Very Active" : discussionCount > 2 ? "Regular" : "Limited"} communication observed${isParentTask ? " across the task hierarchy" : ""}.

${
  isParentTask
    ? `**Cross-Task Communication:** ${discussions.filter((d) => d.task_id !== safeTask.id).length} discussions from child tasks indicate ${discussions.filter((d) => d.task_id !== safeTask.id).length > 0 ? "active coordination" : "limited cross-task communication"}.`
    : ""
}
`
    : `**No discussions recorded yet.** Consider initiating team discussions to ensure proper collaboration and knowledge sharing${isParentTask ? " across all child tasks" : ""}.`
}

---

## 5. Completed Actions

${
  safeTask.completed
    ? `
✅ **Task Completed Successfully**
- All deliverables have been finalized
- Documentation is up to date
- Stakeholder approval obtained
- Plan status alignment maintained
${isParentTask ? `- All ${childTasks.length} child tasks coordinated and completed` : ""}
`
    : `
🔄 **Work in Progress**
- Task is actively being worked on
- ${Math.floor(completionRate)}% estimated completion
- Regular progress updates being provided
- Plan status "${safePlan.validation_status}" considerations maintained
${
  isParentTask
    ? `- Child task progress: ${childTasks.filter((c) => c.completed).length}/${childTasks.length} completed (${completionPercentage}%)`
    : ""
}
`
}

**Documented Milestones:**
${conclusions.length > 0 ? conclusions.map((c) => `- v${c.version}: ${c.message} (${new Date(c.timestamp).toLocaleDateString()})${isParentTask ? ` [${c.task_id}]` : ""}`).join("\n") : "- No formal milestones documented yet"}

---

## 6. Key Conclusions

${
  conclusionCount > 0 && lastConclusion
    ? `
**Latest Conclusion (v${lastConclusion.version}):**
${lastConclusion.message}${isParentTask ? ` [from ${lastConclusion.task_id}]` : ""}

**Conclusion History:**
${conclusions.map((c) => `- **Version ${c.version}** (${new Date(c.timestamp).toLocaleDateString()}): ${c.message}${isParentTask ? ` [${c.task_id}]` : ""}`).join("\n")}

**Decision Quality:** ${conclusionCount > 2 ? "Well-documented with clear progression" : conclusionCount > 0 ? "Basic documentation present" : "Insufficient documentation"}${isParentTask ? " across the task hierarchy" : ""}
`
    : `
**No formal conclusions documented.**
Recommend establishing clear decision points and documenting key outcomes for audit trail and future reference${isParentTask ? " across all child tasks" : ""}.
`
}

---

## 7. Risk Assessment

**Overall Risk Level:** ${safeTask.completed ? "🟢 Low" : discussionCount === 0 ? "🔴 High" : "🟡 Medium"}  
**Difficulty-Based Risk:** ${difficultyRisk === "High" ? "🔴" : difficultyRisk === "Medium" ? "🟡" : "🟢"} ${difficultyRisk} (based on ${safeTask.difficulty} difficulty)  
**Plan Status Risk:** ${safePlan.validation_status === "In Construction" ? "🟡 Medium" : safePlan.validation_status === "Pending" ? "🟡 Medium" : "🟢 Low"} (plan status: ${safePlan.validation_status})

**Risk Factors:**
${!safeTask.completed && discussionCount === 0 ? "- ⚠️ No team communication recorded" : ""}
${conclusionCount === 0 ? "- ⚠️ No formal conclusions documented" : ""}
${safeTask.days_required > 5 ? "- ⚠️ Complex task requiring extended timeline" : ""}
${safeTask.difficulty === "Hard" ? "- ⚠️ High difficulty level requires specialized expertise" : ""}
${safePlan.validation_status === "In Construction" ? "- ⚠️ Plan still under construction may affect task stability" : ""}
${safePlan.validation_status === "Pending" ? "- ⚠️ Plan pending approval may delay task execution" : ""}
${isParentTask && childTasks.filter((c) => !c.completed).length > 0 ? `- ⚠️ ${childTasks.filter((c) => !c.completed).length} child tasks still pending` : ""}
${safeTask.completed ? "- ✅ Task completed successfully with minimal residual risk" : ""}

**Mitigation Recommendations:**
${
  !safeTask.completed
    ? `
- Establish regular check-ins with ${safeTask.assigned_to}
- Document interim conclusions and decisions
- Monitor progress against ${safeTask.days_required}-day timeline
- Align task execution with plan status "${safePlan.validation_status}"
${safeTask.difficulty === "Hard" ? "- Ensure adequate expertise and resources for high-difficulty task" : ""}
${isParentTask ? "- Coordinate regular updates across all child tasks" : ""}
`
    : `
- Archive task documentation for future reference
- Conduct lessons learned session
- Update process documentation if applicable
- Ensure plan status alignment is maintained
${isParentTask ? "- Document coordination patterns for future parent tasks" : ""}
`
}

---

## 8. Next Steps and Recommendations

${
  safeTask.completed
    ? `
**Post-Completion Actions:**
1. **Archive Documentation:** Ensure all task materials are properly stored
2. **Knowledge Transfer:** Share learnings with team members
3. **Process Improvement:** Identify optimization opportunities for similar ${safeTask.difficulty.toLowerCase()}-difficulty tasks
4. **Plan Status Alignment:** Verify completion supports plan status objectives
5. **Compliance Review:** Verify all regulatory requirements have been met
${isParentTask ? "6. **Coordination Review:** Analyze parent-child task coordination effectiveness" : ""}
`
    : `
**Immediate Actions Required:**
1. **Progress Review:** Schedule check-in with ${safeTask.assigned_to}
2. **Documentation:** Ensure regular updates to discussion and conclusion logs
3. **Plan Alignment:** Verify task execution aligns with "${safePlan.validation_status}" plan status
4. **Risk Monitoring:** Address any identified risk factors, especially given ${safeTask.difficulty.toLowerCase()} difficulty
5. **Timeline Management:** Monitor against ${safeTask.days_required}-day allocation
${isParentTask ? "6. **Child Task Coordination:** Ensure all child tasks are progressing appropriately" : ""}
`
}

**Strategic Recommendations:**
- Enhance documentation practices for better audit trail
- Implement regular milestone reviews for ${safeTask.difficulty.toLowerCase()}-complexity tasks
- Consider automation opportunities for routine activities
- Strengthen cross-functional collaboration protocols
- Maintain alignment with plan status requirements
${isParentTask ? "- Develop standardized parent-child task coordination processes" : ""}

---

## 9. Compliance Notes

**Regulatory Context:** This task operates within the "${safePlan.name}" framework (Status: ${safePlan.validation_status}), ensuring alignment with:
- Internal audit requirements
- Regulatory compliance standards
- Risk management protocols
- Documentation retention policies
- Plan status governance requirements

**Audit Trail:** ${discussionCount + conclusionCount > 0 ? "✅ Adequate" : "⚠️ Needs Improvement"}${isParentTask ? " (aggregated across task hierarchy)" : ""}
**Documentation Standards:** ${conclusionCount > 0 ? "✅ Meeting requirements" : "⚠️ Below standards"}
**Plan Status Compliance:** ${safeTask.completed && safePlan.validation_status === "Finished/Suspended" ? "✅ Aligned" : "🔄 In Progress"}
**Approval Process:** ${safeTask.completed ? "✅ Completed" : "🔄 In Progress"}
**Difficulty Compliance:** ${safeTask.difficulty} tasks require ${safeTask.difficulty === "Hard" ? "enhanced oversight and specialized approval" : safeTask.difficulty === "Medium" ? "standard oversight and approval" : "basic oversight and approval"}

---

## Report Metadata

**Generated by:** AI Analysis Engine v2.1  
**Prompt Version:** ${isEditingPrompt ? "Custom" : "Standard"}  
**Data Sources:** ${isParentTask ? "Aggregated task discussions, conclusions, and metadata" : "Task discussions, conclusions, and metadata"}  
**Confidence Level:** ${discussionCount > 2 && conclusionCount > 0 ? "High" : "Medium"}  
**Task Complexity:** ${safeTask.difficulty}  
**Plan Status Context:** ${safePlan.validation_status}  
**Aggregation Level:** ${isParentTask ? "Parent Task (includes child data)" : "Leaf Task"}  
**Next Review:** ${safeTask.completed ? "As needed" : "Weekly"}

---

*This report was automatically generated based on ${isParentTask ? "aggregated task hierarchy data" : "available task data"} within the context of plan status "${safePlan.validation_status}". For questions or clarifications, please contact the task owner or review plan coordinator.*`

      return {
        id: `RPT-${Date.now()}`,
        task_id: safeTask.id,
        content,
        prompt: {
          id: `PRM-${Date.now()}`,
          content: prompt,
          timestamp: new Date().toISOString(),
          author: "System",
          isDefault: !isEditingPrompt,
        },
        generated_at: new Date().toISOString(),
        metadata: {
          discussion_count: discussionCount,
          conclusion_count: conclusionCount,
          completion_rate: completionRate,
          confidence_level: discussionCount > 2 && conclusionCount > 0 ? "High" : "Medium",
          aggregated_from_children: isParentTask,
        },
      }
    },
    [safeTask, safePlan, safeAggregation, isEditingPrompt, isParentTask, completionPercentage],
  )

  const handleGenerateReport = useCallback(async () => {
    setIsGenerating(true)
    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, 2000))
    setIsGenerating(false)
  }, [])

  const handleEditPrompt = useCallback(
    (editing: boolean) => {
      setIsEditingPrompt(editing)
      if (editing && !customPrompt) {
        setCustomPrompt(defaultPrompt)
      }
    },
    [defaultPrompt, customPrompt],
  )

  const handleSavePrompt = useCallback(() => {
    setIsEditingPrompt(false)
  }, [])

  const handleCancelPrompt = useCallback(() => {
    setIsEditingPrompt(false)
    setCustomPrompt("")
  }, [])

  return {
    currentPrompt,
    customPrompt,
    setCustomPrompt,
    isEditingPrompt,
    isGenerating,
    generateReport,
    handleGenerateReport,
    handleEditPrompt,
    handleSavePrompt,
    handleCancelPrompt,
  }
}
