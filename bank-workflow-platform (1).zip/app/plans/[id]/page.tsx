"use client"

import { useState, useEffect, useCallback } from "react"
import { useParams, useRouter } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Dialog, DialogContent } from "@/components/ui/dialog"
import { ArrowLeft, Users, CheckSquare, Plus, FolderOpen, Clock } from "lucide-react"
import { mockPlans } from "@/lib/mock-data"
import type { ReviewPlan, Task } from "@/lib/types"
import { TaskTree } from "@/components/task-tree"
import { TaskDetailsPanel } from "@/components/task-details-panel"
import { SimpleTaskCreator } from "@/components/simple-task-creator"
import { TaskEditDialog } from "@/components/task-edit-dialog"
import { ConfirmationDialog } from "@/components/confirmation-dialog"
import { useTaskAggregation } from "@/hooks/use-task-aggregation"
import { useToast } from "@/hooks/use-toast"

export default function PlanDetailPage() {
  const params = useParams()
  const router = useRouter()
  const { toast } = useToast()
  const planId = params.id as string

  const [plan, setPlan] = useState<ReviewPlan | null>(null)
  const [selectedTask, setSelectedTask] = useState<Task | null>(null)
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [editingTask, setEditingTask] = useState<Task | null>(null)
  const [taskToDelete, setTaskToDelete] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)

  // Load initial plan data
  useEffect(() => {
    const foundPlan = mockPlans.find((p) => p.id === planId)
    if (foundPlan) {
      console.log("📋 Loaded plan:", foundPlan.name)
      console.log(
        "📋 Plan tasks:",
        foundPlan.tasks.map((t) => ({
          id: t.id,
          name: t.name,
          parent_id: t.parent_id,
          is_folder: t.is_folder,
          discussions: t.discussions?.length || 0,
          conclusions: t.conclusions?.length || 0,
        })),
      )
      setPlan(foundPlan)
    }
  }, [planId])

  // Get aggregation data for selected task
  const { selectedTaskAggregation, isLeafTask: isLeafTaskFn } = useTaskAggregation(
    plan?.tasks || [],
    selectedTask?.id || null,
  )

  // Helper functions for task management
  const isLeafTask = useCallback(
    (taskId: string): boolean => {
      if (!plan) return false
      return isLeafTaskFn(taskId)
    },
    [plan, isLeafTaskFn],
  )

  const getLeafTaskCount = useCallback((): number => {
    if (!plan) return 0
    return plan.tasks.filter((task) => {
      const hasChildren = plan.tasks.some((t) => t.parent_id === task.id)
      return !task.is_folder && !hasChildren
    }).length
  }, [plan])

  const getCompletedLeafTaskCount = useCallback((): number => {
    if (!plan) return 0
    return plan.tasks.filter((task) => {
      const hasChildren = plan.tasks.some((t) => t.parent_id === task.id)
      return !task.is_folder && !hasChildren && task.completed
    }).length
  }, [plan])

  const getTaskCompletionPercentage = useCallback(
    (taskId: string): number => {
      if (!plan) return 0

      const getLeafTasksUnderParent = (parentId: string): Task[] => {
        const getAllDescendants = (id: string): Task[] => {
          const children = plan.tasks.filter((task) => task.parent_id === id)
          let allDescendants: Task[] = []

          children.forEach((child) => {
            const hasChildren = plan.tasks.some((t) => t.parent_id === child.id)
            if (!hasChildren && !child.is_folder) {
              allDescendants.push(child)
            } else {
              allDescendants = allDescendants.concat(getAllDescendants(child.id))
            }
          })

          return allDescendants
        }

        return getAllDescendants(parentId)
      }

      const leafTasks = getLeafTasksUnderParent(taskId)
      if (leafTasks.length === 0) return 0

      const completedLeafTasks = leafTasks.filter((task) => task.completed).length
      return Math.round((completedLeafTasks / leafTasks.length) * 100)
    },
    [plan],
  )

  const getTaskDifficulty = useCallback(
    (taskId: string): "Easy" | "Medium" | "Hard" => {
      if (!plan) return "Medium"

      const task = plan.tasks.find((t) => t.id === taskId)
      if (!task) return "Medium"

      const hasChildren = plan.tasks.some((t) => t.parent_id === taskId)
      if (!hasChildren) {
        return task.difficulty
      }

      // Calculate average difficulty for parent tasks
      const getLeafTasksUnderParent = (parentId: string): Task[] => {
        const getAllDescendants = (id: string): Task[] => {
          const children = plan.tasks.filter((task) => task.parent_id === id)
          let allDescendants: Task[] = []

          children.forEach((child) => {
            const hasChildren = plan.tasks.some((t) => t.parent_id === child.id)
            if (!hasChildren && !child.is_folder) {
              allDescendants.push(child)
            } else {
              allDescendants = allDescendants.concat(getAllDescendants(child.id))
            }
          })

          return allDescendants
        }

        return getAllDescendants(parentId)
      }

      const leafTasks = getLeafTasksUnderParent(taskId)
      if (leafTasks.length === 0) return "Medium"

      const difficultyValues = { Easy: 1, Medium: 2, Hard: 3 }
      const difficultyLabels = ["Easy", "Medium", "Hard"] as const

      const averageValue =
        leafTasks.reduce((sum, task) => sum + difficultyValues[task.difficulty], 0) / leafTasks.length
      const roundedValue = Math.round(averageValue)

      return difficultyLabels[Math.max(0, Math.min(2, roundedValue - 1))]
    },
    [plan],
  )

  // Task management functions
  const createTask = useCallback(
    async (taskData: any) => {
      if (!plan) return null

      setIsLoading(true)
      try {
        const newTask: Task = {
          id: taskData.is_folder
            ? `FLD-${String(plan.tasks.length + 1).padStart(3, "0")}`
            : `TSK-${String(plan.tasks.length + 1).padStart(3, "0")}`,
          plan_id: plan.id,
          completed: false,
          discussions: [],
          conclusions: [],
          ...taskData,
        }

        const updatedPlan = {
          ...plan,
          tasks: [...plan.tasks, newTask],
        }
        setPlan(updatedPlan)
        return newTask
      } finally {
        setIsLoading(false)
      }
    },
    [plan],
  )

  const updateTask = useCallback(
    (taskId: string, updates: Partial<Task>) => {
      if (!plan) return

      const updatedTasks = plan.tasks.map((task) => (task.id === taskId ? { ...task, ...updates } : task))
      const updatedPlan = { ...plan, tasks: updatedTasks }
      setPlan(updatedPlan)

      if (selectedTask?.id === taskId) {
        const updatedSelectedTask = updatedTasks.find((t) => t.id === taskId)
        setSelectedTask(updatedSelectedTask || null)
      }
    },
    [plan, selectedTask],
  )

  const deleteTask = useCallback(
    (taskId: string) => {
      if (!plan) return

      // Also delete all child tasks
      const getChildTaskIds = (parentId: string): string[] => {
        const children = plan.tasks.filter((task) => task.parent_id === parentId)
        let allChildIds = children.map((child) => child.id)
        children.forEach((child) => {
          allChildIds = allChildIds.concat(getChildTaskIds(child.id))
        })
        return allChildIds
      }

      const taskIdsToDelete = [taskId, ...getChildTaskIds(taskId)]
      const updatedTasks = plan.tasks.filter((task) => !taskIdsToDelete.includes(task.id))
      const updatedPlan = { ...plan, tasks: updatedTasks }
      setPlan(updatedPlan)

      if (selectedTask && taskIdsToDelete.includes(selectedTask.id)) {
        setSelectedTask(null)
      }
    },
    [plan, selectedTask],
  )

  const toggleTaskCompletion = useCallback(
    (taskId: string) => {
      if (!plan) return

      const task = plan.tasks.find((t) => t.id === taskId)
      if (!task) return

      // Only allow toggling completion for leaf tasks
      const hasChildren = plan.tasks.some((t) => t.parent_id === taskId)
      if (hasChildren) return

      const newCompleted = !task.completed
      const updatedTasks = plan.tasks.map((t) => (t.id === taskId ? { ...t, completed: newCompleted } : t))
      const updatedPlan = { ...plan, tasks: updatedTasks }
      setPlan(updatedPlan)

      if (selectedTask?.id === taskId) {
        const updatedSelectedTask = updatedTasks.find((t) => t.id === taskId)
        setSelectedTask(updatedSelectedTask || null)
      }
    },
    [plan, selectedTask],
  )

  const addDiscussion = useCallback(
    (taskId: string, message: string) => {
      if (!plan) return

      console.log(`➕ Adding discussion to task ${taskId}:`, message)

      const newDiscussion = {
        id: `DISC-${Date.now()}`,
        author: "Current User",
        message,
        timestamp: new Date().toISOString(),
        task_id: taskId,
      }

      const updatedTasks = plan.tasks.map((task) =>
        task.id === taskId ? { ...task, discussions: [...(task.discussions || []), newDiscussion] } : task,
      )
      const updatedPlan = { ...plan, tasks: updatedTasks }

      console.log(
        `✅ Updated task ${taskId} discussions:`,
        updatedTasks.find((t) => t.id === taskId)?.discussions?.length,
      )

      setPlan(updatedPlan)

      if (selectedTask?.id === taskId) {
        setSelectedTask({
          ...selectedTask,
          discussions: [...(selectedTask.discussions || []), newDiscussion],
        })
      }
    },
    [plan, selectedTask],
  )

  const addConclusion = useCallback(
    (taskId: string, message: string) => {
      if (!plan) return

      console.log(`➕ Adding conclusion to task ${taskId}:`, message)

      const task = plan.tasks.find((t) => t.id === taskId)
      const newConclusion = {
        id: `CONC-${Date.now()}`,
        author: "Current User",
        message,
        timestamp: new Date().toISOString(),
        version: (task?.conclusions?.length || 0) + 1,
        task_id: taskId,
      }

      const updatedTasks = plan.tasks.map((task) =>
        task.id === taskId ? { ...task, conclusions: [...(task.conclusions || []), newConclusion] } : task,
      )
      const updatedPlan = { ...plan, tasks: updatedTasks }

      console.log(
        `✅ Updated task ${taskId} conclusions:`,
        updatedTasks.find((t) => t.id === taskId)?.conclusions?.length,
      )

      setPlan(updatedPlan)

      if (selectedTask?.id === taskId) {
        setSelectedTask({
          ...selectedTask,
          conclusions: [...(selectedTask.conclusions || []), newConclusion],
        })
      }
    },
    [plan, selectedTask],
  )

  if (!plan) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <Card>
          <CardContent className="p-6">
            <p className="text-slate-700">Plan not found</p>
            <Button onClick={() => router.push("/plans")} className="mt-4">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Plans
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  // Calculate plan statistics
  const totalTasks = getLeafTaskCount()
  const completedTasks = getCompletedLeafTaskCount()
  const overallProgress = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0

  const handleTaskSelect = (task: Task) => {
    console.log(`🎯 Selected task: ${task.id} (${task.name})`)
    console.log(`🎯 Task details:`, {
      is_folder: task.is_folder,
      parent_id: task.parent_id,
      discussions: task.discussions?.length || 0,
      conclusions: task.conclusions?.length || 0,
    })
    setSelectedTask(task)
  }

  const handleTaskEdit = (task: Task) => {
    setEditingTask(task)
  }

  const handleTaskDelete = (taskId: string) => {
    setTaskToDelete(taskId)
  }

  const confirmDelete = () => {
    if (taskToDelete) {
      deleteTask(taskToDelete)
      setTaskToDelete(null)
      toast({ title: "Task deleted" })
    }
  }

  const handleTaskToggle = (taskId: string) => {
    toggleTaskCompletion(taskId)
    toast({ title: "Task updated" })
  }

  const handleCreateTask = async (taskData: any) => {
    const result = await createTask(taskData)
    if (result) {
      setIsCreateDialogOpen(false)
      toast({ title: `${taskData.is_folder ? "Folder" : "Task"} created successfully` })
    }
  }

  const handleEditTask = (taskData: any) => {
    if (editingTask) {
      updateTask(editingTask.id, taskData)
      setEditingTask(null)
      toast({ title: "Task updated" })
    }
  }

  const handleAddDiscussion = (taskId: string, message: string) => {
    addDiscussion(taskId, message)
  }

  const handleAddConclusion = (taskId: string, message: string) => {
    addConclusion(taskId, message)
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="container mx-auto p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <Button variant="ghost" onClick={() => router.push("/plans")}>
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>
            <div>
              <div className="flex items-center gap-2 mb-1">
                <Users className="h-5 w-5 text-slate-600" />
                <h1 className="text-2xl font-bold text-slate-900">{plan.name}</h1>
              </div>
              <p className="text-slate-600">{plan.description}</p>
            </div>
          </div>
          <Button onClick={() => setIsCreateDialogOpen(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Add Item
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <CheckSquare className="h-8 w-8 text-blue-600" />
                <div>
                  <p className="text-sm text-slate-600">Progress</p>
                  <p className="text-2xl font-bold">{overallProgress}%</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <FolderOpen className="h-8 w-8 text-green-600" />
                <div>
                  <p className="text-sm text-slate-600">Total Tasks</p>
                  <p className="text-2xl font-bold">{totalTasks}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <CheckSquare className="h-8 w-8 text-green-600" />
                <div>
                  <p className="text-sm text-slate-600">Completed</p>
                  <p className="text-2xl font-bold">{completedTasks}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <Clock className="h-8 w-8 text-orange-600" />
                <div>
                  <p className="text-sm text-slate-600">Remaining</p>
                  <p className="text-2xl font-bold">{totalTasks - completedTasks}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Progress Bar */}
        <Card className="mb-6">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium">Overall Progress</span>
              <span className="text-sm font-bold">{overallProgress}%</span>
            </div>
            <Progress value={overallProgress} className="h-2" />
          </CardContent>
        </Card>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Task Tree */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FolderOpen className="h-5 w-5" />
                Tasks
              </CardTitle>
            </CardHeader>
            <CardContent>
              <TaskTree
                tasks={plan.tasks}
                onTaskSelect={handleTaskSelect}
                onTaskEdit={handleTaskEdit}
                onTaskDelete={handleTaskDelete}
                onTaskToggle={handleTaskToggle}
                selectedTaskId={selectedTask?.id}
                getTaskCompletionPercentage={getTaskCompletionPercentage}
                getTaskDifficulty={getTaskDifficulty}
                isLeafTask={isLeafTask}
              />
            </CardContent>
          </Card>

          {/* Task Details */}
          <TaskDetailsPanel
            task={selectedTask}
            plan={plan}
            aggregation={selectedTaskAggregation}
            isLeafTask={selectedTask ? isLeafTask(selectedTask.id) : false}
            onAddDiscussion={handleAddDiscussion}
            onAddConclusion={handleAddConclusion}
            getTaskCompletionPercentage={getTaskCompletionPercentage}
            getTaskDifficulty={getTaskDifficulty}
          />
        </div>

        {/* Simple Task Creator Dialog */}
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogContent className="max-w-2xl">
            <SimpleTaskCreator
              plan={plan}
              onCreateTask={handleCreateTask}
              onClose={() => setIsCreateDialogOpen(false)}
              isLoading={isLoading}
            />
          </DialogContent>
        </Dialog>

        {/* Edit Dialog */}
        {editingTask && (
          <TaskEditDialog
            isOpen={!!editingTask}
            onClose={() => setEditingTask(null)}
            onSubmit={handleEditTask}
            task={editingTask}
            existingTasks={plan.tasks}
          />
        )}

        {/* Delete Confirmation */}
        <ConfirmationDialog
          isOpen={!!taskToDelete}
          onClose={() => setTaskToDelete(null)}
          onConfirm={confirmDelete}
          title="Delete Task"
          description="Are you sure? This will also delete all child tasks."
          confirmText="Delete"
          cancelText="Cancel"
        />
      </div>
    </div>
  )
}
