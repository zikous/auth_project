"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import { Plus, Search, Edit, Trash2, FileText, MoreHorizontal, LinkIcon } from "lucide-react"
import { mockReviews, mockPlans } from "@/lib/mock-data"
import type { Review } from "@/lib/types"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

export default function ReviewsPage() {
  const [reviews, setReviews] = useState<Review[]>(mockReviews)
  const [searchTerm, setSearchTerm] = useState("")
  const [isCreateOpen, setIsCreateOpen] = useState(false)
  const [editingReview, setEditingReview] = useState<Review | null>(null)
  const [formData, setFormData] = useState({ id: "", name: "", description: "" })
  const [selectedItems, setSelectedItems] = useState<string[]>([])
  const [viewingLinkedPlans, setViewingLinkedPlans] = useState<string | null>(null)

  const filteredReviews = reviews.filter(
    (review) =>
      review.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      review.id.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const getLinkedPlans = (reviewId: string) => {
    return mockPlans.filter((plan) => plan.attached_reviews.includes(reviewId))
  }

  const handleCreate = () => {
    // Check if ID already exists
    if (reviews.some((r) => r.id === formData.id)) {
      alert("Review ID already exists. Please choose a different ID.")
      return
    }

    const newReview: Review = {
      id: formData.id,
      name: formData.name,
      description: formData.description,
    }
    setReviews([...reviews, newReview])
    setFormData({ id: "", name: "", description: "" })
    setIsCreateOpen(false)
  }

  const handleEdit = (review: Review) => {
    setEditingReview(review)
    setFormData({ id: review.id, name: review.name, description: review.description })
  }

  const handleUpdate = () => {
    if (!editingReview) return

    // Check if new ID already exists (and it's not the current review's ID)
    if (formData.id !== editingReview.id && reviews.some((r) => r.id === formData.id)) {
      alert("Review ID already exists. Please choose a different ID.")
      return
    }

    setReviews(
      reviews.map((r) =>
        r.id === editingReview.id
          ? { ...r, id: formData.id, name: formData.name, description: formData.description }
          : r,
      ),
    )
    setEditingReview(null)
    setFormData({ id: "", name: "", description: "" })
  }

  const handleDelete = (id: string) => {
    setReviews(reviews.filter((r) => r.id !== id))
    setSelectedItems(selectedItems.filter((item) => item !== id))
  }

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedItems(filteredReviews.map((r) => r.id))
    } else {
      setSelectedItems([])
    }
  }

  const handleSelectItem = (id: string, checked: boolean) => {
    if (checked) {
      setSelectedItems([...selectedItems, id])
    } else {
      setSelectedItems(selectedItems.filter((item) => item !== id))
    }
  }

  const handleBulkDelete = () => {
    setReviews(reviews.filter((r) => !selectedItems.includes(r.id)))
    setSelectedItems([])
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-semibold text-gray-900">Reviews</h1>
            <p className="text-gray-600 mt-1">{reviews.length} total reviews</p>
          </div>
          <div className="flex items-center space-x-3">
            {selectedItems.length > 0 && (
              <Button variant="outline" onClick={handleBulkDelete} className="text-red-600 hover:text-red-700">
                <Trash2 className="h-4 w-4 mr-2" />
                Delete ({selectedItems.length})
              </Button>
            )}
            <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
              <DialogTrigger asChild>
                <Button className="bg-blue-600 hover:bg-blue-700">
                  <Plus className="h-4 w-4 mr-2" />
                  New Review
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-md">
                <DialogHeader>
                  <DialogTitle>New Review</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div>
                    <Label htmlFor="id">Review ID</Label>
                    <Input
                      id="id"
                      value={formData.id}
                      onChange={(e) => setFormData({ ...formData, id: e.target.value })}
                      placeholder="e.g., RVW-001"
                      className="mt-1"
                    />
                    <p className="text-xs text-gray-500 mt-1">Enter a unique identifier for this review</p>
                  </div>
                  <div>
                    <Label htmlFor="name">Name</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="Review name"
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="description">Description</Label>
                    <Textarea
                      id="description"
                      value={formData.description}
                      onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                      placeholder="Brief description"
                      className="mt-1"
                      rows={3}
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsCreateOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleCreate} disabled={!formData.id.trim() || !formData.name.trim()}>
                    Create
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Search */}
        <div className="mb-6">
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Search reviews..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        </div>

        {/* Table */}
        <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="w-12 px-4 py-3 text-left">
                    <Checkbox
                      checked={selectedItems.length === filteredReviews.length && filteredReviews.length > 0}
                      onCheckedChange={handleSelectAll}
                    />
                  </th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-900">ID</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-900">Name</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-900">Description</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-900">Linked Plans</th>
                  <th className="px-4 py-3 text-left text-sm font-medium text-gray-900">Created</th>
                  <th className="w-16 px-4 py-3 text-center text-sm font-medium text-gray-900">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {filteredReviews.map((review, index) => {
                  const linkedPlans = getLinkedPlans(review.id)
                  return (
                    <tr key={review.id} className="hover:bg-gray-50 transition-colors">
                      <td className="px-4 py-4">
                        <Checkbox
                          checked={selectedItems.includes(review.id)}
                          onCheckedChange={(checked) => handleSelectItem(review.id, checked as boolean)}
                        />
                      </td>
                      <td className="px-4 py-4">
                        <div className="flex items-center space-x-2">
                          <div className="bg-blue-100 rounded p-1">
                            <FileText className="h-3 w-3 text-blue-600" />
                          </div>
                          <span className="text-sm font-mono text-gray-900">{review.id}</span>
                        </div>
                      </td>
                      <td className="px-4 py-4">
                        <span className="text-sm font-medium text-gray-900">{review.name}</span>
                      </td>
                      <td className="px-4 py-4">
                        <span className="text-sm text-gray-600 max-w-xs truncate block">{review.description}</span>
                      </td>
                      <td className="px-4 py-4">
                        {linkedPlans.length > 0 ? (
                          <div className="flex items-center space-x-2">
                            <span className="text-sm text-gray-600">{linkedPlans.length} plan(s)</span>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => setViewingLinkedPlans(review.id)}
                              className="h-6 w-6 p-0"
                            >
                              <LinkIcon className="h-3 w-3" />
                            </Button>
                          </div>
                        ) : (
                          <span className="text-sm text-gray-400">No plans</span>
                        )}
                      </td>
                      <td className="px-4 py-4">
                        <span className="text-sm text-gray-500">
                          {new Date(Date.now() - index * 24 * 60 * 60 * 1000).toLocaleDateString()}
                        </span>
                      </td>
                      <td className="px-4 py-4 text-center">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                              <MoreHorizontal className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => handleEdit(review)}>
                              <Edit className="h-4 w-4 mr-2" />
                              Edit
                            </DropdownMenuItem>
                            {linkedPlans.length > 0 && (
                              <DropdownMenuItem onClick={() => setViewingLinkedPlans(review.id)}>
                                <LinkIcon className="h-4 w-4 mr-2" />
                                View Linked Plans ({linkedPlans.length})
                              </DropdownMenuItem>
                            )}
                            <DropdownMenuItem onClick={() => handleDelete(review.id)} className="text-red-600">
                              <Trash2 className="h-4 w-4 mr-2" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>

          {filteredReviews.length === 0 && (
            <div className="text-center py-12">
              <FileText className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No reviews found</h3>
              <p className="text-gray-600 mb-4">
                {searchTerm ? "Try a different search term" : "Create your first review to get started"}
              </p>
              {!searchTerm && (
                <Button onClick={() => setIsCreateOpen(true)} className="bg-blue-600 hover:bg-blue-700">
                  <Plus className="h-4 w-4 mr-2" />
                  New Review
                </Button>
              )}
            </div>
          )}
        </div>

        {/* Edit Dialog */}
        <Dialog open={!!editingReview} onOpenChange={() => setEditingReview(null)}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Edit Review</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div>
                <Label htmlFor="edit-id">Review ID</Label>
                <Input
                  id="edit-id"
                  value={formData.id}
                  onChange={(e) => setFormData({ ...formData, id: e.target.value })}
                  className="mt-1"
                />
                <p className="text-xs text-gray-500 mt-1">Enter a unique identifier for this review</p>
              </div>
              <div>
                <Label htmlFor="edit-name">Name</Label>
                <Input
                  id="edit-name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="edit-description">Description</Label>
                <Textarea
                  id="edit-description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="mt-1"
                  rows={3}
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setEditingReview(null)}>
                Cancel
              </Button>
              <Button onClick={handleUpdate} disabled={!formData.id.trim() || !formData.name.trim()}>
                Save
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Linked Plans Dialog */}
        <Dialog open={!!viewingLinkedPlans} onOpenChange={() => setViewingLinkedPlans(null)}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>
                Linked Plans for {viewingLinkedPlans && reviews.find((r) => r.id === viewingLinkedPlans)?.name}
              </DialogTitle>
            </DialogHeader>
            <div className="py-4">
              {viewingLinkedPlans && (
                <div className="space-y-3">
                  {getLinkedPlans(viewingLinkedPlans).map((plan) => (
                    <div key={plan.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="bg-green-100 rounded p-2">
                          <FileText className="h-4 w-4 text-green-600" />
                        </div>
                        <div>
                          <h4 className="font-medium text-gray-900">{plan.name}</h4>
                          <p className="text-sm text-gray-500">{plan.id}</p>
                          <p className="text-xs text-gray-400 mt-1">{plan.description}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className="text-xs px-2 py-1 bg-gray-100 rounded-full">{plan.validation_status}</span>
                        <Button size="sm" variant="outline" asChild>
                          <a href={`/plans/${plan.id}`}>View</a>
                        </Button>
                      </div>
                    </div>
                  ))}
                  {getLinkedPlans(viewingLinkedPlans).length === 0 && (
                    <div className="text-center py-8">
                      <FileText className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                      <p className="text-gray-500">No plans are linked to this review</p>
                    </div>
                  )}
                </div>
              )}
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setViewingLinkedPlans(null)}>
                Close
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  )
}
