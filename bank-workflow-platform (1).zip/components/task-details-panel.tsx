"use client"

import { useState, useMemo } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import {
  User,
  Calendar,
  MessageSquare,
  GitCommit,
  AlertCircle,
  FolderOpen,
  FileText,
  Plus,
  Send,
  Users,
  TestTube,
} from "lucide-react"
import type { Task, ReviewPlan, TaskAggregation } from "@/lib/types"
import { AIReportGenerator } from "@/components/ai-report-generator"
import { useToast } from "@/hooks/use-toast"

interface TaskDetailsPanelProps {
  task: Task | null
  plan: ReviewPlan
  aggregation: TaskAggregation | null
  isLeafTask: boolean
  onAddDiscussion: (taskId: string, message: string) => void
  onAddConclusion: (taskId: string, message: string) => void
  getTaskCompletionPercentage: (taskId: string) => number
  getTaskDifficulty: (taskId: string) => "Easy" | "Medium" | "Hard" | null
}

export function TaskDetailsPanel({
  task,
  plan,
  aggregation,
  isLeafTask,
  onAddDiscussion,
  onAddConclusion,
  getTaskCompletionPercentage,
}: TaskDetailsPanelProps) {
  // Always call hooks at the top level, before any early returns
  const [newDiscussion, setNewDiscussion] = useState("")
  const [newConclusion, setNewConclusion] = useState("")
  const { toast } = useToast()

  // Memoize computed values to avoid recalculation
  const computedValues = useMemo(() => {
    if (!task) {
      return {
        isFolder: false,
        discussions: [],
        conclusions: [],
        childTasks: [],
        completionPercentage: 0,
        discussionsByTask: null,
        conclusionsByTask: null,
      }
    }

    const isFolder = !isLeafTask
    const discussions = isFolder ? aggregation?.discussions || [] : task?.discussions || []
    const conclusions = isFolder ? aggregation?.conclusions || [] : task?.conclusions || []
    const childTasks = aggregation?.childTasks || []
    const completionPercentage = isFolder ? getTaskCompletionPercentage(task.id) : 0

    console.log(`📊 TaskDetailsPanel computed values for ${task.id}:`, {
      isFolder,
      isLeafTask,
      aggregationExists: !!aggregation,
      discussionsFromAggregation: aggregation?.discussions?.length || 0,
      discussionsFromTask: task?.discussions?.length || 0,
      finalDiscussionsCount: discussions.length,
      conclusionsFromAggregation: aggregation?.conclusions?.length || 0,
      conclusionsFromTask: task?.conclusions?.length || 0,
      finalConclusionsCount: conclusions.length,
      childTasksCount: childTasks.length,
    })

    // Group discussions by task for better organization in folder view
    const discussionsByTask = isFolder
      ? discussions.reduce(
          (acc, discussion) => {
            const taskId = discussion?.task_id || "unknown"
            if (!acc[taskId]) {
              acc[taskId] = []
            }
            acc[taskId].push(discussion)
            return acc
          },
          {} as Record<string, typeof discussions>,
        )
      : null

    // Group conclusions by task for better organization in folder view
    const conclusionsByTask = isFolder
      ? conclusions.reduce(
          (acc, conclusion) => {
            const taskId = conclusion?.task_id || "unknown"
            if (!acc[taskId]) {
              acc[taskId] = []
            }
            acc[taskId].push(conclusion)
            return acc
          },
          {} as Record<string, typeof conclusions>,
        )
      : null

    return {
      isFolder,
      discussions,
      conclusions,
      childTasks,
      completionPercentage,
      discussionsByTask,
      conclusionsByTask,
    }
  }, [task, isLeafTask, aggregation, getTaskCompletionPercentage])

  const { isFolder, discussions, conclusions, childTasks, completionPercentage, discussionsByTask, conclusionsByTask } =
    computedValues

  const handleAddDiscussion = () => {
    if (!newDiscussion.trim() || !task?.id) return
    onAddDiscussion(task.id, newDiscussion.trim())
    setNewDiscussion("")
    toast({ title: "Discussion added" })
  }

  const handleAddConclusion = () => {
    if (!newConclusion.trim() || !task?.id) return
    onAddConclusion(task.id, newConclusion.trim())
    setNewConclusion("")
    toast({ title: "Conclusion added" })
  }

  const quickDiscussions = [
    "Initial review completed - no major issues found.",
    "Need clarification from business team on requirements.",
    "Risk assessment shows medium exposure level.",
    "Documentation needs to be updated before proceeding.",
  ]

  const quickConclusions = [
    "Analysis complete - approved to proceed.",
    "All requirements met and documented.",
    "Risk mitigation strategies implemented successfully.",
    "Review completed with no outstanding issues.",
  ]

  const addQuickDiscussion = () => {
    if (!task?.id) return
    const message = quickDiscussions[Math.floor(Math.random() * quickDiscussions.length)]
    onAddDiscussion(task.id, message)
    toast({ title: "Discussion added" })
  }

  const addQuickConclusion = () => {
    if (!task?.id) return
    const message = quickConclusions[Math.floor(Math.random() * quickConclusions.length)]
    onAddConclusion(task.id, message)
    toast({ title: "Conclusion added" })
  }

  // Test function to add discussions to child tasks
  const addTestDiscussionsToChildren = () => {
    if (!task?.id || !isFolder) return

    const childTasks = plan.tasks.filter((t) => t.parent_id === task.id)
    const leafChildren = childTasks.filter((child) => {
      const hasChildren = plan.tasks.some((t) => t.parent_id === child.id)
      return !hasChildren && !child.is_folder
    })

    console.log(`🧪 Adding test discussions to ${leafChildren.length} leaf children of ${task.id}`)

    leafChildren.forEach((child, index) => {
      const testMessage = `Test discussion ${index + 1} for ${child.name} - Added for aggregation testing`
      onAddDiscussion(child.id, testMessage)
    })

    toast({
      title: `Added test discussions to ${leafChildren.length} child tasks`,
      description: "Check the aggregated view to see them appear",
    })
  }

  // Early return after all hooks have been called
  if (!task) {
    return (
      <Card>
        <CardContent className="p-8 text-center text-slate-500">
          <AlertCircle className="h-8 w-8 mx-auto mb-3 opacity-30" />
          <p>Select a task to view details</p>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader className="border-b">
        <div className="flex items-start gap-3">
          {isLeafTask ? (
            <FileText className="h-5 w-5 text-slate-600 mt-0.5" />
          ) : (
            <FolderOpen className="h-5 w-5 text-blue-600 mt-0.5" />
          )}
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1 flex-wrap">
              <span className="text-sm font-mono text-slate-500">{task.id}</span>
              <Badge
                variant="outline"
                className={isLeafTask ? "bg-green-50 text-green-700" : "bg-blue-50 text-blue-700"}
              >
                {isLeafTask ? "Task" : "Folder"}
              </Badge>
              {isFolder && (
                <>
                  <Badge variant="secondary" className="bg-slate-100 text-slate-700">
                    {childTasks.length} items
                  </Badge>
                  {discussions.length > 0 && (
                    <Badge variant="secondary" className="bg-orange-100 text-orange-700">
                      <MessageSquare className="h-3 w-3 mr-1" />
                      {discussions.length} discussions
                    </Badge>
                  )}
                  {conclusions.length > 0 && (
                    <Badge variant="secondary" className="bg-purple-100 text-purple-700">
                      <GitCommit className="h-3 w-3 mr-1" />
                      {conclusions.length} conclusions
                    </Badge>
                  )}
                </>
              )}
            </div>
            <CardTitle className="text-lg">{task.name}</CardTitle>
            <p className="text-sm text-slate-600 mt-1">{task.description}</p>
          </div>
        </div>
      </CardHeader>

      <CardContent className="p-6">
        {/* Task Info */}
        <div className="flex items-center gap-4 text-sm text-slate-600 mb-6">
          {isLeafTask && task.assigned_to && (
            <div className="flex items-center gap-1">
              <User className="h-4 w-4" />
              <span>{task.assigned_to}</span>
            </div>
          )}
          {!isLeafTask && task.responsible_person && (
            <div className="flex items-center gap-1">
              <Users className="h-4 w-4" />
              <span>{task.responsible_person}</span>
            </div>
          )}
          {isLeafTask && task.days_required && task.days_required > 0 && (
            <div className="flex items-center gap-1">
              <Calendar className="h-4 w-4" />
              <span>{task.days_required} days</span>
            </div>
          )}
        </div>

        {/* Progress for folders */}
        {!isLeafTask && (
          <div className="mb-6 p-4 bg-slate-50 rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium">Progress</span>
              <span className="text-sm text-slate-600">{completionPercentage}%</span>
            </div>
            <Progress value={completionPercentage} className="h-2" />
            <p className="text-xs text-slate-500 mt-1">{childTasks.length} child items</p>
          </div>
        )}

        {/* Aggregation Status for Folders */}
        {isFolder && (
          <div className="mb-4 p-3 bg-blue-50 rounded-lg border border-blue-200">
            <div className="flex items-center justify-between mb-1">
              <div className="flex items-center gap-2">
                <Users className="h-4 w-4 text-blue-600" />
                <span className="text-sm font-medium text-blue-800">Aggregated View</span>
              </div>
              <Button size="sm" variant="outline" onClick={addTestDiscussionsToChildren} className="text-xs">
                <TestTube className="h-3 w-3 mr-1" />
                Add Test Data
              </Button>
            </div>
            <p className="text-xs text-blue-700">
              Showing {discussions.length} discussions and {conclusions.length} conclusions from all child tasks
            </p>
          </div>
        )}

        {/* Debug Info */}
        {process.env.NODE_ENV === "development" && (
          <div className="mb-4 p-2 bg-yellow-50 rounded text-xs">
            <strong>Debug:</strong> Task {task.id}, isFolder: {isFolder.toString()}, childTasks: {childTasks.length},
            aggregation: {aggregation ? "exists" : "null"}, discussions: {discussions.length}, conclusions:{" "}
            {conclusions.length}
          </div>
        )}

        {/* Tabs */}
        <Tabs defaultValue="discussion" className="w-full">
          <TabsList className={`grid w-full ${isFolder ? "grid-cols-2" : "grid-cols-3"}`}>
            <TabsTrigger value="discussion">
              <MessageSquare className="h-4 w-4 mr-1" />
              Discussion ({discussions.length})
            </TabsTrigger>
            <TabsTrigger value="conclusions">
              <GitCommit className="h-4 w-4 mr-1" />
              Conclusions ({conclusions.length})
            </TabsTrigger>
            {!isFolder && <TabsTrigger value="ai-report">AI Report</TabsTrigger>}
          </TabsList>

          <TabsContent value="discussion" className="mt-4">
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h4 className="font-medium">
                  {isFolder ? "Aggregated Discussions from Child Tasks" : "Task Discussions"}
                </h4>
                {isLeafTask && (
                  <Button size="sm" variant="outline" onClick={addQuickDiscussion}>
                    <Plus className="h-4 w-4 mr-1" />
                    Quick Add
                  </Button>
                )}
              </div>

              <ScrollArea className="h-64 border rounded p-3">
                {discussions.length > 0 ? (
                  <div className="space-y-3">
                    {isFolder && discussionsByTask
                      ? // Grouped view for folders
                        Object.entries(discussionsByTask).map(([taskId, taskDiscussions]) => (
                          <div key={taskId} className="space-y-2">
                            <div className="flex items-center gap-2 py-1">
                              <Badge variant="outline" className="text-xs font-mono bg-blue-50 text-blue-700">
                                {taskId}
                              </Badge>
                              <span className="text-xs text-slate-500">
                                {taskDiscussions.length} discussion{taskDiscussions.length !== 1 ? "s" : ""}
                              </span>
                            </div>
                            {taskDiscussions.map((discussion, index) => (
                              <div
                                key={discussion?.id || `${taskId}-${index}`}
                                className="ml-4 pb-2 border-l-2 border-blue-200 pl-3"
                              >
                                <div className="flex items-center gap-2 mb-1">
                                  <span className="text-sm font-medium">{discussion?.author || "Unknown"}</span>
                                  <span className="text-xs text-slate-500">
                                    {discussion?.timestamp
                                      ? new Date(discussion.timestamp).toLocaleString()
                                      : "Unknown time"}
                                  </span>
                                </div>
                                <p className="text-sm text-slate-700">{discussion?.message || "No message"}</p>
                              </div>
                            ))}
                            <Separator className="my-3" />
                          </div>
                        ))
                      : // Simple view for leaf tasks
                        discussions.map((discussion, index) => (
                          <div key={discussion?.id || index} className="pb-3 border-b last:border-b-0">
                            <div className="flex items-center gap-2 mb-1">
                              <span className="text-sm font-medium">{discussion?.author || "Unknown"}</span>
                              <span className="text-xs text-slate-500">
                                {discussion?.timestamp
                                  ? new Date(discussion.timestamp).toLocaleString()
                                  : "Unknown time"}
                              </span>
                            </div>
                            <p className="text-sm text-slate-700">{discussion?.message || "No message"}</p>
                          </div>
                        ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-slate-500">
                    <MessageSquare className="h-8 w-8 mx-auto mb-2 opacity-30" />
                    <p className="text-sm">{isFolder ? "No discussions in child tasks yet" : "No discussions yet"}</p>
                    <p className="text-xs mt-1">
                      {isFolder
                        ? "Discussions from child tasks will appear here. Use 'Add Test Data' to try it out."
                        : "Start a conversation to track progress"}
                    </p>
                  </div>
                )}
              </ScrollArea>

              {isLeafTask && (
                <div className="space-y-2">
                  <Textarea
                    placeholder="Add a discussion point..."
                    value={newDiscussion}
                    onChange={(e) => setNewDiscussion(e.target.value)}
                    rows={3}
                  />
                  <Button onClick={handleAddDiscussion} disabled={!newDiscussion.trim()} className="w-full">
                    <Send className="h-4 w-4 mr-2" />
                    Add Discussion
                  </Button>
                </div>
              )}
            </div>
          </TabsContent>

          <TabsContent value="conclusions" className="mt-4">
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h4 className="font-medium">
                  {isFolder ? "Aggregated Conclusions from Child Tasks" : "Task Conclusions"}
                </h4>
                {isLeafTask && (
                  <Button size="sm" variant="outline" onClick={addQuickConclusion}>
                    <Plus className="h-4 w-4 mr-1" />
                    Quick Add
                  </Button>
                )}
              </div>

              <ScrollArea className="h-64 border rounded p-3">
                {conclusions.length > 0 ? (
                  <div className="space-y-3">
                    {isFolder && conclusionsByTask
                      ? // Grouped view for folders
                        Object.entries(conclusionsByTask).map(([taskId, taskConclusions]) => (
                          <div key={taskId} className="space-y-2">
                            <div className="flex items-center gap-2 py-1">
                              <Badge variant="outline" className="text-xs font-mono bg-green-50 text-green-700">
                                {taskId}
                              </Badge>
                              <span className="text-xs text-slate-500">
                                {taskConclusions.length} conclusion{taskConclusions.length !== 1 ? "s" : ""}
                              </span>
                            </div>
                            {taskConclusions.map((conclusion, index) => (
                              <div
                                key={conclusion?.id || `${taskId}-${index}`}
                                className="ml-4 pb-2 border-l-2 border-green-200 pl-3"
                              >
                                <div className="flex items-center gap-2 mb-1">
                                  <span className="text-sm font-medium">v{conclusion?.version || index + 1}</span>
                                  <span className="text-xs text-slate-500">by {conclusion?.author || "Unknown"}</span>
                                  <span className="text-xs text-slate-500">
                                    {conclusion?.timestamp
                                      ? new Date(conclusion.timestamp).toLocaleString()
                                      : "Unknown time"}
                                  </span>
                                </div>
                                <p className="text-sm text-slate-700">{conclusion?.message || "No message"}</p>
                              </div>
                            ))}
                            <Separator className="my-3" />
                          </div>
                        ))
                      : // Simple view for leaf tasks
                        conclusions.map((conclusion, index) => (
                          <div key={conclusion?.id || index} className="pb-3 border-b last:border-b-0">
                            <div className="flex items-center gap-2 mb-1">
                              <span className="text-sm font-medium">v{conclusion?.version || index + 1}</span>
                              <span className="text-xs text-slate-500">by {conclusion?.author || "Unknown"}</span>
                              <span className="text-xs text-slate-500">
                                {conclusion?.timestamp
                                  ? new Date(conclusion.timestamp).toLocaleString()
                                  : "Unknown time"}
                              </span>
                            </div>
                            <p className="text-sm text-slate-700">{conclusion?.message || "No message"}</p>
                          </div>
                        ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-slate-500">
                    <GitCommit className="h-8 w-8 mx-auto mb-2 opacity-30" />
                    <p className="text-sm">{isFolder ? "No conclusions in child tasks yet" : "No conclusions yet"}</p>
                    <p className="text-xs mt-1">
                      {isFolder
                        ? "Conclusions from child tasks will appear here"
                        : "Document key decisions and outcomes"}
                    </p>
                  </div>
                )}
              </ScrollArea>

              {isLeafTask && (
                <div className="space-y-2">
                  <Textarea
                    placeholder="Add a conclusion..."
                    value={newConclusion}
                    onChange={(e) => setNewConclusion(e.target.value)}
                    rows={3}
                  />
                  <Button onClick={handleAddConclusion} disabled={!newConclusion.trim()} className="w-full">
                    <GitCommit className="h-4 w-4 mr-2" />
                    Add Conclusion
                  </Button>
                </div>
              )}
            </div>
          </TabsContent>

          {!isFolder && (
            <TabsContent value="ai-report" className="mt-4">
              <AIReportGenerator
                task={task}
                plan={plan}
                aggregation={aggregation}
                getTaskCompletionPercentage={getTaskCompletionPercentage}
              />
            </TabsContent>
          )}
        </Tabs>
      </CardContent>
    </Card>
  )
}
