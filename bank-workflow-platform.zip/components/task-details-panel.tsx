"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Separator } from "@/components/ui/separator"
import { Progress } from "@/components/ui/progress"
import { Checkbox } from "@/components/ui/checkbox"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  User,
  Calendar,
  MessageSquare,
  GitCommit,
  Bot,
  AlertCircle,
  Users,
  TrendingUp,
  Clock,
  FolderOpen,
  FileText,
  UserCheck,
  Download,
  Plus,
  CheckSquare,
  Send,
} from "lucide-react"
import type { Task, ReviewPlan, TaskAggregation, WorkingPaper } from "@/lib/types"
import { AIReportGenerator } from "@/components/ai-report-generator"

interface TaskDetailsPanelProps {
  task: Task
  plan: ReviewPlan
  aggregation: TaskAggregation
  isLeafTask: boolean
  onAddDiscussion: (taskId: string, message: string) => void
  onAddConclusion: (taskId: string, message: string) => void
  getTaskCompletionPercentage: (taskId: string) => number
  getTaskDifficulty: (taskId: string) => "Easy" | "Medium" | "Hard" | null
}

export function TaskDetailsPanel({
  task,
  plan,
  aggregation,
  isLeafTask,
  onAddDiscussion,
  onAddConclusion,
  getTaskCompletionPercentage,
  getTaskDifficulty,
}: TaskDetailsPanelProps) {
  const [isAttachPaperOpen, setIsAttachPaperOpen] = useState(false)
  const [newDiscussion, setNewDiscussion] = useState("")

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Easy":
        return "bg-emerald-100 text-emerald-700"
      case "Medium":
        return "bg-amber-100 text-amber-700"
      case "Hard":
        return "bg-red-100 text-red-700"
      default:
        return "bg-gray-100 text-gray-700"
    }
  }

  const getDifficultyIcon = (difficulty: string) => {
    switch (difficulty) {
      case "Easy":
        return <TrendingUp className="h-3 w-3" />
      case "Medium":
        return <Clock className="h-3 w-3" />
      case "Hard":
        return <AlertCircle className="h-3 w-3" />
      default:
        return <TrendingUp className="h-3 w-3" />
    }
  }

  const completionPercentage = !isLeafTask ? getTaskCompletionPercentage(task.id) : 0
  const taskDifficulty = getTaskDifficulty(task.id)

  // Get aggregated working papers for folders
  const getAggregatedWorkingPapers = (): WorkingPaper[] => {
    if (isLeafTask) {
      return task.working_papers || []
    }

    // For folders, collect working papers from all child tasks
    const allPapers: WorkingPaper[] = [...(task.working_papers || [])]

    const collectFromChildren = (children: Task[]) => {
      children.forEach((child) => {
        if (child.working_papers) {
          allPapers.push(...child.working_papers)
        }
        const grandChildren = aggregation.childTasks.filter((t) => t.parent_id === child.id)
        if (grandChildren.length > 0) {
          collectFromChildren(grandChildren)
        }
      })
    }

    collectFromChildren(aggregation.childTasks)

    // Remove duplicates based on paper ID
    const uniquePapers = allPapers.filter((paper, index, self) => index === self.findIndex((p) => p.id === paper.id))

    return uniquePapers
  }

  const aggregatedWorkingPapers = getAggregatedWorkingPapers()

  // Mock working papers for demonstration
  const mockAvailablePapers: WorkingPaper[] = [
    {
      id: "WP-001",
      name: "Risk Assessment Template",
      description: "Standard template for conducting risk assessments",
      file_name: "risk_assessment_template.xlsx",
      file_size: "2.3 MB",
      uploaded_by: "John Smith",
      uploaded_at: "2024-01-15T10:30:00Z",
      resolved: false,
    },
    {
      id: "WP-002",
      name: "Compliance Checklist",
      description: "Comprehensive checklist for regulatory compliance review",
      file_name: "compliance_checklist.pdf",
      file_size: "1.8 MB",
      uploaded_by: "Sarah Johnson",
      uploaded_at: "2024-01-16T14:20:00Z",
      resolved: true,
    },
  ]

  const handleTogglePaperResolved = (paperId: string) => {
    // This would update the working paper's resolved status
    console.log(`Toggle resolved status for paper ${paperId}`)
  }

  const handleSubmitDiscussion = () => {
    if (newDiscussion.trim()) {
      onAddDiscussion(task.id, newDiscussion.trim())
      setNewDiscussion("")
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && e.ctrlKey) {
      handleSubmitDiscussion()
    }
  }

  return (
    <Card className="h-fit shadow-sm bg-white border-slate-200">
      <CardHeader className="border-b bg-slate-50">
        <CardTitle className="flex items-center justify-between">
          <span className="flex items-center gap-3">
            {isLeafTask ? (
              <>
                <FileText className="h-5 w-5 text-green-600" />
                <div className="flex items-center gap-2">
                  <span className="text-slate-800">{task.id}</span>
                  <Badge variant="outline" className="text-xs bg-green-50 text-green-700 border-green-200">
                    TASK
                  </Badge>
                </div>
              </>
            ) : (
              <>
                <FolderOpen className="h-5 w-5 text-blue-600" />
                <div className="flex items-center gap-2">
                  <span className="text-slate-800">{task.id}</span>
                  <Badge variant="outline" className="text-xs bg-blue-50 text-blue-700 border-blue-200">
                    FOLDER
                  </Badge>
                </div>
              </>
            )}
          </span>
          <div className="flex items-center gap-2">
            <Badge
              variant={task.completed ? "default" : "secondary"}
              className={
                task.completed ? "bg-green-100 text-green-700 border-green-200" : "bg-slate-100 text-slate-700"
              }
            >
              {task.completed ? "Completed" : "In Progress"}
            </Badge>
            {/* Only show difficulty badge if there's a difficulty */}
            {taskDifficulty && (
              <Badge className={getDifficultyColor(taskDifficulty)}>
                {getDifficultyIcon(taskDifficulty)}
                {taskDifficulty}
                {!isLeafTask && <span className="ml-1">(avg)</span>}
              </Badge>
            )}
          </div>
        </CardTitle>
        <CardDescription className="text-base font-medium text-slate-700">{task.name}</CardDescription>
        {!isLeafTask && (
          <div className="text-xs text-blue-600 bg-blue-50 px-2 py-1 rounded border border-blue-200">
            📁 This folder contains {aggregation.childTasks.length} items and serves as an organizational container
          </div>
        )}
        {isLeafTask && (
          <div className="text-xs text-green-600 bg-green-50 px-2 py-1 rounded border border-green-200">
            📋 This is an executable task that can be assigned and completed
          </div>
        )}
      </CardHeader>
      <CardContent className="p-6">
        <div className="space-y-6">
          <p className="text-sm text-slate-600 leading-relaxed">{task.description}</p>

          <div className="flex items-center gap-6 text-sm">
            {/* Assignment Info */}
            {isLeafTask && task.assigned_to ? (
              <div className="flex items-center gap-2">
                <User className="h-4 w-4 text-blue-500" />
                <span className="font-medium text-slate-700">{task.assigned_to}</span>
                <span className="text-xs text-blue-600">(assigned)</span>
              </div>
            ) : !isLeafTask && task.responsible_person ? (
              <div className="flex items-center gap-2">
                <UserCheck className="h-4 w-4 text-blue-500" />
                <span className="font-medium text-slate-700">{task.responsible_person}</span>
                <span className="text-xs text-blue-600">(responsible)</span>
              </div>
            ) : null}

            {/* Days Required - Only show for tasks (not folders) and if > 0 */}
            {isLeafTask && task.days_required > 0 && (
              <div className="flex items-center gap-2">
                <Calendar className="h-4 w-4 text-green-500" />
                <span className="text-slate-700">{task.days_required} days</span>
              </div>
            )}
          </div>

          {!isLeafTask && (
            <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-4 rounded-lg border border-blue-200">
              <div className="flex items-center gap-2 mb-3">
                <Users className="h-4 w-4 text-blue-600" />
                <span className="text-sm font-medium text-blue-900">Parent Task Progress</span>
              </div>
              {aggregation.childTasks.filter(
                (t) => !t.is_folder && !aggregation.childTasks.some((ct) => ct.parent_id === t.id),
              ).length > 0 ? (
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-blue-700">
                      {
                        aggregation.childTasks.filter(
                          (t) => !t.is_folder && !aggregation.childTasks.some((ct) => ct.parent_id === t.id),
                        ).length
                      }{" "}
                      executable tasks
                    </span>
                    <span className="text-sm font-medium text-blue-900">{completionPercentage}%</span>
                  </div>
                  <Progress value={completionPercentage} className="h-3" />
                  <p className="text-xs text-blue-700">
                    Completion is automatically calculated based on executable task progress.
                    {taskDifficulty && ` Difficulty is averaged from tasks (${taskDifficulty}).`}
                  </p>
                </div>
              ) : (
                <div className="text-sm text-blue-700">
                  No executable tasks defined yet. Add tasks to this folder to track progress.
                </div>
              )}
            </div>
          )}

          <Tabs defaultValue="discussion" className="w-full">
            <TabsList className="grid w-full grid-cols-4 bg-white border border-slate-200">
              <TabsTrigger
                value="discussion"
                className="flex items-center gap-1 text-xs data-[state=active]:bg-slate-100"
              >
                <MessageSquare className="h-3 w-3" />
                Discussion
                {aggregation.totalDiscussions > 0 && (
                  <Badge variant="secondary" className="ml-1 text-xs bg-slate-100 text-slate-700">
                    {aggregation.totalDiscussions}
                  </Badge>
                )}
              </TabsTrigger>
              <TabsTrigger
                value="conclusions"
                className="flex items-center gap-1 text-xs data-[state=active]:bg-slate-100"
              >
                <GitCommit className="h-3 w-3" />
                Conclusions
                {aggregation.totalConclusions > 0 && (
                  <Badge variant="secondary" className="ml-1 text-xs bg-slate-100 text-slate-700">
                    {aggregation.totalConclusions}
                  </Badge>
                )}
              </TabsTrigger>
              <TabsTrigger
                value="working-papers"
                className="flex items-center gap-1 text-xs data-[state=active]:bg-slate-100"
              >
                <FileText className="h-3 w-3" />
                Papers
                {aggregatedWorkingPapers.length > 0 && (
                  <Badge variant="secondary" className="ml-1 text-xs bg-slate-100 text-slate-700">
                    {aggregatedWorkingPapers.length}
                  </Badge>
                )}
              </TabsTrigger>
              <TabsTrigger
                value="ai-report"
                className="flex items-center gap-1 text-xs data-[state=active]:bg-slate-100"
              >
                <Bot className="h-3 w-3" />
                AI Report
              </TabsTrigger>
            </TabsList>

            <TabsContent value="discussion" className="mt-6">
              <div className="space-y-4">
                {!isLeafTask && (
                  <div className="bg-amber-50 p-3 rounded-lg border border-amber-200">
                    <p className="text-xs text-amber-700">
                      <AlertCircle className="h-3 w-3 inline mr-1" />
                      Parent tasks show aggregated discussions from all child tasks. Add discussions to individual child
                      tasks to see them here.
                    </p>
                  </div>
                )}

                {/* Working Papers in Discussion View - Only show if there are papers */}
                {aggregatedWorkingPapers.length > 0 && (
                  <div className="space-y-3">
                    <h5 className="text-sm font-medium text-slate-700">
                      {isLeafTask ? "Attached Working Papers" : "Working Papers from Child Tasks"}
                    </h5>
                    <div className="space-y-2">
                      {aggregatedWorkingPapers.slice(0, 3).map((paper) => (
                        <div
                          key={paper.id}
                          className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg border border-slate-200"
                        >
                          <Checkbox
                            id={`paper-${paper.id}`}
                            checked={paper.resolved}
                            onCheckedChange={() => handleTogglePaperResolved(paper.id)}
                            disabled={!isLeafTask} // Only allow toggling for leaf tasks
                          />
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <FileText className="h-4 w-4 text-blue-500" />
                              <span className="text-sm font-medium text-slate-700">{paper.name}</span>
                              <Badge variant="outline" className="text-xs bg-white text-slate-700 border-slate-300">
                                {paper.id}
                              </Badge>
                              {paper.resolved && (
                                <Badge
                                  variant="default"
                                  className="text-xs bg-green-100 text-green-700 border-green-200"
                                >
                                  <CheckSquare className="h-3 w-3 mr-1" />
                                  Resolved
                                </Badge>
                              )}
                              {!isLeafTask && paper.task_id && (
                                <Badge variant="outline" className="text-xs bg-white text-slate-700 border-slate-300">
                                  {paper.task_id}
                                </Badge>
                              )}
                            </div>
                            <p className="text-xs text-slate-500 mt-1">{paper.description}</p>
                          </div>
                          <Button variant="ghost" size="sm" className="h-8 w-8 p-0 text-slate-500 hover:text-slate-700">
                            <Download className="h-3 w-3" />
                          </Button>
                        </div>
                      ))}
                      {aggregatedWorkingPapers.length > 3 && (
                        <p className="text-xs text-slate-500 text-center">
                          +{aggregatedWorkingPapers.length - 3} more papers (see Papers tab)
                        </p>
                      )}
                    </div>
                    <Separator />
                  </div>
                )}

                <div className="flex justify-between items-center">
                  <h4 className="text-sm font-medium text-slate-700">
                    {isLeafTask ? "Task Discussions" : "Aggregated Discussions"}
                  </h4>
                  <span className="text-xs text-slate-500">
                    {aggregation.totalDiscussions} total
                    {!isLeafTask && ` from ${aggregation.childTasks.length + 1} tasks`}
                  </span>
                </div>

                <ScrollArea className="h-64">
                  <div className="space-y-3">
                    {aggregation.discussions.length > 0 ? (
                      aggregation.discussions.map((discussion) => (
                        <div key={discussion.id} className="border-l-2 border-green-500 pl-3 pb-3">
                          <div className="flex items-center gap-2 mb-1">
                            <MessageSquare className="h-4 w-4 text-green-500" />
                            <span className="text-sm font-medium text-slate-700">{discussion.author}</span>
                            <span className="text-xs text-slate-500">
                              {new Date(discussion.timestamp).toLocaleString()}
                            </span>
                            {!isLeafTask && discussion.task_id !== task.id && (
                              <Badge variant="outline" className="text-xs bg-white text-slate-700 border-slate-300">
                                {discussion.task_id}
                              </Badge>
                            )}
                          </div>
                          <p className="text-sm text-slate-600">{discussion.message}</p>
                        </div>
                      ))
                    ) : (
                      <div className="text-center py-8 text-slate-500">
                        <MessageSquare className="h-8 w-8 mx-auto mb-2 opacity-50" />
                        <p className="text-sm">No discussions yet</p>
                        <p className="text-xs">
                          {isLeafTask
                            ? "Start the conversation below"
                            : "Add discussions to child tasks to see them here"}
                        </p>
                      </div>
                    )}
                  </div>
                </ScrollArea>

                {/* Add Discussion - Only for leaf tasks */}
                {isLeafTask && (
                  <>
                    <Separator />
                    <div className="space-y-2">
                      <Label htmlFor="discussion" className="text-slate-700">
                        Add Discussion Point
                      </Label>
                      <Textarea
                        id="discussion"
                        placeholder="Enter your message... (Ctrl+Enter to send)"
                        value={newDiscussion}
                        onChange={(e) => setNewDiscussion(e.target.value)}
                        onKeyDown={handleKeyDown}
                        rows={3}
                        className="border-slate-300 focus:border-blue-500"
                      />
                      <Button
                        size="sm"
                        onClick={handleSubmitDiscussion}
                        disabled={!newDiscussion.trim()}
                        className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                      >
                        <Send className="h-4 w-4 mr-2" />
                        Add Discussion Point
                      </Button>
                    </div>
                  </>
                )}
              </div>
            </TabsContent>

            <TabsContent value="conclusions" className="mt-6">
              <div className="space-y-4">
                {!isLeafTask && (
                  <div className="bg-amber-50 p-3 rounded-lg border border-amber-200">
                    <p className="text-xs text-amber-700">
                      <AlertCircle className="h-3 w-3 inline mr-1" />
                      Parent tasks show aggregated conclusions from all child tasks. Add conclusions to individual child
                      tasks to see them here.
                    </p>
                  </div>
                )}

                <div className="flex justify-between items-center">
                  <h4 className="text-sm font-medium text-slate-700">
                    {isLeafTask ? "Conclusion History" : "Aggregated Conclusions"}
                  </h4>
                  <Badge variant="outline" className="bg-white text-slate-700 border-slate-300">
                    {aggregation.totalConclusions} total
                    {!isLeafTask && ` from ${aggregation.childTasks.length + 1} tasks`}
                  </Badge>
                </div>

                <ScrollArea className="h-64">
                  <div className="space-y-3">
                    {aggregation.conclusions.length > 0 ? (
                      aggregation.conclusions.map((conclusion) => (
                        <div key={conclusion.id} className="border-l-2 border-blue-500 pl-3 pb-3">
                          <div className="flex items-center gap-2 mb-1">
                            <GitCommit className="h-4 w-4 text-blue-500" />
                            <span className="text-sm font-medium text-slate-700">v{conclusion.version}</span>
                            <span className="text-xs text-slate-500">by {conclusion.author}</span>
                            {!isLeafTask && conclusion.task_id !== task.id && (
                              <Badge variant="outline" className="text-xs bg-white text-slate-700 border-slate-300">
                                {conclusion.task_id}
                              </Badge>
                            )}
                          </div>
                          <p className="text-sm text-slate-600 mb-1">{conclusion.message}</p>
                          <span className="text-xs text-slate-500">
                            {new Date(conclusion.timestamp).toLocaleString()}
                          </span>
                        </div>
                      ))
                    ) : (
                      <div className="text-center py-8 text-slate-500">
                        <GitCommit className="h-8 w-8 mx-auto mb-2 opacity-50" />
                        <p className="text-sm">No conclusions yet</p>
                        <p className="text-xs">
                          {isLeafTask
                            ? "Document key decisions below"
                            : "Add conclusions to child tasks to see them here"}
                        </p>
                      </div>
                    )}
                  </div>
                </ScrollArea>

                {isLeafTask && (
                  <>
                    <Separator />
                    <div className="space-y-2">
                      <Label htmlFor="conclusion" className="text-slate-700">
                        Add Conclusion
                      </Label>
                      <Textarea
                        id="conclusion"
                        placeholder="Enter conclusion..."
                        className="border-slate-300 focus:border-blue-500"
                        onKeyDown={(e) => {
                          if (e.key === "Enter" && e.ctrlKey) {
                            const target = e.target as HTMLTextAreaElement
                            if (target.value.trim()) {
                              onAddConclusion(task.id, target.value.trim())
                              target.value = ""
                            }
                          }
                        }}
                      />
                      <Button
                        size="sm"
                        onClick={() => {
                          const textarea = document.getElementById("conclusion") as HTMLTextAreaElement
                          if (textarea.value.trim()) {
                            onAddConclusion(task.id, textarea.value.trim())
                            textarea.value = ""
                          }
                        }}
                        className="bg-blue-600 hover:bg-blue-700 text-white"
                      >
                        Add Conclusion
                      </Button>
                    </div>
                  </>
                )}
              </div>
            </TabsContent>

            <TabsContent value="working-papers" className="mt-6">
              <div className="space-y-4">
                {!isLeafTask && (
                  <div className="bg-amber-50 p-3 rounded-lg border border-amber-200">
                    <p className="text-xs text-amber-700">
                      <AlertCircle className="h-3 w-3 inline mr-1" />
                      Folders show aggregated working papers from all child tasks. Attach papers to individual tasks to
                      see them here.
                    </p>
                  </div>
                )}

                <div className="flex justify-between items-center">
                  <h4 className="text-sm font-medium text-slate-700">
                    {isLeafTask ? "Attached Working Papers" : "Aggregated Working Papers"}
                  </h4>
                  <Badge variant="outline" className="bg-white text-slate-700 border-slate-300">
                    {aggregatedWorkingPapers.length} papers
                    {!isLeafTask && aggregatedWorkingPapers.length > 0 && " from child tasks"}
                  </Badge>
                </div>

                <ScrollArea className="h-64">
                  <div className="space-y-3">
                    {aggregatedWorkingPapers.length > 0 ? (
                      aggregatedWorkingPapers.map((paper) => (
                        <div key={paper.id} className="border rounded-lg p-3 bg-slate-50 border-slate-200">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <FileText className="h-4 w-4 text-blue-500" />
                                <span className="text-sm font-medium text-slate-700">{paper.name}</span>
                                <Badge variant="outline" className="text-xs bg-white text-slate-700 border-slate-300">
                                  {paper.id}
                                </Badge>
                                {paper.resolved && (
                                  <Badge
                                    variant="default"
                                    className="text-xs bg-green-100 text-green-700 border-green-200"
                                  >
                                    <CheckSquare className="h-3 w-3 mr-1" />
                                    Resolved
                                  </Badge>
                                )}
                                {!isLeafTask && paper.task_id && (
                                  <Badge variant="outline" className="text-xs bg-white text-slate-700 border-slate-300">
                                    {paper.task_id}
                                  </Badge>
                                )}
                              </div>
                              <p className="text-xs text-slate-500 mb-2">{paper.description}</p>
                              <div className="flex items-center gap-4 text-xs text-slate-500">
                                <span>{paper.file_name}</span>
                                <span>{paper.file_size}</span>
                                <span>by {paper.uploaded_by}</span>
                              </div>
                            </div>
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-8 w-8 p-0 text-slate-500 hover:text-slate-700"
                            >
                              <Download className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="text-center py-8 text-slate-500">
                        <FileText className="h-8 w-8 mx-auto mb-2 opacity-50" />
                        <p className="text-sm">No working papers {isLeafTask ? "attached" : "found"}</p>
                        <p className="text-xs">
                          {isLeafTask
                            ? "Attach papers to track task-related documents"
                            : "Attach papers to child tasks to see them here"}
                        </p>
                      </div>
                    )}
                  </div>
                </ScrollArea>

                {/* Attach Paper Button - Only for leaf tasks */}
                {isLeafTask && (
                  <div className="pt-2 border-t">
                    <Dialog open={isAttachPaperOpen} onOpenChange={setIsAttachPaperOpen}>
                      <DialogTrigger asChild>
                        <Button
                          size="sm"
                          variant="outline"
                          className="w-full border-slate-300 text-slate-700 hover:bg-slate-50"
                        >
                          <Plus className="h-3 w-3 mr-2" />
                          Attach Working Paper
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="bg-white">
                        <DialogHeader>
                          <DialogTitle className="text-slate-800">Attach Working Paper</DialogTitle>
                          <DialogDescription className="text-slate-600">
                            Select a working paper to attach to this task
                          </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4 max-h-96 overflow-y-auto">
                          {mockAvailablePapers.map((paper) => (
                            <div
                              key={paper.id}
                              className="flex items-center gap-3 p-3 border rounded-lg border-slate-200"
                            >
                              <Checkbox id={`attach-${paper.id}`} />
                              <div className="flex-1">
                                <div className="flex items-center gap-2 mb-1">
                                  <FileText className="h-4 w-4 text-blue-500" />
                                  <span className="text-sm font-medium text-slate-700">{paper.name}</span>
                                  <Badge variant="outline" className="text-xs bg-white text-slate-700 border-slate-300">
                                    {paper.id}
                                  </Badge>
                                </div>
                                <p className="text-xs text-slate-500">{paper.description}</p>
                                <div className="flex items-center gap-2 text-xs text-slate-500 mt-1">
                                  <span>{paper.file_name}</span>
                                  <span>•</span>
                                  <span>{paper.file_size}</span>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                        <DialogFooter>
                          <Button
                            variant="outline"
                            onClick={() => setIsAttachPaperOpen(false)}
                            className="border-slate-300 text-slate-700 hover:bg-slate-50"
                          >
                            Cancel
                          </Button>
                          <Button
                            onClick={() => setIsAttachPaperOpen(false)}
                            className="bg-blue-600 hover:bg-blue-700 text-white"
                          >
                            Attach Selected Papers
                          </Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  </div>
                )}
              </div>
            </TabsContent>

            <TabsContent value="ai-report" className="mt-6">
              <AIReportGenerator
                task={task}
                plan={plan}
                aggregation={aggregation}
                getTaskCompletionPercentage={getTaskCompletionPercentage}
              />
            </TabsContent>
          </Tabs>
        </div>
      </CardContent>
    </Card>
  )
}
