"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  ChevronDown,
  ChevronRight,
  Edit,
  Trash2,
  CheckSquare,
  Square,
  User,
  Calendar,
  AlertCircle,
  TrendingUp,
  Clock,
  FolderOpen,
  FileText,
  MessageSquare,
  GitCommit,
  UserCheck,
} from "lucide-react"
import type { Task } from "@/lib/types"

interface TaskTreeProps {
  tasks: Task[]
  onTaskSelect: (task: Task) => void
  onTaskEdit: (task: Task) => void
  onTaskDelete: (id: string) => void
  onTaskToggle: (id: string) => void
  selectedTaskId?: string
  getTaskCompletionPercentage: (taskId: string) => number
  getTaskDifficulty: (taskId: string) => "Easy" | "Medium" | "Hard" | null
  isLeafTask: (taskId: string) => boolean
}

export function TaskTree({
  tasks,
  onTaskSelect,
  onTaskEdit,
  onTaskDelete,
  onTaskToggle,
  selectedTaskId,
  getTaskCompletionPercentage,
  getTaskDifficulty,
  isLeafTask,
}: TaskTreeProps) {
  const [expandedNodes, setExpandedNodes] = useState<Set<string>>(new Set())

  const toggleExpanded = (taskId: string) => {
    const newExpanded = new Set(expandedNodes)
    if (newExpanded.has(taskId)) {
      newExpanded.delete(taskId)
    } else {
      newExpanded.add(taskId)
    }
    setExpandedNodes(newExpanded)
  }

  const getChildTasks = (parentId: string | null) => {
    return tasks.filter((task) => task.parent_id === parentId)
  }

  const hasChildren = (taskId: string) => {
    return tasks.some((task) => task.parent_id === taskId)
  }

  // Check if item is a folder (either explicitly marked or has children)
  const isFolder = (task: Task) => {
    return task.is_folder === true || hasChildren(task.id)
  }

  // Check if item is an executable task (not a folder and no children)
  const isExecutableTask = (task: Task) => {
    return !task.is_folder && !hasChildren(task.id)
  }

  // Get leaf tasks under a parent
  const getLeafTasksUnder = (parentId: string): Task[] => {
    const getAllDescendants = (taskId: string): Task[] => {
      const children = tasks.filter((task) => task.parent_id === taskId)
      let allDescendants: Task[] = []

      children.forEach((child) => {
        const hasChildren = tasks.some((t) => t.parent_id === child.id)
        if (!hasChildren && !child.is_folder) {
          // This is a leaf task (executable task)
          allDescendants.push(child)
        } else {
          // This has children, get their descendants
          allDescendants = allDescendants.concat(getAllDescendants(child.id))
        }
      })

      return allDescendants
    }

    return getAllDescendants(parentId)
  }

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Easy":
        return "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400"
      case "Medium":
        return "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-400"
      case "Hard":
        return "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400"
      default:
        return "bg-gray-100 text-gray-700 dark:bg-gray-900/30 dark:text-gray-400"
    }
  }

  const getDifficultyIcon = (difficulty: string) => {
    switch (difficulty) {
      case "Easy":
        return <TrendingUp className="h-3 w-3" />
      case "Medium":
        return <Clock className="h-3 w-3" />
      case "Hard":
        return <AlertCircle className="h-3 w-3" />
      default:
        return <TrendingUp className="h-3 w-3" />
    }
  }

  const renderTask = (task: Task, level = 0) => {
    const children = getChildTasks(task.id)
    const isExpanded = expandedNodes.has(task.id)
    const isSelected = selectedTaskId === task.id
    const isParent = hasChildren(task.id)
    const isFolderItem = isFolder(task)
    const isTaskItem = isExecutableTask(task)
    const completionPercentage = isParent ? getTaskCompletionPercentage(task.id) : 0
    const taskDifficulty = getTaskDifficulty(task.id)

    // For folders, get the count of leaf tasks underneath
    const leafTasksUnder = isFolderItem ? getLeafTasksUnder(task.id) : []
    const leafTaskCount = leafTasksUnder.length

    return (
      <div key={task.id} className="w-full">
        <div
          className={`group flex items-center gap-3 p-4 rounded-xl transition-all duration-200 cursor-pointer border-2 ${
            isSelected
              ? "bg-blue-50 border-blue-200 shadow-md"
              : "border-transparent hover:border-slate-200 hover:bg-slate-50"
          } ${isFolderItem ? "bg-gradient-to-r from-blue-50 to-blue-100" : ""}`}
          style={{ marginLeft: `${level * 32}px` }}
          onClick={() => onTaskSelect(task)}
        >
          {/* Expand/Collapse Button */}
          <div className="flex items-center">
            {isParent ? (
              <Button
                variant="ghost"
                size="sm"
                className="h-8 w-8 p-0 hover:bg-slate-200"
                onClick={(e) => {
                  e.stopPropagation()
                  toggleExpanded(task.id)
                }}
              >
                {isExpanded ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
              </Button>
            ) : (
              <div className="w-8" />
            )}
          </div>

          {/* Item Type Icon & Label */}
          <div className="flex items-center">
            {isFolderItem ? (
              <div className="flex items-center gap-1">
                <FolderOpen className="h-5 w-5 text-blue-600" />
                <span className="text-xs text-blue-600 font-medium">FOLDER</span>
              </div>
            ) : (
              <div className="flex items-center gap-1">
                <FileText className="h-5 w-5 text-green-600" />
                <span className="text-xs text-green-600 font-medium">TASK</span>
              </div>
            )}
          </div>

          {/* Completion Checkbox - Only for executable tasks */}
          {isTaskItem ? (
            <Button
              variant="ghost"
              size="sm"
              className="h-8 w-8 p-0 hover:bg-slate-200"
              onClick={(e) => {
                e.stopPropagation()
                onTaskToggle(task.id)
              }}
            >
              {task.completed ? (
                <CheckSquare className="h-5 w-5 text-green-600" />
              ) : (
                <Square className="h-5 w-5 text-slate-400" />
              )}
            </Button>
          ) : (
            <div className="w-8" />
          )}

          {/* Task Content */}
          <div className="flex-1 min-w-0 space-y-3">
            {/* Task Header */}
            <div className="flex items-center gap-3 flex-wrap">
              <span
                className={`text-sm font-semibold ${
                  task.completed ? "line-through text-muted-foreground" : "text-slate-900"
                }`}
              >
                {task.id}
              </span>
              <span
                className={`text-sm font-medium ${
                  task.completed ? "line-through text-muted-foreground" : "text-slate-700"
                }`}
              >
                {task.name}
              </span>

              {/* Difficulty Badge - Only show if there's a difficulty */}
              {taskDifficulty && (
                <Badge className={`text-xs font-medium ${getDifficultyColor(taskDifficulty)}`}>
                  {getDifficultyIcon(taskDifficulty)}
                  {taskDifficulty}
                  {isFolderItem && <span className="ml-1">(avg)</span>}
                </Badge>
              )}

              {/* Type Badge */}
              {isFolderItem ? (
                <Badge variant="secondary" className="text-xs bg-blue-100 text-blue-700">
                  <FolderOpen className="h-3 w-3 mr-1" />
                  Folder ({leafTaskCount > 0 ? `${leafTaskCount} tasks` : `${children.length} items`})
                </Badge>
              ) : (
                <Badge variant="outline" className="text-xs bg-green-50 text-green-700 border-green-200">
                  <FileText className="h-3 w-3 mr-1" />
                  Task
                </Badge>
              )}
            </div>

            {/* Progress Bar for Folders - Only show if there are leaf tasks */}
            {isFolderItem && leafTaskCount > 0 && (
              <div className="flex items-center gap-3">
                <Progress value={completionPercentage} className="flex-1 h-2" />
                <span className="text-xs font-semibold text-slate-600 min-w-[3rem]">{completionPercentage}%</span>
              </div>
            )}

            {/* No Tasks Message for Empty Folders */}
            {isFolderItem && leafTaskCount === 0 && children.length === 0 && (
              <div className="text-xs text-muted-foreground italic">Empty folder - no tasks defined</div>
            )}

            {/* Item Details */}
            <div className="flex items-center gap-6 text-xs text-muted-foreground">
              {/* Assignment/Responsibility Info */}
              {isTaskItem && task.assigned_to ? (
                <div className="flex items-center gap-2">
                  <User className="h-3 w-3" />
                  <span className="font-medium">{task.assigned_to}</span>
                </div>
              ) : isFolderItem && task.responsible_person ? (
                <div className="flex items-center gap-2">
                  <UserCheck className="h-3 w-3 text-blue-500" />
                  <span className="font-medium">{task.responsible_person}</span>
                  <span className="text-xs text-blue-600">(responsible)</span>
                </div>
              ) : null}

              {/* Days Required - Only show for tasks (not folders) and if > 0 */}
              {isTaskItem && task.days_required > 0 && (
                <div className="flex items-center gap-2">
                  <Calendar className="h-3 w-3" />
                  <span>{task.days_required} days</span>
                </div>
              )}

              {/* Discussion and Conclusion Counts */}
              {(task.discussions.length > 0 || task.conclusions.length > 0) && (
                <div className="flex items-center gap-3">
                  {task.discussions.length > 0 && (
                    <div className="flex items-center gap-1">
                      <MessageSquare className="h-3 w-3 text-blue-500" />
                      <span className="font-medium">{task.discussions.length}</span>
                    </div>
                  )}
                  {task.conclusions.length > 0 && (
                    <div className="flex items-center gap-1">
                      <GitCommit className="h-3 w-3 text-green-500" />
                      <span className="font-medium">{task.conclusions.length}</span>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
            <Button
              variant="ghost"
              size="sm"
              className="h-8 w-8 p-0 hover:bg-blue-100"
              onClick={(e) => {
                e.stopPropagation()
                onTaskEdit(task)
              }}
            >
              <Edit className="h-4 w-4 text-blue-600" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="h-8 w-8 p-0 hover:bg-red-100"
              onClick={(e) => {
                e.stopPropagation()
                onTaskDelete(task.id)
              }}
            >
              <Trash2 className="h-4 w-4 text-red-600" />
            </Button>
          </div>
        </div>

        {/* Child Tasks */}
        {isExpanded && children.length > 0 && (
          <div className="mt-2 space-y-2">{children.map((child) => renderTask(child, level + 1))}</div>
        )}
      </div>
    )
  }

  const rootTasks = getChildTasks(null)

  return (
    <div className="space-y-3">
      {rootTasks.length > 0 ? (
        rootTasks.map((task) => renderTask(task))
      ) : (
        <div className="text-center py-16 text-muted-foreground">
          <div className="bg-slate-100 rounded-full w-24 h-24 flex items-center justify-center mx-auto mb-6">
            <CheckSquare className="h-12 w-12 opacity-50" />
          </div>
          <h3 className="text-lg font-semibold mb-2">No items found</h3>
          <p className="text-sm">Create your first folder or task to get started with this plan</p>
        </div>
      )}
    </div>
  )
}
