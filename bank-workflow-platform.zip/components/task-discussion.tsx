"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { ScrollArea } from "@/components/ui/scroll-area"
import { MessageSquare, Send } from "lucide-react"
import type { Task } from "@/lib/types"

interface TaskDiscussionProps {
  task: Task
  onAddDiscussion: (taskId: string, message: string) => void
}

export function TaskDiscussion({ task, onAddDiscussion }: TaskDiscussionProps) {
  const [newMessage, setNewMessage] = useState("")

  const handleSubmit = () => {
    if (newMessage.trim()) {
      onAddDiscussion(task.id, newMessage.trim())
      setNewMessage("")
    }
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && e.ctrlKey) {
      handleSubmit()
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h4 className="text-sm font-medium">Discussion Points</h4>
        <span className="text-xs text-muted-foreground">{task.discussions.length} messages</span>
      </div>

      <ScrollArea className="h-64">
        <div className="space-y-3">
          {task.discussions.length > 0 ? (
            task.discussions.map((discussion) => (
              <div key={discussion.id} className="border-l-2 border-green-500 pl-3 pb-3">
                <div className="flex items-center gap-2 mb-1">
                  <MessageSquare className="h-4 w-4 text-green-500" />
                  <span className="text-sm font-medium">{discussion.author}</span>
                  <span className="text-xs text-muted-foreground">
                    {new Date(discussion.timestamp).toLocaleString()}
                  </span>
                </div>
                <p className="text-sm text-muted-foreground">{discussion.message}</p>
              </div>
            ))
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <MessageSquare className="h-8 w-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">No discussions yet</p>
              <p className="text-xs">Start the conversation below</p>
            </div>
          )}
        </div>
      </ScrollArea>

      <div className="space-y-2">
        <Label htmlFor="discussion">Add Discussion Point</Label>
        <Textarea
          id="discussion"
          placeholder="Enter your message... (Ctrl+Enter to send)"
          value={newMessage}
          onChange={(e) => setNewMessage(e.target.value)}
          onKeyDown={handleKeyDown}
          rows={3}
        />
        <Button size="sm" onClick={handleSubmit} disabled={!newMessage.trim()} className="w-full">
          <Send className="h-4 w-4 mr-2" />
          Add Discussion Point
        </Button>
      </div>
    </div>
  )
}
