"use client"

import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Separator } from "@/components/ui/separator"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import {
  Bot,
  Settings,
  RefreshCw,
  ChevronDown,
  ChevronRight,
  AlertTriangle,
  Sparkles,
  FileText,
  Copy,
  Download,
  Users,
} from "lucide-react"
import type { Task, ReviewPlan, TaskAggregation } from "@/lib/types"
import { useAIReport } from "@/hooks/use-ai-report"
import { useState } from "react"

interface AIReportGeneratorProps {
  task: Task
  plan: ReviewPlan
  aggregation: TaskAggregation
  getTaskCompletionPercentage: (taskId: string) => number
}

export function AIReportGenerator({ task, plan, aggregation, getTaskCompletionPercentage }: AIReportGeneratorProps) {
  const [showPrompt, setShowPrompt] = useState(false)
  const [activeTab, setActiveTab] = useState("report")

  const {
    currentPrompt,
    customPrompt,
    setCustomPrompt,
    isEditingPrompt,
    isGenerating,
    generateReport,
    handleGenerateReport,
    handleEditPrompt,
    handleSavePrompt,
    handleCancelPrompt,
  } = useAIReport(task, plan, aggregation, getTaskCompletionPercentage)

  const report = generateReport(currentPrompt)
  const isParentTask = aggregation.childTasks.length > 0

  const handleCopyReport = async () => {
    await navigator.clipboard.writeText(report.content)
  }

  const handleDownloadReport = () => {
    const blob = new Blob([report.content], { type: "text/markdown" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `${task.id}-report.md`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Bot className="h-5 w-5 text-purple-500" />
          <h4 className="text-sm font-medium">AI-Generated Report</h4>
          <Badge variant="outline" className="text-xs">
            {isEditingPrompt ? "Custom Prompt" : "Standard"}
          </Badge>
          {isParentTask && (
            <Badge variant="secondary" className="text-xs">
              <Users className="h-3 w-3 mr-1" />
              Aggregated
            </Badge>
          )}
        </div>
        <Button variant="ghost" size="sm" onClick={handleGenerateReport} disabled={isGenerating} className="text-xs">
          {isGenerating ? <RefreshCw className="h-3 w-3 mr-1 animate-spin" /> : <Sparkles className="h-3 w-3 mr-1" />}
          {isGenerating ? "Generating..." : "Regenerate"}
        </Button>
      </div>

      {/* Prompt Configuration */}
      <Collapsible open={showPrompt} onOpenChange={setShowPrompt}>
        <CollapsibleTrigger asChild>
          <Button variant="outline" size="sm" className="w-full justify-between text-xs">
            <div className="flex items-center gap-2">
              <Settings className="h-3 w-3" />
              AI Prompt Configuration
            </div>
            {showPrompt ? <ChevronDown className="h-3 w-3" /> : <ChevronRight className="h-3 w-3" />}
          </Button>
        </CollapsibleTrigger>
        <CollapsibleContent className="space-y-3 mt-3">
          <Card className="border-orange-200 bg-orange-50/50 dark:bg-orange-950/20 dark:border-orange-800">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-sm flex items-center gap-2">
                  <Settings className="h-4 w-4" />
                  Prompt Settings
                </CardTitle>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => handleEditPrompt(!isEditingPrompt)}
                  className="text-xs"
                >
                  {isEditingPrompt ? "Cancel Edit" : "Edit Prompt"}
                </Button>
              </div>
              <CardDescription className="flex items-start gap-2">
                <AlertTriangle className="h-4 w-4 text-orange-500 mt-0.5 flex-shrink-0" />
                <span className="text-xs">
                  Modifying the AI prompt may affect report quality and consistency. Use the default prompt for
                  standardized reports across all tasks.
                </span>
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {isEditingPrompt ? (
                <div className="space-y-3">
                  <Label htmlFor="custom-prompt" className="text-sm">
                    Custom Prompt
                  </Label>
                  <Textarea
                    id="custom-prompt"
                    value={customPrompt}
                    onChange={(e) => setCustomPrompt(e.target.value)}
                    rows={6}
                    className="text-xs font-mono resize-none"
                    placeholder="Enter your custom prompt..."
                  />
                  <div className="flex justify-end gap-2">
                    <Button variant="outline" size="sm" onClick={handleCancelPrompt}>
                      Cancel
                    </Button>
                    <Button size="sm" onClick={handleSavePrompt}>
                      Apply Custom Prompt
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="space-y-2">
                  <Label className="text-sm">Current Prompt</Label>
                  <ScrollArea className="h-24 w-full rounded border bg-muted/50 p-2">
                    <pre className="text-xs text-muted-foreground whitespace-pre-wrap font-mono">{currentPrompt}</pre>
                  </ScrollArea>
                </div>
              )}
            </CardContent>
          </Card>
        </CollapsibleContent>
      </Collapsible>

      <Separator />

      {/* Report Content */}
      <div className="space-y-4">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <div className="flex items-center justify-between">
            <TabsList className="grid w-full max-w-md grid-cols-1">
              <TabsTrigger value="report" className="flex items-center gap-1 text-xs">
                <FileText className="h-3 w-3" />
                Generated Report
              </TabsTrigger>
            </TabsList>

            {activeTab === "report" && (
              <div className="flex flex-col gap-2">
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="sm" onClick={handleCopyReport} className="text-xs">
                    <Copy className="h-3 w-3 mr-1" />
                    Copy
                  </Button>
                  <Button variant="outline" size="sm" onClick={handleDownloadReport} className="text-xs">
                    <Download className="h-3 w-3 mr-1" />
                    Download
                  </Button>
                </div>
              </div>
            )}
          </div>

          <TabsContent value="report" className="mt-4">
            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm">Analysis Report</CardTitle>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary" className="text-xs bg-blue-50 text-blue-700 border-blue-200">
                      Confidence: {report.metadata.confidence_level}
                    </Badge>
                    <Badge variant="secondary" className="text-xs bg-slate-100 text-slate-700 border-slate-300">
                      Generated: {new Date(report.generated_at).toLocaleTimeString()}
                    </Badge>
                    {isParentTask && (
                      <Badge variant="default" className="text-xs bg-emerald-100 text-emerald-700 border-emerald-200">
                        Aggregated Data
                      </Badge>
                    )}
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-96 w-full">
                  <div className="prose prose-sm max-w-none dark:prose-invert">
                    <pre className="whitespace-pre-wrap text-xs bg-slate-50 text-slate-800 p-4 rounded-lg border border-slate-200 font-sans leading-relaxed">
                      {report.content}
                    </pre>
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
