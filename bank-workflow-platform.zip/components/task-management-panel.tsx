"use client"

import React, { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { QuickActionButton } from "@/components/ui/quick-action-button"
import { StatusIndicator } from "@/components/ui/status-indicator"
import { ProgressRing } from "@/components/ui/progress-ring"
import { Plus, Search, CheckSquare, Target, FolderTree, Folder, FileText, Zap } from "lucide-react"
import type { ReviewPlan, Task } from "@/lib/types"
import { useTaskOperations } from "@/hooks/use-task-operations"
import { useTaskCalculations } from "@/hooks/use-task-calculations"
import { useTaskAggregation } from "@/hooks/use-task-aggregation"
import { useToast } from "@/hooks/use-toast"
import { EnhancedTaskTree } from "@/components/enhanced-task-tree"
import { TaskDetailsPanel } from "@/components/task-details-panel"
import { SimplifiedTaskCreation } from "@/components/simplified-task-creation"
import { TaskEditDialog } from "@/components/task-edit-dialog"
import { ConfirmationDialog } from "@/components/confirmation-dialog"

interface TaskManagementPanelProps {
  initialPlan: ReviewPlan
  onPlanUpdate?: (plan: ReviewPlan) => void
}

export function TaskManagementPanel({ initialPlan, onPlanUpdate }: TaskManagementPanelProps) {
  const [plan, setPlan] = useState<ReviewPlan>(initialPlan)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedTask, setSelectedTask] = useState<Task | null>(null)
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [editingTask, setEditingTask] = useState<Task | null>(null)
  const [confirmDialog, setConfirmDialog] = useState<{
    open: boolean
    title: string
    description: string
    action: () => void
    variant?: "default" | "destructive"
  }>({
    open: false,
    title: "",
    description: "",
    action: () => {},
  })

  const { success, error } = useToast()

  const handlePlanUpdate = (updatedPlan: ReviewPlan) => {
    setPlan(updatedPlan)
    onPlanUpdate?.(updatedPlan)
  }

  const { createTask, updateTask, deleteTask, toggleTaskCompletion, addDiscussion, addConclusion, isLoading } =
    useTaskOperations({
      plan,
      onPlanUpdate: handlePlanUpdate,
      onError: error,
      onSuccess: success,
    })

  const {
    isLeafTask,
    getTaskCompletionPercentage,
    getTaskDifficulty,
    getLeafTaskCount,
    getCompletedLeafTaskCount,
    getFolderCount,
  } = useTaskCalculations({ tasks: plan.tasks })

  const { selectedTaskAggregation } = useTaskAggregation(plan.tasks, selectedTask?.id)

  React.useEffect(() => {
    if (onPlanUpdate) {
      onPlanUpdate(plan)
    }
  }, [plan, onPlanUpdate])

  const filteredTasks = plan.tasks.filter(
    (task) =>
      task.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      task.id.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const handleDeleteTask = (taskId: string) => {
    const task = plan.tasks.find((t) => t.id === taskId)
    const hasChildren = plan.tasks.some((t) => t.parent_id === taskId)
    const childCount = plan.tasks.filter((t) => t.parent_id === taskId).length
    const itemType = isLeafTask(taskId) ? "task" : "folder"

    setConfirmDialog({
      open: true,
      title: `Delete ${itemType}`,
      description: `Delete ${itemType} "${task?.name}" (${taskId})? ${
        hasChildren ? `This will also delete ${childCount} child item(s). ` : ""
      }This action cannot be undone.`,
      action: async () => {
        await deleteTask(taskId)
        if (selectedTask?.id === taskId) {
          setSelectedTask(null)
        }
        setConfirmDialog({ ...confirmDialog, open: false })
      },
      variant: "destructive",
    })
  }

  const handleToggleCompletion = (taskId: string) => {
    const task = plan.tasks.find((t) => t.id === taskId)
    const hasChildren = plan.tasks.some((t) => t.parent_id === taskId)

    if (hasChildren) return

    setConfirmDialog({
      open: true,
      title: task?.completed ? "Mark Task as Incomplete" : "Mark Task as Complete",
      description: `Mark task "${task?.name}" (${taskId}) as ${task?.completed ? "incomplete" : "complete"}?`,
      action: async () => {
        const updatedTask = await toggleTaskCompletion(taskId)
        if (updatedTask && selectedTask?.id === taskId) {
          setSelectedTask(updatedTask)
        }
        setConfirmDialog({ ...confirmDialog, open: false })
      },
    })
  }

  const handleAddDiscussion = (taskId: string, message: string) => {
    setConfirmDialog({
      open: true,
      title: "Add Discussion",
      description: "Add this discussion point to the task history?",
      action: async () => {
        const discussion = await addDiscussion(taskId, message)
        if (discussion && selectedTask?.id === taskId) {
          setSelectedTask({
            ...selectedTask,
            discussions: [...selectedTask.discussions, discussion],
          })
        }
        setConfirmDialog({ ...confirmDialog, open: false })
      },
    })
  }

  const handleAddConclusion = (taskId: string, message: string) => {
    setConfirmDialog({
      open: true,
      title: "Add Conclusion",
      description: "Add this conclusion and create a new version in the task history?",
      action: async () => {
        const conclusion = await addConclusion(taskId, message)
        if (conclusion && selectedTask?.id === taskId) {
          setSelectedTask({
            ...selectedTask,
            conclusions: [...selectedTask.conclusions, conclusion],
          })
        }
        setConfirmDialog({ ...confirmDialog, open: false })
      },
    })
  }

  const leafTaskCount = getLeafTaskCount()
  const completedLeafTaskCount = getCompletedLeafTaskCount()
  const folderCount = getFolderCount()
  const overallProgress = leafTaskCount > 0 ? Math.round((completedLeafTaskCount / leafTaskCount) * 100) : 0

  return (
    <div className="space-y-6">
      {/* Enhanced Plan Status Header */}
      <Card className="border-l-4 border-l-blue-500 bg-gradient-to-r from-blue-50 via-white to-green-50">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-blue-100 rounded-xl">
                <Target className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <CardTitle className="text-xl text-slate-800">{plan.name}</CardTitle>
                <p className="text-sm text-slate-600 mt-1">{plan.description}</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <ProgressRing progress={overallProgress} size="lg" />
              <Badge variant="secondary" className="bg-blue-100 text-blue-700 px-3 py-1 text-sm">
                {plan.validation_status}
              </Badge>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Quick Stats & Actions */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-blue-700">{folderCount}</div>
            <div className="text-sm text-blue-600">Folders</div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-green-700">{leafTaskCount}</div>
            <div className="text-sm text-green-600">Tasks</div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-emerald-50 to-emerald-100 border-emerald-200">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-emerald-700">{completedLeafTaskCount}</div>
            <div className="text-sm text-emerald-600">Completed</div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-purple-700">{overallProgress}%</div>
            <div className="text-sm text-purple-600">Progress</div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Left Panel - Project Structure */}
        <div className="xl:col-span-2">
          <Card className="shadow-sm">
            <CardHeader className="border-b bg-gradient-to-r from-slate-50 to-blue-50">
              <div className="flex justify-between items-center">
                <CardTitle className="flex items-center gap-2">
                  <FolderTree className="h-5 w-5 text-blue-600" />
                  Project Structure
                </CardTitle>
                <div className="flex items-center gap-3">
                  <StatusIndicator
                    status={overallProgress >= 80 ? "success" : overallProgress >= 50 ? "pending" : "warning"}
                    message={`${overallProgress}% complete`}
                  />
                  <Button
                    size="sm"
                    className="shadow-sm bg-gradient-to-r from-blue-600 to-green-600 hover:from-blue-700 hover:to-green-700"
                    onClick={() => setIsCreateDialogOpen(true)}
                    disabled={isLoading}
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Create
                  </Button>
                </div>
              </div>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Search folders and tasks..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 bg-white"
                />
              </div>
            </CardHeader>
            <CardContent className="p-6">
              {plan.tasks.length === 0 && (
                <div className="text-center py-12">
                  <div className="bg-gradient-to-br from-blue-100 to-green-100 rounded-full w-24 h-24 flex items-center justify-center mx-auto mb-6">
                    <Zap className="h-12 w-12 text-blue-600" />
                  </div>
                  <h3 className="text-xl font-semibold mb-3 text-slate-800">Let's get started!</h3>
                  <p className="text-slate-600 mb-6 max-w-md mx-auto">
                    Create your first folder or task to organize your work and track progress effectively.
                  </p>
                  <div className="flex justify-center gap-4">
                    <QuickActionButton
                      icon={Folder}
                      label="Create Folder"
                      description="Organize work"
                      variant="folder"
                      onClick={() => setIsCreateDialogOpen(true)}
                    />
                    <QuickActionButton
                      icon={FileText}
                      label="Create Task"
                      description="Define work"
                      variant="task"
                      onClick={() => setIsCreateDialogOpen(true)}
                    />
                  </div>
                </div>
              )}

              {plan.tasks.length > 0 && (
                <EnhancedTaskTree
                  tasks={filteredTasks}
                  onTaskSelect={setSelectedTask}
                  onTaskEdit={setEditingTask}
                  onTaskDelete={handleDeleteTask}
                  onTaskToggle={handleToggleCompletion}
                  selectedTaskId={selectedTask?.id}
                  getTaskCompletionPercentage={getTaskCompletionPercentage}
                  getTaskDifficulty={getTaskDifficulty}
                  isLeafTask={isLeafTask}
                />
              )}
            </CardContent>
          </Card>
        </div>

        {/* Right Panel - Details */}
        <div>
          {selectedTask && selectedTaskAggregation ? (
            <TaskDetailsPanel
              task={selectedTask}
              plan={plan}
              aggregation={selectedTaskAggregation}
              isLeafTask={isLeafTask(selectedTask.id)}
              onAddDiscussion={handleAddDiscussion}
              onAddConclusion={handleAddConclusion}
              getTaskCompletionPercentage={getTaskCompletionPercentage}
              getTaskDifficulty={getTaskDifficulty}
            />
          ) : (
            <Card className="h-96 flex items-center justify-center shadow-sm bg-gradient-to-br from-slate-50 to-blue-50">
              <CardContent className="text-center">
                <div className="bg-gradient-to-br from-slate-100 to-blue-100 rounded-full w-20 h-20 flex items-center justify-center mx-auto mb-4">
                  <CheckSquare className="h-10 w-10 text-slate-400" />
                </div>
                <h3 className="text-lg font-medium text-slate-800 mb-2">Select an Item</h3>
                <p className="text-slate-600 text-sm max-w-xs">
                  Choose a folder or task from the structure to view details and manage progress
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* Dialogs */}
      {isCreateDialogOpen && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50">
          <SimplifiedTaskCreation
            plan={plan}
            onCreateTask={createTask}
            onClose={() => setIsCreateDialogOpen(false)}
            isLoading={isLoading}
          />
        </div>
      )}

      <TaskEditDialog
        task={editingTask}
        onClose={() => setEditingTask(null)}
        plan={plan}
        onUpdateTask={updateTask}
        isLoading={isLoading}
        isLeafTask={isLeafTask}
      />

      <ConfirmationDialog
        open={confirmDialog.open}
        onOpenChange={(open) => setConfirmDialog({ ...confirmDialog, open })}
        title={confirmDialog.title}
        description={confirmDialog.description}
        onConfirm={confirmDialog.action}
        variant={confirmDialog.variant}
      />
    </div>
  )
}
