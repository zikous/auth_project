"use client"

import { useMemo } from "react"
import type { Task, TaskAggregation, Discussion, Conclusion } from "@/lib/types"

export function useTaskAggregation(tasks: Task[], selectedTaskId?: string) {
  const taskMap = useMemo(() => {
    const map = new Map<string, Task>()
    tasks.forEach((task) => map.set(task.id, task))
    return map
  }, [tasks])

  const getChildTasks = useMemo(() => {
    return (parentId: string): Task[] => {
      return tasks.filter((task) => task.parent_id === parentId)
    }
  }, [tasks])

  const isLeafTask = useMemo(() => {
    return (taskId: string): boolean => {
      return !tasks.some((task) => task.parent_id === taskId)
    }
  }, [tasks])

  const getTaskAggregation = useMemo(() => {
    return (taskId: string): TaskAggregation => {
      const task = taskMap.get(taskId)
      if (!task) {
        return {
          discussions: [],
          conclusions: [],
          childTasks: [],
          totalDiscussions: 0,
          totalConclusions: 0,
        }
      }

      const childTasks = getChildTasks(taskId)
      const allDiscussions: Discussion[] = [...task.discussions]
      const allConclusions: Conclusion[] = [...task.conclusions]

      // Recursively collect discussions and conclusions from child tasks
      const collectFromChildren = (children: Task[]) => {
        children.forEach((child) => {
          allDiscussions.push(...child.discussions)
          allConclusions.push(...child.conclusions)
          const grandChildren = getChildTasks(child.id)
          if (grandChildren.length > 0) {
            collectFromChildren(grandChildren)
          }
        })
      }

      collectFromChildren(childTasks)

      // Sort by timestamp
      allDiscussions.sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime())
      allConclusions.sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime())

      return {
        discussions: allDiscussions,
        conclusions: allConclusions,
        childTasks,
        totalDiscussions: allDiscussions.length,
        totalConclusions: allConclusions.length,
      }
    }
  }, [taskMap, getChildTasks])

  const selectedTaskAggregation = useMemo(() => {
    return selectedTaskId ? getTaskAggregation(selectedTaskId) : null
  }, [selectedTaskId, getTaskAggregation])

  return {
    getChildTasks,
    isLeafTask,
    getTaskAggregation,
    selectedTaskAggregation,
  }
}
