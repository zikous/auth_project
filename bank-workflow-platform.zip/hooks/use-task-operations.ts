"use client"

import { useState, useCallback } from "react"
import { api } from "@/lib/api/mock-api"
import type { Task, ReviewPlan } from "@/lib/types"

interface UseTaskOperationsProps {
  plan: ReviewPlan
  onPlanUpdate: (plan: ReviewPlan) => void
  onError?: (error: string) => void
  onSuccess?: (message: string) => void
}

interface TaskCreationData {
  name: string
  description: string
  parent_id: string | null
  assigned_to?: string
  responsible_person?: string
  days_required: number
  difficulty: "Easy" | "Medium" | "Hard"
  is_folder: boolean
}

export function useTaskOperations({ plan, onPlanUpdate, onError, onSuccess }: UseTaskOperationsProps) {
  const [isLoading, setIsLoading] = useState(false)

  const createTask = useCallback(
    async (taskData: TaskCreationData) => {
      if (isLoading) return null

      setIsLoading(true)
      try {
        const response = await api.tasks.create({
          ...taskData,
          plan_id: plan.id,
          completed: false,
        })

        if (response.success) {
          // Update the plan with the new task
          const updatedPlan = {
            ...plan,
            tasks: [...plan.tasks, response.data],
          }
          onPlanUpdate(updatedPlan)
          onSuccess?.(response.message || "Task created successfully")
          return response.data
        }
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : "Failed to create task"
        onError?.(errorMessage)
      } finally {
        setIsLoading(false)
      }
      return null
    },
    [plan, onPlanUpdate, onError, onSuccess, isLoading],
  )

  const updateTask = useCallback(
    async (taskId: string, updates: Partial<Task>) => {
      if (isLoading) return null

      setIsLoading(true)
      try {
        const response = await api.tasks.update(taskId, updates)

        if (response.success) {
          // Update the plan with the modified task
          const updatedTasks = plan.tasks.map((task) => (task.id === taskId ? response.data : task))
          const updatedPlan = { ...plan, tasks: updatedTasks }
          onPlanUpdate(updatedPlan)
          onSuccess?.(response.message || "Task updated successfully")
          return response.data
        }
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : "Failed to update task"
        onError?.(errorMessage)
      } finally {
        setIsLoading(false)
      }
      return null
    },
    [plan, onPlanUpdate, onError, onSuccess, isLoading],
  )

  const deleteTask = useCallback(
    async (taskId: string) => {
      if (isLoading) return false

      setIsLoading(true)
      try {
        const response = await api.tasks.delete(taskId)

        if (response.success) {
          // Remove the task and its children from the plan
          const getChildTaskIds = (parentId: string): string[] => {
            const children = plan.tasks.filter((task) => task.parent_id === parentId)
            let allChildIds = children.map((child) => child.id)
            children.forEach((child) => {
              allChildIds = allChildIds.concat(getChildTaskIds(child.id))
            })
            return allChildIds
          }

          const taskIdsToDelete = [taskId, ...getChildTaskIds(taskId)]
          const updatedTasks = plan.tasks.filter((task) => !taskIdsToDelete.includes(task.id))
          const updatedPlan = { ...plan, tasks: updatedTasks }
          onPlanUpdate(updatedPlan)
          onSuccess?.(response.message || "Task deleted successfully")
          return true
        }
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : "Failed to delete task"
        onError?.(errorMessage)
      } finally {
        setIsLoading(false)
      }
      return false
    },
    [plan, onPlanUpdate, onError, onSuccess, isLoading],
  )

  const toggleTaskCompletion = useCallback(
    async (taskId: string) => {
      if (isLoading) return null

      setIsLoading(true)
      try {
        const response = await api.tasks.toggleCompletion(taskId)

        if (response.success) {
          // Update the plan with the modified task
          const updatedTasks = plan.tasks.map((task) => (task.id === taskId ? response.data : task))
          const updatedPlan = { ...plan, tasks: updatedTasks }
          onPlanUpdate(updatedPlan)
          onSuccess?.(response.message || "Task status updated")
          return response.data
        }
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : "Failed to update task status"
        onError?.(errorMessage)
      } finally {
        setIsLoading(false)
      }
      return null
    },
    [plan, onPlanUpdate, onError, onSuccess, isLoading],
  )

  const addDiscussion = useCallback(
    async (taskId: string, message: string) => {
      if (isLoading) return null

      setIsLoading(true)
      try {
        const response = await api.tasks.addDiscussion(taskId, message)

        if (response.success) {
          // Update the plan with the new discussion
          const updatedTasks = plan.tasks.map((task) =>
            task.id === taskId ? { ...task, discussions: [...task.discussions, response.data] } : task,
          )
          const updatedPlan = { ...plan, tasks: updatedTasks }
          onPlanUpdate(updatedPlan)
          onSuccess?.(response.message || "Discussion added")
          return response.data
        }
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : "Failed to add discussion"
        onError?.(errorMessage)
      } finally {
        setIsLoading(false)
      }
      return null
    },
    [plan, onPlanUpdate, onError, onSuccess, isLoading],
  )

  const addConclusion = useCallback(
    async (taskId: string, message: string) => {
      if (isLoading) return null

      setIsLoading(true)
      try {
        const response = await api.tasks.addConclusion(taskId, message)

        if (response.success) {
          // Update the plan with the new conclusion
          const updatedTasks = plan.tasks.map((task) =>
            task.id === taskId ? { ...task, conclusions: [...task.conclusions, response.data] } : task,
          )
          const updatedPlan = { ...plan, tasks: updatedTasks }
          onPlanUpdate(updatedPlan)
          onSuccess?.(response.message || "Conclusion added")
          return response.data
        }
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : "Failed to add conclusion"
        onError?.(errorMessage)
      } finally {
        setIsLoading(false)
      }
      return null
    },
    [plan, onPlanUpdate, onError, onSuccess, isLoading],
  )

  return {
    createTask,
    updateTask,
    deleteTask,
    toggleTaskCompletion,
    addDiscussion,
    addConclusion,
    isLoading,
  }
}
