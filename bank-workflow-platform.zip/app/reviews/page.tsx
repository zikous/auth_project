"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Plus, Search, Edit, Trash2, FileText } from "lucide-react"
import { mockReviews } from "@/lib/mock-data"
import type { Review } from "@/lib/types"

export default function ReviewsPage() {
  const [reviews, setReviews] = useState<Review[]>(mockReviews)
  const [searchTerm, setSearchTerm] = useState("")
  const [isCreateOpen, setIsCreateOpen] = useState(false)
  const [editingReview, setEditingReview] = useState<Review | null>(null)
  const [formData, setFormData] = useState({ name: "", description: "" })

  const filteredReviews = reviews.filter(
    (review) =>
      review.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      review.id.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const handleCreate = () => {
    const newReview: Review = {
      id: `RVW-${String(reviews.length + 1).padStart(3, "0")}`,
      name: formData.name,
      description: formData.description,
    }
    setReviews([...reviews, newReview])
    setFormData({ name: "", description: "" })
    setIsCreateOpen(false)
  }

  const handleEdit = (review: Review) => {
    setEditingReview(review)
    setFormData({ name: review.name, description: review.description })
  }

  const handleUpdate = () => {
    if (!editingReview) return
    setReviews(
      reviews.map((r) =>
        r.id === editingReview.id ? { ...r, name: formData.name, description: formData.description } : r,
      ),
    )
    setEditingReview(null)
    setFormData({ name: "", description: "" })
  }

  const handleDelete = (id: string) => {
    setReviews(reviews.filter((r) => r.id !== id))
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="container mx-auto p-6">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-slate-800 mb-2">Reviews Management</h1>
            <p className="text-slate-600">Manage individual review items and their details</p>
          </div>
          <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
            <DialogTrigger asChild>
              <Button className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white">
                <Plus className="h-4 w-4" />
                Create Review
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-white">
              <DialogHeader>
                <DialogTitle className="text-slate-800">Create New Review</DialogTitle>
                <DialogDescription className="text-slate-600">Add a new review item to the system</DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="name" className="text-slate-700">
                    Review Name
                  </Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Enter review name"
                    className="border-slate-300 focus:border-blue-500"
                  />
                </div>
                <div>
                  <Label htmlFor="description" className="text-slate-700">
                    Description
                  </Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Enter review description"
                    className="border-slate-300 focus:border-blue-500"
                  />
                </div>
              </div>
              <DialogFooter>
                <Button
                  variant="outline"
                  onClick={() => setIsCreateOpen(false)}
                  className="border-slate-300 text-slate-700 hover:bg-slate-50"
                >
                  Cancel
                </Button>
                <Button onClick={handleCreate} className="bg-blue-600 hover:bg-blue-700 text-white">
                  Create Review
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        {/* Search and Stats */}
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 h-4 w-4" />
            <Input
              placeholder="Search reviews by ID or name..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 border-slate-300 focus:border-blue-500"
            />
          </div>
          <div className="flex items-center gap-4">
            <Badge variant="secondary" className="text-sm bg-slate-100 text-slate-700 border-slate-200">
              {filteredReviews.length} of {reviews.length} reviews
            </Badge>
          </div>
        </div>

        {/* Reviews Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredReviews.map((review) => (
            <Card key={review.id} className="hover:shadow-md transition-shadow bg-white border-slate-200">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="flex items-center gap-2 text-lg text-slate-800">
                      <FileText className="h-5 w-5 text-blue-500" />
                      {review.id}
                    </CardTitle>
                    <CardDescription className="mt-1 text-slate-600">{review.name}</CardDescription>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleEdit(review)}
                      className="text-blue-600 hover:bg-blue-50"
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDelete(review.id)}
                      className="text-red-600 hover:bg-red-50"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-slate-600">{review.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Edit Dialog */}
        <Dialog open={!!editingReview} onOpenChange={() => setEditingReview(null)}>
          <DialogContent className="bg-white">
            <DialogHeader>
              <DialogTitle className="text-slate-800">Edit Review</DialogTitle>
              <DialogDescription className="text-slate-600">Update the review details</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="edit-name" className="text-slate-700">
                  Review Name
                </Label>
                <Input
                  id="edit-name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Enter review name"
                  className="border-slate-300 focus:border-blue-500"
                />
              </div>
              <div>
                <Label htmlFor="edit-description" className="text-slate-700">
                  Description
                </Label>
                <Textarea
                  id="edit-description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Enter review description"
                  className="border-slate-300 focus:border-blue-500"
                />
              </div>
            </div>
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setEditingReview(null)}
                className="border-slate-300 text-slate-700 hover:bg-slate-50"
              >
                Cancel
              </Button>
              <Button onClick={handleUpdate} className="bg-blue-600 hover:bg-blue-700 text-white">
                Update Review
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {filteredReviews.length === 0 && (
          <Card className="text-center py-12 bg-white border-slate-200">
            <CardContent>
              <FileText className="h-12 w-12 mx-auto text-slate-400 mb-4" />
              <h3 className="text-lg font-medium text-slate-800 mb-2">No reviews found</h3>
              <p className="text-slate-600 mb-4">
                {searchTerm ? "Try adjusting your search terms" : "Get started by creating your first review"}
              </p>
              {!searchTerm && (
                <Button onClick={() => setIsCreateOpen(true)} className="bg-blue-600 hover:bg-blue-700 text-white">
                  <Plus className="h-4 w-4 mr-2" />
                  Create Review
                </Button>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
