"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { FileText, Users, CheckSquare, Clock } from "lucide-react"
import Link from "next/link"
import { mockReviews, mockPlans, mockTasks } from "@/lib/mock-data"

export default function Dashboard() {
  const totalReviews = mockReviews.length
  const totalPlans = mockPlans.length

  // Count only leaf tasks (executable tasks, not folders)
  const leafTasks = mockTasks.filter((task) => {
    const hasChildren = mockTasks.some((t) => t.parent_id === task.id)
    return !task.is_folder && !hasChildren
  })

  const totalTasks = leafTasks.length
  const validatedPlans = mockPlans.filter((plan) => plan.validation_status === "Validated").length
  const startedPlans = mockPlans.filter((plan) => plan.validation_status === "Started").length
  const pendingTasks = leafTasks.filter((task) => !task.completed).length

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="container mx-auto p-6">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-slate-800 mb-2">Bank Workflow Dashboard</h1>
          <p className="text-slate-600">Productivity & Workflow Automation Platform</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
          <Card className="border-l-4 border-l-blue-500 bg-white shadow-sm hover:shadow-md transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-slate-700">Total Reviews</CardTitle>
              <FileText className="h-4 w-4 text-blue-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-slate-900">{totalReviews}</div>
              <p className="text-xs text-slate-500">Active review items</p>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-green-500 bg-white shadow-sm hover:shadow-md transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-slate-700">Review Plans</CardTitle>
              <Users className="h-4 w-4 text-green-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-slate-900">{totalPlans}</div>
              <p className="text-xs text-slate-500">
                {validatedPlans} validated, {startedPlans} started
              </p>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-l-orange-500 bg-white shadow-sm hover:shadow-md transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-slate-700">Active Tasks</CardTitle>
              <CheckSquare className="h-4 w-4 text-orange-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-slate-900">{totalTasks}</div>
              <p className="text-xs text-slate-500">{pendingTasks} pending completion</p>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          <Card className="bg-white shadow-sm hover:shadow-md transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-slate-800">
                <FileText className="h-5 w-5 text-blue-600" />
                Reviews Management
              </CardTitle>
              <CardDescription className="text-slate-600">
                Manage individual review items and their status
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm text-slate-700">Recent Reviews</span>
                <Badge variant="secondary" className="bg-slate-100 text-slate-700">
                  {totalReviews} total
                </Badge>
              </div>
              <div className="space-y-2">
                {mockReviews.slice(0, 3).map((review) => (
                  <div key={review.id} className="flex justify-between items-center p-2 bg-slate-50 rounded border">
                    <span className="text-sm font-medium text-slate-800">{review.id}</span>
                    <span className="text-xs text-slate-600">{review.name}</span>
                  </div>
                ))}
              </div>
              <Link href="/reviews">
                <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white">Manage Reviews</Button>
              </Link>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-sm hover:shadow-md transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-slate-800">
                <Users className="h-5 w-5 text-green-600" />
                Review Plans & Tasks
              </CardTitle>
              <CardDescription className="text-slate-600">
                Create plans and manage their associated tasks
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm text-slate-700">Active Plans</span>
                <Badge variant="secondary" className="bg-slate-100 text-slate-700">
                  {totalPlans} total
                </Badge>
              </div>
              <div className="space-y-2">
                {mockPlans.slice(0, 3).map((plan) => {
                  // Count only leaf tasks for this plan
                  const planLeafTasks = plan.tasks.filter((task) => {
                    const hasChildren = plan.tasks.some((t) => t.parent_id === task.id)
                    return !task.is_folder && !hasChildren
                  })
                  const planCompletedTasks = planLeafTasks.filter((task) => task.completed)

                  return (
                    <div key={plan.id} className="flex justify-between items-center p-2 bg-slate-50 rounded border">
                      <div className="flex-1">
                        <span className="text-sm font-medium text-slate-800">{plan.name}</span>
                        <div className="text-xs text-slate-600">
                          {planLeafTasks.length} tasks • {planCompletedTasks.length} completed
                        </div>
                      </div>
                      <Badge
                        variant={plan.validation_status === "Validated" ? "default" : "secondary"}
                        className={
                          plan.validation_status === "Validated"
                            ? "bg-green-100 text-green-700 border-green-200"
                            : "bg-slate-100 text-slate-700"
                        }
                      >
                        {plan.validation_status}
                      </Badge>
                    </div>
                  )
                })}
              </div>
              <Link href="/plans">
                <Button className="w-full bg-green-600 hover:bg-green-700 text-white">Manage Plans & Tasks</Button>
              </Link>
            </CardContent>
          </Card>
        </div>

        {/* Recent Activity */}
        <Card className="bg-white shadow-sm">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-slate-800">
              <Clock className="h-5 w-5 text-slate-600" />
              Recent Activity
            </CardTitle>
            <CardDescription className="text-slate-600">Latest updates across all modules</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg border border-blue-200">
                <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-slate-800">New review plan created</p>
                  <p className="text-xs text-slate-600">Q4 Compliance Review - 2 hours ago</p>
                </div>
              </div>
              <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg border border-green-200">
                <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-slate-800">Task completed</p>
                  <p className="text-xs text-slate-600">Risk Assessment Documentation - 4 hours ago</p>
                </div>
              </div>
              <div className="flex items-center gap-3 p-3 bg-orange-50 rounded-lg border border-orange-200">
                <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-slate-800">Review plan validated</p>
                  <p className="text-xs text-slate-600">Regulatory Compliance Check - 6 hours ago</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Navigation Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
          <Link href="/reviews">
            <Card className="hover:shadow-md transition-shadow cursor-pointer bg-white border-2 hover:border-blue-200">
              <CardHeader className="text-center">
                <FileText className="h-12 w-12 mx-auto text-blue-500 mb-2" />
                <CardTitle className="text-slate-800">Reviews</CardTitle>
                <CardDescription className="text-slate-600">Manage individual review items</CardDescription>
              </CardHeader>
            </Card>
          </Link>

          <Link href="/plans">
            <Card className="hover:shadow-md transition-shadow cursor-pointer bg-white border-2 hover:border-green-200">
              <CardHeader className="text-center">
                <Users className="h-12 w-12 mx-auto text-green-500 mb-2" />
                <CardTitle className="text-slate-800">Review Plans</CardTitle>
                <CardDescription className="text-slate-600">Create plans and manage associated tasks</CardDescription>
              </CardHeader>
            </Card>
          </Link>
        </div>
      </div>
    </div>
  )
}
