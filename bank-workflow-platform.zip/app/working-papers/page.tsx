"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Plus, Search, Edit, Trash2, FileText, Download, Upload } from "lucide-react"

interface WorkingPaper {
  id: string
  name: string
  description: string
  file_name: string
  file_size: string
  uploaded_by: string
  uploaded_at: string
  task_id?: string
  plan_id?: string
}

const mockWorkingPapers: WorkingPaper[] = [
  {
    id: "WP-001",
    name: "Risk Assessment Template",
    description: "Standard template for conducting risk assessments",
    file_name: "risk_assessment_template.xlsx",
    file_size: "2.3 MB",
    uploaded_by: "John Smith",
    uploaded_at: "2024-01-15T10:30:00Z",
    task_id: "TSK-001",
    plan_id: "PLN-001",
  },
  {
    id: "WP-002",
    name: "Compliance Checklist",
    description: "Comprehensive checklist for regulatory compliance review",
    file_name: "compliance_checklist.pdf",
    file_size: "1.8 MB",
    uploaded_by: "Sarah Johnson",
    uploaded_at: "2024-01-16T14:20:00Z",
    task_id: "TSK-004",
    plan_id: "PLN-001",
  },
  {
    id: "WP-003",
    name: "Data Privacy Guidelines",
    description: "Internal guidelines for data privacy compliance",
    file_name: "data_privacy_guidelines.docx",
    file_size: "956 KB",
    uploaded_by: "Emily Davis",
    uploaded_at: "2024-01-17T09:15:00Z",
    task_id: "TSK-006",
    plan_id: "PLN-002",
  },
]

export default function WorkingPapersPage() {
  const [papers, setPapers] = useState<WorkingPaper[]>(mockWorkingPapers)
  const [searchTerm, setSearchTerm] = useState("")
  const [isCreateOpen, setIsCreateOpen] = useState(false)
  const [editingPaper, setEditingPaper] = useState<WorkingPaper | null>(null)
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    file_name: "",
  })

  const filteredPapers = papers.filter(
    (paper) =>
      paper.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      paper.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      paper.file_name.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const handleCreate = () => {
    const newPaper: WorkingPaper = {
      id: `WP-${String(papers.length + 1).padStart(3, "0")}`,
      name: formData.name,
      description: formData.description,
      file_name: formData.file_name,
      file_size: "1.2 MB", // Mock file size
      uploaded_by: "Current User",
      uploaded_at: new Date().toISOString(),
    }
    setPapers([...papers, newPaper])
    resetForm()
    setIsCreateOpen(false)
  }

  const handleEdit = (paper: WorkingPaper) => {
    setEditingPaper(paper)
    setFormData({
      name: paper.name,
      description: paper.description,
      file_name: paper.file_name,
    })
  }

  const handleUpdate = () => {
    if (!editingPaper) return
    setPapers(
      papers.map((p) =>
        p.id === editingPaper.id
          ? {
              ...p,
              name: formData.name,
              description: formData.description,
              file_name: formData.file_name,
            }
          : p,
      ),
    )
    setEditingPaper(null)
    resetForm()
  }

  const handleDelete = (id: string) => {
    setPapers(papers.filter((p) => p.id !== id))
  }

  const resetForm = () => {
    setFormData({
      name: "",
      description: "",
      file_name: "",
    })
  }

  const getFileIcon = (fileName: string) => {
    const extension = fileName.split(".").pop()?.toLowerCase()
    return <FileText className="h-5 w-5 text-blue-500" />
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="container mx-auto p-6">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-slate-800 mb-2">Working Papers</h1>
            <p className="text-slate-600">Manage documents and files attached to tasks and plans</p>
          </div>
          <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
            <DialogTrigger asChild>
              <Button className="flex items-center gap-2 bg-purple-600 hover:bg-purple-700 text-white">
                <Plus className="h-4 w-4" />
                Upload Paper
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-white">
              <DialogHeader>
                <DialogTitle className="text-slate-800">Upload Working Paper</DialogTitle>
                <DialogDescription className="text-slate-600">Add a new working paper to the system</DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="name" className="text-slate-700">
                    Paper Name
                  </Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Enter paper name"
                    className="border-slate-300 focus:border-purple-500"
                  />
                </div>
                <div>
                  <Label htmlFor="description" className="text-slate-700">
                    Description
                  </Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Enter paper description"
                    className="border-slate-300 focus:border-purple-500"
                  />
                </div>
                <div>
                  <Label htmlFor="file" className="text-slate-700">
                    File
                  </Label>
                  <div className="flex items-center gap-2">
                    <Input
                      id="file"
                      type="file"
                      onChange={(e) => {
                        const file = e.target.files?.[0]
                        if (file) {
                          setFormData({ ...formData, file_name: file.name })
                        }
                      }}
                      className="border-slate-300 focus:border-purple-500"
                    />
                    <Upload className="h-4 w-4 text-slate-500" />
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button
                  variant="outline"
                  onClick={() => setIsCreateOpen(false)}
                  className="border-slate-300 text-slate-700 hover:bg-slate-50"
                >
                  Cancel
                </Button>
                <Button onClick={handleCreate} className="bg-purple-600 hover:bg-purple-700 text-white">
                  Upload Paper
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        {/* Search and Stats */}
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 h-4 w-4" />
            <Input
              placeholder="Search working papers by name, ID, or filename..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 border-slate-300 focus:border-purple-500"
            />
          </div>
          <div className="flex items-center gap-4">
            <Badge variant="secondary" className="text-sm bg-slate-100 text-slate-700 border-slate-200">
              {filteredPapers.length} of {papers.length} papers
            </Badge>
          </div>
        </div>

        {/* Papers Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredPapers.map((paper) => (
            <Card key={paper.id} className="hover:shadow-md transition-shadow bg-white border-slate-200">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="flex items-center gap-2 text-lg text-slate-800">
                      {getFileIcon(paper.file_name)}
                      {paper.id}
                    </CardTitle>
                    <CardDescription className="mt-1 text-slate-600">{paper.name}</CardDescription>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleEdit(paper)}
                      className="text-blue-600 hover:bg-blue-50"
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDelete(paper.id)}
                      className="text-red-600 hover:bg-red-50"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-slate-600">{paper.description}</p>

                <div className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-500">File:</span>
                    <span className="font-medium text-slate-700">{paper.file_name}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-500">Size:</span>
                    <span className="text-slate-700">{paper.file_size}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-500">Uploaded by:</span>
                    <span className="text-slate-700">{paper.uploaded_by}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-500">Date:</span>
                    <span className="text-slate-700">{new Date(paper.uploaded_at).toLocaleDateString()}</span>
                  </div>
                </div>

                <Button size="sm" className="w-full bg-purple-600 hover:bg-purple-700 text-white">
                  <Download className="h-4 w-4 mr-2" />
                  Download
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Edit Dialog */}
        <Dialog open={!!editingPaper} onOpenChange={() => setEditingPaper(null)}>
          <DialogContent className="bg-white">
            <DialogHeader>
              <DialogTitle className="text-slate-800">Edit Working Paper</DialogTitle>
              <DialogDescription className="text-slate-600">Update the working paper details</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <Label htmlFor="edit-name" className="text-slate-700">
                  Paper Name
                </Label>
                <Input
                  id="edit-name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Enter paper name"
                  className="border-slate-300 focus:border-purple-500"
                />
              </div>
              <div>
                <Label htmlFor="edit-description" className="text-slate-700">
                  Description
                </Label>
                <Textarea
                  id="edit-description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Enter paper description"
                  className="border-slate-300 focus:border-purple-500"
                />
              </div>
              <div>
                <Label htmlFor="edit-file" className="text-slate-700">
                  Current File
                </Label>
                <Input
                  id="edit-file"
                  value={formData.file_name}
                  onChange={(e) => setFormData({ ...formData, file_name: e.target.value })}
                  placeholder="File name"
                  disabled
                  className="border-slate-300 bg-slate-50"
                />
              </div>
            </div>
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setEditingPaper(null)}
                className="border-slate-300 text-slate-700 hover:bg-slate-50"
              >
                Cancel
              </Button>
              <Button onClick={handleUpdate} className="bg-purple-600 hover:bg-purple-700 text-white">
                Update Paper
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {filteredPapers.length === 0 && (
          <Card className="text-center py-12 bg-white border-slate-200">
            <CardContent>
              <FileText className="h-12 w-12 mx-auto text-slate-400 mb-4" />
              <h3 className="text-lg font-medium text-slate-800 mb-2">No working papers found</h3>
              <p className="text-slate-600 mb-4">
                {searchTerm ? "Try adjusting your search terms" : "Get started by uploading your first working paper"}
              </p>
              {!searchTerm && (
                <Button onClick={() => setIsCreateOpen(true)} className="bg-purple-600 hover:bg-purple-700 text-white">
                  <Plus className="h-4 w-4 mr-2" />
                  Upload Paper
                </Button>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
