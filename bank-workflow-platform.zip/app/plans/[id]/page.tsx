"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeft, FileText, Users, CheckSquare, User, CheckCircle, Play, AlertTriangle, X } from "lucide-react"
import { mockPlans, mockReviews } from "@/lib/mock-data"
import type { ReviewPlan } from "@/lib/types"
import { TaskManagementPanel } from "@/components/task-management-panel"

export default function PlanDetailPage() {
  const params = useParams()
  const router = useRouter()
  const planId = params.id as string

  const [plan, setPlan] = useState<ReviewPlan | null>(null)

  useEffect(() => {
    const foundPlan = mockPlans.find((p) => p.id === planId)
    if (foundPlan) {
      setPlan(foundPlan)
    }
  }, [planId])

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "Validated":
        return <CheckCircle className="h-4 w-4" />
      case "Started":
        return <Play className="h-4 w-4" />
      case "In Construction":
        return <AlertTriangle className="h-4 w-4" />
      case "Terminated":
        return <X className="h-4 w-4" />
      default:
        return <AlertTriangle className="h-4 w-4" />
    }
  }

  const getStatusVariant = (status: string) => {
    switch (status) {
      case "Validated":
        return "bg-green-100 text-green-700 border-green-200"
      case "Started":
        return "bg-blue-100 text-blue-700 border-blue-200"
      case "In Construction":
        return "bg-amber-100 text-amber-700 border-amber-200"
      case "Terminated":
        return "bg-red-100 text-red-700 border-red-200"
      default:
        return "bg-slate-100 text-slate-700 border-slate-200"
    }
  }

  if (!plan) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <Card className="bg-white border-slate-200">
          <CardContent className="p-6">
            <p className="text-slate-700">Plan not found</p>
            <Button onClick={() => router.push("/plans")} className="mt-4 bg-blue-600 hover:bg-blue-700 text-white">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Plans
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  // Count only leaf tasks (executable tasks, not folders)
  const leafTasks = plan.tasks.filter((task) => {
    const hasChildren = plan.tasks.some((t) => t.parent_id === task.id)
    return !task.is_folder && !hasChildren
  })

  const completedTasks = leafTasks.filter((t) => t.completed).length
  const totalTasks = leafTasks.length

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="container mx-auto p-6">
        {/* Header */}
        <div className="flex items-center gap-4 mb-6">
          <Button
            variant="ghost"
            onClick={() => router.push("/plans")}
            className="text-slate-600 hover:text-slate-900 hover:bg-slate-100"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Plans
          </Button>
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-2">
              <Users className="h-6 w-6 text-green-500" />
              <h1 className="text-3xl font-bold text-slate-800">{plan.name}</h1>
              <Badge className={getStatusVariant(plan.validation_status)}>
                {getStatusIcon(plan.validation_status)}
                {plan.validation_status}
              </Badge>
            </div>
            <p className="text-slate-600">{plan.description}</p>
          </div>
        </div>

        {/* Plan Overview - Only Leaf Tasks */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          <Card className="bg-white border-slate-200">
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <CheckSquare className="h-4 w-4 text-orange-500" />
                <span className="text-sm font-medium text-slate-700">Total Tasks</span>
              </div>
              <p className="text-2xl font-bold mt-1 text-slate-900">{totalTasks}</p>
              <p className="text-xs text-slate-500">Executable tasks only</p>
            </CardContent>
          </Card>
          <Card className="bg-white border-slate-200">
            <CardContent className="p-4">
              <div className="flex items-center gap-2">
                <CheckSquare className="h-4 w-4 text-purple-500" />
                <span className="text-sm font-medium text-slate-700">Completed Tasks</span>
              </div>
              <p className="text-2xl font-bold mt-1 text-slate-900">{completedTasks}</p>
              <p className="text-xs text-slate-500">
                {totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0}% completion rate
              </p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="tasks" className="w-full">
          <TabsList className="bg-white border border-slate-200">
            <TabsTrigger value="tasks" className="data-[state=active]:bg-slate-100">
              Tasks
            </TabsTrigger>
            <TabsTrigger value="details" className="data-[state=active]:bg-slate-100">
              Plan Details
            </TabsTrigger>
          </TabsList>

          <TabsContent value="tasks" className="mt-6">
            <TaskManagementPanel initialPlan={plan} onPlanUpdate={(updatedPlan) => setPlan(updatedPlan)} />
          </TabsContent>

          <TabsContent value="details" className="mt-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-white border-slate-200">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-slate-800">
                    <FileText className="h-5 w-5" />
                    Attached Reviews ({plan.attached_reviews.length})
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {plan.attached_reviews.length > 0 ? (
                      plan.attached_reviews.map((reviewId) => {
                        const review = mockReviews.find((r) => r.id === reviewId)
                        return (
                          <div
                            key={reviewId}
                            className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-200"
                          >
                            <div className="flex-1">
                              <Badge variant="outline" className="mb-1 bg-white text-slate-700 border-slate-300">
                                {reviewId}
                              </Badge>
                              {review && <p className="text-sm text-slate-600">{review.name}</p>}
                            </div>
                          </div>
                        )
                      })
                    ) : (
                      <p className="text-sm text-slate-500">No reviews attached</p>
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-white border-slate-200">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-slate-800">
                    <Users className="h-5 w-5" />
                    Team Members ({plan.persons_concerned.length})
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {plan.persons_concerned.length > 0 ? (
                      plan.persons_concerned.map((person) => (
                        <div
                          key={person}
                          className="flex items-center gap-2 p-2 bg-slate-50 rounded border border-slate-200"
                        >
                          <User className="h-4 w-4 text-slate-500" />
                          <span className="text-sm text-slate-700">{person}</span>
                        </div>
                      ))
                    ) : (
                      <p className="text-sm text-slate-500">No team members assigned</p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
