"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Plus, Search, Edit, Trash2, Users, CheckCircle, Clock, CheckSquare, Play, Construction } from "lucide-react"
import { mockPlans, mockReviews } from "@/lib/mock-data"
import type { ReviewPlan } from "@/lib/types"
import Link from "next/link"

export default function PlansPage() {
  const [plans, setPlans] = useState<ReviewPlan[]>(mockPlans)
  const [searchTerm, setSearchTerm] = useState("")
  const [isCreateOpen, setIsCreateOpen] = useState(false)
  const [editingPlan, setEditingPlan] = useState<ReviewPlan | null>(null)
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    attached_reviews: [] as string[],
    persons_concerned: [] as string[],
  })

  const filteredPlans = plans.filter(
    (plan) =>
      plan.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      plan.id.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "Validated":
        return <CheckCircle className="h-3 w-3 mr-1" />
      case "Started":
        return <Play className="h-3 w-3 mr-1" />
      case "In Construction":
        return <Construction className="h-3 w-3 mr-1" />
      case "Finished":
        return <CheckSquare className="h-3 w-3 mr-1" />
      default:
        return <Clock className="h-3 w-3 mr-1" />
    }
  }

  const getStatusVariant = (status: string) => {
    switch (status) {
      case "Validated":
        return "bg-green-100 text-green-700 border-green-200"
      case "Started":
        return "bg-blue-100 text-blue-700 border-blue-200"
      case "In Construction":
        return "bg-amber-100 text-amber-700 border-amber-200"
      case "Finished":
        return "bg-slate-100 text-slate-700 border-slate-200"
      default:
        return "bg-slate-100 text-slate-700 border-slate-200"
    }
  }

  // Calculate leaf task counts for each plan
  const getLeafTaskCounts = (plan: ReviewPlan) => {
    const leafTasks = plan.tasks.filter((task) => !plan.tasks.some((t) => t.parent_id === task.id))
    const completedLeafTasks = leafTasks.filter((task) => task.completed)
    return { total: leafTasks.length, completed: completedLeafTasks.length }
  }

  const handleCreate = () => {
    const newPlan: ReviewPlan = {
      id: `PLN-${String(plans.length + 1).padStart(3, "0")}`,
      name: formData.name,
      description: formData.description,
      attached_reviews: formData.attached_reviews,
      persons_concerned: formData.persons_concerned,
      validation_status: "In Construction",
      tasks: [],
    }
    setPlans([...plans, newPlan])
    resetForm()
    setIsCreateOpen(false)
  }

  const handleEdit = (plan: ReviewPlan) => {
    setEditingPlan(plan)
    setFormData({
      name: plan.name,
      description: plan.description,
      attached_reviews: plan.attached_reviews,
      persons_concerned: plan.persons_concerned,
    })
  }

  const handleUpdate = () => {
    if (!editingPlan) return
    setPlans(plans.map((p) => (p.id === editingPlan.id ? { ...p, ...formData } : p)))
    setEditingPlan(null)
    resetForm()
  }

  const handleDelete = (id: string) => {
    setPlans(plans.filter((p) => p.id !== id))
  }

  const handleStatusChange = (id: string, newStatus: "In Construction" | "Validated" | "Started" | "Finished") => {
    setPlans(plans.map((p) => (p.id === id ? { ...p, validation_status: newStatus } : p)))
  }

  const resetForm = () => {
    setFormData({
      name: "",
      description: "",
      attached_reviews: [],
      persons_concerned: [],
    })
  }

  const handleReviewToggle = (reviewId: string, checked: boolean) => {
    if (checked) {
      setFormData({
        ...formData,
        attached_reviews: [...formData.attached_reviews, reviewId],
      })
    } else {
      setFormData({
        ...formData,
        attached_reviews: formData.attached_reviews.filter((id) => id !== reviewId),
      })
    }
  }

  const addPerson = (person: string) => {
    if (person && !formData.persons_concerned.includes(person)) {
      setFormData({
        ...formData,
        persons_concerned: [...formData.persons_concerned, person],
      })
    }
  }

  const removePerson = (person: string) => {
    setFormData({
      ...formData,
      persons_concerned: formData.persons_concerned.filter((p) => p !== person),
    })
  }

  const validatedPlans = plans.filter((p) => p.validation_status === "Validated").length
  const startedPlans = plans.filter((p) => p.validation_status === "Started").length
  const inConstructionPlans = plans.filter((p) => p.validation_status === "In Construction").length
  const finishedPlans = plans.filter((p) => p.validation_status === "Finished").length

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="container mx-auto p-6">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-slate-800 mb-2">Review Plans</h1>
            <p className="text-slate-600">Create and manage scoped review plans with linked reviews</p>
          </div>
          <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
            <DialogTrigger asChild>
              <Button className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white">
                <Plus className="h-4 w-4" />
                Create Plan
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto bg-white">
              <DialogHeader>
                <DialogTitle className="text-slate-800">Create New Review Plan</DialogTitle>
                <DialogDescription className="text-slate-600">
                  Create a new review plan and link relevant reviews
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-6">
                <div>
                  <Label htmlFor="name" className="text-slate-700">
                    Plan Name
                  </Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="Enter plan name"
                    className="border-slate-300 focus:border-green-500"
                  />
                </div>
                <div>
                  <Label htmlFor="description" className="text-slate-700">
                    Description
                  </Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder="Enter plan description"
                    className="border-slate-300 focus:border-green-500"
                  />
                </div>

                {/* Attached Reviews */}
                <div>
                  <Label className="text-slate-700">Attached Reviews</Label>
                  <div className="mt-2 space-y-2 max-h-40 overflow-y-auto border rounded-md p-3 bg-slate-50">
                    {mockReviews.map((review) => (
                      <div key={review.id} className="flex items-center space-x-2">
                        <Checkbox
                          id={review.id}
                          checked={formData.attached_reviews.includes(review.id)}
                          onCheckedChange={(checked) => handleReviewToggle(review.id, checked as boolean)}
                        />
                        <Label htmlFor={review.id} className="text-sm text-slate-700">
                          {review.id} - {review.name}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Persons Concerned */}
                <div>
                  <Label className="text-slate-700">Persons Concerned</Label>
                  <div className="flex gap-2 mt-2">
                    <Select onValueChange={addPerson}>
                      <SelectTrigger className="border-slate-300">
                        <SelectValue placeholder="Add person" />
                      </SelectTrigger>
                      <SelectContent className="bg-white">
                        <SelectItem value="John Smith">John Smith</SelectItem>
                        <SelectItem value="Sarah Johnson">Sarah Johnson</SelectItem>
                        <SelectItem value="Michael Brown">Michael Brown</SelectItem>
                        <SelectItem value="Emily Davis">Emily Davis</SelectItem>
                        <SelectItem value="David Wilson">David Wilson</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {formData.persons_concerned.map((person) => (
                      <Badge
                        key={person}
                        variant="secondary"
                        className="flex items-center gap-1 bg-slate-100 text-slate-700"
                      >
                        {person}
                        <button onClick={() => removePerson(person)} className="ml-1 text-xs hover:text-red-500">
                          ×
                        </button>
                      </Badge>
                    ))}
                  </div>
                </div>

                <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                  <p className="text-sm text-blue-700">
                    <Construction className="h-4 w-4 inline mr-1" />
                    New plans start in "In Construction" status and must be explicitly validated before they can be
                    started.
                  </p>
                </div>
              </div>
              <DialogFooter>
                <Button
                  variant="outline"
                  onClick={() => {
                    setIsCreateOpen(false)
                    resetForm()
                  }}
                  className="border-slate-300 text-slate-700 hover:bg-slate-50"
                >
                  Cancel
                </Button>
                <Button onClick={handleCreate} className="bg-green-600 hover:bg-green-700 text-white">
                  Create Plan
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        {/* Search and Stats */}
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 h-4 w-4" />
            <Input
              placeholder="Search plans by ID or name..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 border-slate-300 focus:border-green-500"
            />
          </div>
          <div className="flex items-center gap-4">
            <Badge variant="secondary" className="text-sm bg-slate-100 text-slate-700">
              {filteredPlans.length} of {plans.length} plans
            </Badge>
            <Badge variant="outline" className="text-sm bg-amber-50 text-amber-700 border-amber-200">
              {inConstructionPlans} in construction
            </Badge>
            <Badge variant="secondary" className="text-sm bg-green-50 text-green-700 border-green-200">
              {validatedPlans} validated
            </Badge>
            <Badge variant="default" className="text-sm bg-blue-50 text-blue-700 border-blue-200">
              {startedPlans} started
            </Badge>
            {finishedPlans > 0 && (
              <Badge variant="default" className="text-sm bg-slate-100 text-slate-700 border-slate-200">
                {finishedPlans} finished
              </Badge>
            )}
          </div>
        </div>

        {/* Plans Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {filteredPlans.map((plan) => {
            const leafTaskCounts = getLeafTaskCounts(plan)
            const progressPercentage =
              leafTaskCounts.total > 0 ? Math.round((leafTaskCounts.completed / leafTaskCounts.total) * 100) : 0

            return (
              <Card key={plan.id} className="hover:shadow-md transition-shadow bg-white border-slate-200">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <CardTitle className="flex items-center gap-2 text-lg text-slate-800">
                        <Users className="h-5 w-5 text-green-500" />
                        {plan.id}
                      </CardTitle>
                      <CardDescription className="mt-1 text-slate-600">{plan.name}</CardDescription>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className={getStatusVariant(plan.validation_status)}>
                        {getStatusIcon(plan.validation_status)}
                        {plan.validation_status}
                      </Badge>
                      <div className="flex gap-1">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleEdit(plan)}
                          className="text-blue-600 hover:bg-blue-50"
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDelete(plan.id)}
                          className="text-red-600 hover:bg-red-50"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-slate-600">{plan.description}</p>

                  {/* Consolidated Task Progress */}
                  {leafTaskCounts.total > 0 && (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-slate-600">Leaf Task Progress</span>
                        <span className="font-medium text-slate-800">
                          {leafTaskCounts.completed}/{leafTaskCounts.total} ({progressPercentage}%)
                        </span>
                      </div>
                      <Progress value={progressPercentage} className="h-2" />
                    </div>
                  )}

                  <div className="flex gap-2 pt-2">
                    <Link href={`/plans/${plan.id}`} className="flex-1">
                      <Button size="sm" className="w-full bg-blue-600 hover:bg-blue-700 text-white">
                        <CheckSquare className="h-4 w-4 mr-2" />
                        Manage Tasks
                      </Button>
                    </Link>
                    {plan.validation_status === "In Construction" && (
                      <Button
                        size="sm"
                        onClick={() => handleStatusChange(plan.id, "Validated")}
                        variant="outline"
                        className="border-green-300 text-green-700 hover:bg-green-50"
                      >
                        <CheckCircle className="h-4 w-4 mr-2" />
                        Validate
                      </Button>
                    )}
                    {plan.validation_status === "Validated" && (
                      <Button
                        size="sm"
                        onClick={() => handleStatusChange(plan.id, "Started")}
                        variant="outline"
                        className="border-blue-300 text-blue-700 hover:bg-blue-50"
                      >
                        <Play className="h-4 w-4 mr-2" />
                        Start
                      </Button>
                    )}
                    {plan.validation_status === "Started" && (
                      <Button
                        size="sm"
                        onClick={() => handleStatusChange(plan.id, "Finished")}
                        variant="outline"
                        className="border-slate-300 text-slate-700 hover:bg-slate-50"
                      >
                        <CheckSquare className="h-4 w-4 mr-2" />
                        Finish
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            )
          })}
        </div>

        {/* Edit Dialog */}
        <Dialog open={!!editingPlan} onOpenChange={() => setEditingPlan(null)}>
          <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto bg-white">
            <DialogHeader>
              <DialogTitle className="text-slate-800">Edit Review Plan</DialogTitle>
              <DialogDescription className="text-slate-600">Update the review plan details</DialogDescription>
            </DialogHeader>
            <div className="space-y-6">
              <div>
                <Label htmlFor="edit-name" className="text-slate-700">
                  Plan Name
                </Label>
                <Input
                  id="edit-name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder="Enter plan name"
                  className="border-slate-300 focus:border-green-500"
                />
              </div>
              <div>
                <Label htmlFor="edit-description" className="text-slate-700">
                  Description
                </Label>
                <Textarea
                  id="edit-description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Enter plan description"
                  className="border-slate-300 focus:border-green-500"
                />
              </div>

              {/* Attached Reviews */}
              <div>
                <Label className="text-slate-700">Attached Reviews</Label>
                <div className="mt-2 space-y-2 max-h-40 overflow-y-auto border rounded-md p-3 bg-slate-50">
                  {mockReviews.map((review) => (
                    <div key={review.id} className="flex items-center space-x-2">
                      <Checkbox
                        id={`edit-${review.id}`}
                        checked={formData.attached_reviews.includes(review.id)}
                        onCheckedChange={(checked) => handleReviewToggle(review.id, checked as boolean)}
                      />
                      <Label htmlFor={`edit-${review.id}`} className="text-sm text-slate-700">
                        {review.id} - {review.name}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>

              {/* Persons Concerned */}
              <div>
                <Label className="text-slate-700">Persons Concerned</Label>
                <div className="flex gap-2 mt-2">
                  <Select onValueChange={addPerson}>
                    <SelectTrigger className="border-slate-300">
                      <SelectValue placeholder="Add person" />
                    </SelectTrigger>
                    <SelectContent className="bg-white">
                      <SelectItem value="John Smith">John Smith</SelectItem>
                      <SelectItem value="Sarah Johnson">Sarah Johnson</SelectItem>
                      <SelectItem value="Michael Brown">Michael Brown</SelectItem>
                      <SelectItem value="Emily Davis">Emily Davis</SelectItem>
                      <SelectItem value="David Wilson">David Wilson</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex flex-wrap gap-2 mt-2">
                  {formData.persons_concerned.map((person) => (
                    <Badge
                      key={person}
                      variant="secondary"
                      className="flex items-center gap-1 bg-slate-100 text-slate-700"
                    >
                      {person}
                      <button onClick={() => removePerson(person)} className="ml-1 text-xs hover:text-red-500">
                        ×
                      </button>
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => setEditingPlan(null)}
                className="border-slate-300 text-slate-700 hover:bg-slate-50"
              >
                Cancel
              </Button>
              <Button onClick={handleUpdate} className="bg-green-600 hover:bg-green-700 text-white">
                Update Plan
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {filteredPlans.length === 0 && (
          <Card className="text-center py-12 bg-white border-slate-200">
            <CardContent>
              <Users className="h-12 w-12 mx-auto text-slate-400 mb-4" />
              <h3 className="text-lg font-medium text-slate-800 mb-2">No plans found</h3>
              <p className="text-slate-600 mb-4">
                {searchTerm ? "Try adjusting your search terms" : "Get started by creating your first review plan"}
              </p>
              {!searchTerm && (
                <Button onClick={() => setIsCreateOpen(true)} className="bg-green-600 hover:bg-green-700 text-white">
                  <Plus className="h-4 w-4 mr-2" />
                  Create Plan
                </Button>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
