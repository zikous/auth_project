"use client"

import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Bot, Settings, RefreshCw, Sparkles, Copy } from "lucide-react"
import type { Task, ReviewPlan } from "@/lib/types"
import { useAIReport } from "@/hooks/use-ai-report"
import { useState } from "react"

interface AIReportGeneratorProps {
  task: Task | null
  plan: ReviewPlan | null
}

export function AIReportGenerator({ task, plan }: AIReportGeneratorProps) {
  const [showPrompt, setShowPrompt] = useState(false)

  const {
    currentPrompt,
    customPrompt,
    setCustomPrompt,
    isEditingPrompt,
    isGenerating,
    generateReport,
    handleGenerateReport,
    handleEditPrompt,
    handleSavePrompt,
    handleCancelPrompt,
  } = useAIReport(task, plan)

  if (!task) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-8">
          <div className="text-center space-y-2">
            <Bot className="h-8 w-8 text-muted-foreground mx-auto" />
            <p className="text-sm text-muted-foreground">Select a task to generate an AI report</p>
          </div>
        </CardContent>
      </Card>
    )
  }

  const report = generateReport()

  const handleCopyReport = async () => {
    try {
      await navigator.clipboard.writeText(report)
    } catch (error) {
      console.error("Failed to copy report:", error)
    }
  }

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Bot className="h-5 w-5 text-purple-500" />
          <h4 className="text-sm font-medium">AI-Generated Report</h4>
        </div>
        <Button variant="ghost" size="sm" onClick={handleGenerateReport} disabled={isGenerating}>
          {isGenerating ? <RefreshCw className="h-3 w-3 mr-1 animate-spin" /> : <Sparkles className="h-3 w-3 mr-1" />}
          {isGenerating ? "Generating..." : "Generate Report"}
        </Button>
      </div>

      {/* Task Info */}
      <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
        <div className="flex items-center gap-2 mb-1">
          <span className="text-sm font-medium text-blue-800">Task:</span>
          <span className="text-sm text-blue-700 font-mono">{task.id}</span>
        </div>
        <p className="text-sm text-blue-700">{task.name}</p>
      </div>

      {/* Prompt Settings */}
      <div className="space-y-2">
        <Button
          variant="outline"
          size="sm"
          className="w-full justify-between bg-transparent"
          onClick={() => setShowPrompt(!showPrompt)}
        >
          <div className="flex items-center gap-2">
            <Settings className="h-3 w-3" />
            AI Prompt Configuration
          </div>
        </Button>

        {showPrompt && (
          <Card className="border-orange-200 bg-orange-50/50">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm">Prompt Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {isEditingPrompt ? (
                <div className="space-y-3">
                  <Textarea
                    value={customPrompt}
                    onChange={(e) => setCustomPrompt(e.target.value)}
                    rows={6}
                    className="text-xs font-mono"
                    placeholder="Enter your custom prompt..."
                  />
                  <div className="flex justify-end gap-2">
                    <Button variant="outline" size="sm" onClick={handleCancelPrompt}>
                      Cancel
                    </Button>
                    <Button size="sm" onClick={handleSavePrompt}>
                      Apply
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="space-y-2">
                  <ScrollArea className="h-24 w-full rounded border bg-muted/50 p-2">
                    <pre className="text-xs text-muted-foreground whitespace-pre-wrap font-mono">{currentPrompt}</pre>
                  </ScrollArea>
                  <Button variant="ghost" size="sm" onClick={() => handleEditPrompt(true)}>
                    Edit Prompt
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        )}
      </div>

      {/* Report */}
      <Card>
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="text-sm">Analysis Report</CardTitle>
            <Button variant="outline" size="sm" onClick={handleCopyReport}>
              <Copy className="h-3 w-3 mr-1" />
              Copy
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-96 w-full">
            {report ? (
              <pre className="whitespace-pre-wrap text-xs bg-slate-50 text-slate-800 p-4 rounded-lg border font-sans leading-relaxed">
                {report}
              </pre>
            ) : (
              <div className="text-center py-8">
                <Bot className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600 text-sm">Click "Generate Report" to create an AI analysis.</p>
              </div>
            )}
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  )
}
