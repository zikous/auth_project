"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import type { Review } from "@/lib/types"

interface ReviewFormProps {
  review?: Review | null
  onSubmit: (data: { id: string; name: string; description: string }) => void
  onCancel: () => void
  isLoading?: boolean
}

export function ReviewForm({ review, onSubmit, onCancel, isLoading }: ReviewFormProps) {
  const [id, setId] = useState("")
  const [name, setName] = useState("")
  const [description, setDescription] = useState("")

  useEffect(() => {
    if (review) {
      setId(review.id)
      setName(review.name)
      setDescription(review.description)
    } else {
      setId("")
      setName("")
      setDescription("")
    }
  }, [review])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!id.trim() || !name.trim()) return
    onSubmit({ id: id.trim(), name: name.trim(), description: description.trim() })
  }

  const isValid = id.trim() && name.trim()

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="id">Review ID *</Label>
        <Input id="id" value={id} onChange={(e) => setId(e.target.value)} placeholder="e.g., RVW-001" required />
      </div>

      <div>
        <Label htmlFor="name">Name *</Label>
        <Input id="name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Review name" required />
      </div>

      <div>
        <Label htmlFor="description">Description</Label>
        <Textarea
          id="description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Brief description"
          rows={3}
        />
      </div>

      <div className="flex justify-end gap-3 pt-4">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit" disabled={!isValid || isLoading}>
          {isLoading ? "Saving..." : review ? "Update" : "Create"}
        </Button>
      </div>
    </form>
  )
}
