"use client"

import { Button } from "@/components/ui/button"
import { Trash2 } from "lucide-react"

interface BulkActionsProps {
  selectedCount: number
  onDelete: () => void
}

export function BulkActions({ selectedCount, onDelete }: BulkActionsProps) {
  if (selectedCount === 0) return null

  return (
    <Button variant="outline" onClick={onDelete} className="text-red-600 hover:text-red-700">
      <Trash2 className="h-4 w-4 mr-2" />
      Delete ({selectedCount})
    </Button>
  )
}
