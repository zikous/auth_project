"use client"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Edit, Trash2, Users, CheckCircle, MoreHorizontal, Calendar } from "lucide-react"
import Link from "next/link"
import type { ReviewPlan } from "@/lib/types"

interface PlanTableProps {
  plans: ReviewPlan[]
  selectedItems: string[]
  onSelectAll: (checked: boolean) => void
  onSelectItem: (id: string, checked: boolean) => void
  onEdit: (plan: ReviewPlan) => void
  onDelete: (id: string) => void
  onStatusChange: (id: string, status: ReviewPlan["validation_status"]) => void
}

export function PlanTable({
  plans,
  selectedItems,
  onSelectAll,
  onSelectItem,
  onEdit,
  onDelete,
  onStatusChange,
}: PlanTableProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "Validated":
        return "bg-green-100 text-green-700"
      default:
        return "bg-orange-100 text-orange-700"
    }
  }

  const getLeafTaskCounts = (plan: ReviewPlan) => {
    const leafTasks = plan.tasks.filter((task) => !plan.tasks.some((t) => t.parent_id === task.id))
    const completedLeafTasks = leafTasks.filter((task) => task.completed)
    return { total: leafTasks.length, completed: completedLeafTasks.length }
  }

  return (
    <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
      <div className="min-w-full">
        <table className="w-full table-fixed">
          <thead className="bg-gray-50 border-b border-gray-200">
            <tr>
              <th className="w-12 px-4 py-3 text-left">
                <Checkbox
                  checked={selectedItems.length === plans.length && plans.length > 0}
                  onCheckedChange={onSelectAll}
                />
              </th>
              <th className="w-32 px-4 py-3 text-left text-sm font-medium text-gray-900">ID</th>
              <th className="w-48 px-4 py-3 text-left text-sm font-medium text-gray-900">Name</th>
              <th className="w-32 px-4 py-3 text-left text-sm font-medium text-gray-900">Status</th>
              <th className="w-32 px-4 py-3 text-left text-sm font-medium text-gray-900">Review</th>
              <th className="w-24 px-4 py-3 text-left text-sm font-medium text-gray-900">Man Days</th>
              <th className="w-32 px-4 py-3 text-center text-sm font-medium text-gray-900">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {plans.map((plan) => (
              <tr key={plan.id} className="hover:bg-gray-50 transition-colors">
                <td className="px-4 py-4">
                  <Checkbox
                    checked={selectedItems.includes(plan.id)}
                    onCheckedChange={(checked) => onSelectItem(plan.id, checked as boolean)}
                  />
                </td>
                <td className="px-4 py-4">
                  <div className="flex items-center space-x-2">
                    <div className="bg-green-100 rounded p-1">
                      <Users className="h-3 w-3 text-green-600" />
                    </div>
                    <span className="text-sm font-mono text-gray-900 truncate">{plan.id}</span>
                  </div>
                </td>
                <td className="px-4 py-4">
                  <div>
                    <span className="text-sm font-medium text-gray-900 block truncate">{plan.name}</span>
                    <p className="text-xs text-gray-500 mt-1 truncate">{plan.description}</p>
                  </div>
                </td>
                <td className="px-4 py-4">
                  <Badge className={getStatusColor(plan.validation_status)}>{plan.validation_status}</Badge>
                </td>
                <td className="px-4 py-4">
                  {plan.attached_reviews ? (
                    <div className="flex items-center space-x-2">
                      <div className="bg-blue-100 rounded p-1">
                        <Users className="h-3 w-3 text-blue-600" />
                      </div>
                      <span className="text-sm font-mono text-gray-900">{plan.attached_reviews}</span>
                    </div>
                  ) : (
                    <span className="text-xs text-gray-400">No review</span>
                  )}
                </td>
                <td className="px-4 py-4">
                  <div className="flex items-center space-x-1 text-sm text-gray-600">
                    <Calendar className="h-3 w-3 flex-shrink-0" />
                    <span className="truncate">{plan.man_days || 0}</span>
                  </div>
                </td>
                <td className="px-4 py-4">
                  <div className="flex items-center justify-center space-x-1">
                    <Link href={`/plans/${plan.id}`}>
                      <Button size="sm" variant="outline" className="text-xs px-2">
                        Tasks
                      </Button>
                    </Link>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => onEdit(plan)}>
                          <Edit className="h-4 w-4 mr-2" />
                          Edit
                        </DropdownMenuItem>
                        {plan.validation_status === "In Construction" && (
                          <DropdownMenuItem onClick={() => onStatusChange(plan.id, "Validated")}>
                            <CheckCircle className="h-4 w-4 mr-2" />
                            Validate
                          </DropdownMenuItem>
                        )}
                        <DropdownMenuItem onClick={() => onDelete(plan.id)} className="text-red-600">
                          <Trash2 className="h-4 w-4 mr-2" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
