"use client"

import { useEffect } from "react"
import { InputField, TextareaField, SelectField } from "@/components/common/form-field"
import { useFormikForm, planValidationSchema } from "@/lib/hooks/use-formik-form"
import type { ReviewPlan, Review } from "@/lib/types"

interface PlanFormProps {
  plan?: ReviewPlan | null
  reviews: Review[]
  onSubmit: (data: { name: string; description: string; attached_reviews: string; man_days: number }) => void
}

export function PlanForm({ plan, reviews, onSubmit }: PlanFormProps) {
  const formik = useFormikForm({
    initialValues: {
      name: plan?.name || "",
      description: plan?.description || "",
      attached_reviews: plan?.attached_reviews || "",
      man_days: plan?.man_days || 0,
    },
    validationSchema: planValidationSchema,
    onSubmit: (values) => onSubmit(values),
  })

  const reviewOptions = [
    { value: "none", label: "Select a review...", disabled: true },
    ...reviews.map((review) => ({
      value: review.id,
      label: `${review.id} - ${review.name}`,
    })),
  ]

  useEffect(() => {
    if (plan) {
      formik.setValues({
        name: plan.name,
        description: plan.description,
        attached_reviews: plan.attached_reviews,
        man_days: plan.man_days || 0,
      })
    } else {
      formik.resetForm()
    }
  }, [plan])

  return {
    formik,
    isValid: formik.isValid,
    form: (
      <>
        <InputField name="name" label="Plan Name" placeholder="Plan name" required formik={formik} />
        <TextareaField name="description" label="Description" placeholder="Brief description" formik={formik} />
        <InputField name="man_days" label="Man Days" type="number" placeholder="Estimated man days" formik={formik} />
        <SelectField
          name="attached_reviews"
          label="Review"
          placeholder="Select a review"
          options={reviewOptions}
          required
          formik={formik}
        />
      </>
    ),
  }
}
