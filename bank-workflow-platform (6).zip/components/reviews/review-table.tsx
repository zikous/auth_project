"use client"
import { Button } from "@/components/ui/button"
import { Checkbox } from "@/components/ui/checkbox"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Edit, Trash2, FileText, MoreHorizontal, LinkIcon } from "lucide-react"
import type { Review, ReviewPlan } from "@/lib/types"

interface ReviewTableProps {
  reviews: Review[]
  plans: ReviewPlan[]
  selectedItems: string[]
  onSelectAll: (checked: boolean) => void
  onSelectItem: (id: string, checked: boolean) => void
  onEdit: (review: Review) => void
  onDelete: (id: string) => void
  onViewLinkedPlans: (reviewId: string) => void
}

export function ReviewTable({
  reviews,
  plans,
  selectedItems,
  onSelectAll,
  onSelectItem,
  onEdit,
  onDelete,
  onViewLinkedPlans,
}: ReviewTableProps) {
  const getLinkedPlans = (reviewId: string) => {
    return plans.filter((plan) => plan.attached_reviews.includes(reviewId))
  }

  return (
    <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50 border-b border-gray-200">
            <tr>
              <th className="w-12 px-4 py-3 text-left">
                <Checkbox
                  checked={selectedItems.length === reviews.length && reviews.length > 0}
                  onCheckedChange={onSelectAll}
                />
              </th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-900">ID</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-900">Name</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-900">Description</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-900">Linked Plans</th>
              <th className="w-16 px-4 py-3 text-center text-sm font-medium text-gray-900">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {reviews.map((review) => {
              const linkedPlans = getLinkedPlans(review.id)
              return (
                <tr key={review.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-4 py-4">
                    <Checkbox
                      checked={selectedItems.includes(review.id)}
                      onCheckedChange={(checked) => onSelectItem(review.id, checked as boolean)}
                    />
                  </td>
                  <td className="px-4 py-4">
                    <div className="flex items-center space-x-2">
                      <div className="bg-blue-100 rounded p-1">
                        <FileText className="h-3 w-3 text-blue-600" />
                      </div>
                      <span className="text-sm font-mono text-gray-900">{review.id}</span>
                    </div>
                  </td>
                  <td className="px-4 py-4">
                    <span className="text-sm font-medium text-gray-900">{review.name}</span>
                  </td>
                  <td className="px-4 py-4">
                    <span className="text-sm text-gray-600 max-w-xs truncate block">{review.description}</span>
                  </td>
                  <td className="px-4 py-4">
                    {linkedPlans.length > 0 ? (
                      <div className="flex items-center space-x-2">
                        <span className="text-sm text-gray-600">{linkedPlans.length} plan(s)</span>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => onViewLinkedPlans(review.id)}
                          className="h-6 w-6 p-0"
                        >
                          <LinkIcon className="h-3 w-3" />
                        </Button>
                      </div>
                    ) : (
                      <span className="text-sm text-gray-400">No plans</span>
                    )}
                  </td>
                  <td className="px-4 py-4 text-center">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => onEdit(review)}>
                          <Edit className="h-4 w-4 mr-2" />
                          Edit
                        </DropdownMenuItem>
                        {linkedPlans.length > 0 && (
                          <DropdownMenuItem onClick={() => onViewLinkedPlans(review.id)}>
                            <LinkIcon className="h-4 w-4 mr-2" />
                            View Linked Plans ({linkedPlans.length})
                          </DropdownMenuItem>
                        )}
                        <DropdownMenuItem onClick={() => onDelete(review.id)} className="text-red-600">
                          <Trash2 className="h-4 w-4 mr-2" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
    </div>
  )
}
