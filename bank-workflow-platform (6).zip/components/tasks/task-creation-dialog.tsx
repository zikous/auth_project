"use client"

import { useState } from "react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { FileText, Folder, FolderTree, Settings, AlertCircle } from "lucide-react"
import type { ReviewPlan } from "@/lib/types"
import { useTaskHierarchy } from "@/hooks/use-task-hierarchy"

interface TaskCreationDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  plan: ReviewPlan
  onCreateTask: (taskData: any) => Promise<any>
  isLoading: boolean
}

export function TaskCreationDialog({ open, onOpenChange, plan, onCreateTask, isLoading }: TaskCreationDialogProps) {
  const [activeTab, setActiveTab] = useState<"structure" | "tasks">("structure")

  // Folder form state
  const [folderForm, setFolderForm] = useState({
    name: "",
    description: "",
    parent_id: "root" as string,
    responsible_person: "none",
    scope_definition: "",
    organizational_purpose: "",
  })

  // Task form state
  const [taskForm, setTaskForm] = useState({
    name: "",
    description: "",
    parent_id: "root" as string,
    assigned_to: "none",
    days_required: 1,
    difficulty: "Medium" as "Easy" | "Medium" | "Hard",
    objective: "",
    deliverables: "",
    acceptance_criteria: "",
    prerequisites: "",
  })

  // Only use the hook if plan and tasks exist
  const { getOrganizationalFolders, getTaskPlacementOptions } = useTaskHierarchy({
    tasks: plan?.tasks || [],
  })

  const resetForms = () => {
    setFolderForm({
      name: "",
      description: "",
      parent_id: "root",
      responsible_person: "none",
      scope_definition: "",
      organizational_purpose: "",
    })
    setTaskForm({
      name: "",
      description: "",
      parent_id: "root",
      assigned_to: "none",
      days_required: 1,
      difficulty: "Medium",
      objective: "",
      deliverables: "",
      acceptance_criteria: "",
      prerequisites: "",
    })
  }

  const handleCreateFolder = async () => {
    if (!folderForm.name.trim() || !folderForm.organizational_purpose.trim()) {
      return
    }

    const folderData = {
      name: folderForm.name,
      description:
        `${folderForm.description}\n\nOrganizational Purpose: ${folderForm.organizational_purpose}\n\nScope Definition: ${folderForm.scope_definition}`.trim(),
      parent_id: folderForm.parent_id === "root" ? null : folderForm.parent_id,
      assigned_to: "",
      responsible_person: folderForm.responsible_person === "none" ? "" : folderForm.responsible_person,
      days_required: 0,
      difficulty: "Medium" as const,
      is_folder: true,
    }

    const result = await onCreateTask(folderData)
    if (result) {
      resetForms()
      onOpenChange(false)
    }
  }

  const handleCreateTask = async () => {
    if (!taskForm.name.trim() || !taskForm.objective.trim()) {
      return
    }

    const taskData = {
      name: taskForm.name,
      description:
        `${taskForm.description}\n\nObjective: ${taskForm.objective}\n\nDeliverables:\n${taskForm.deliverables}\n\nAcceptance Criteria:\n${taskForm.acceptance_criteria}${taskForm.prerequisites ? `\n\nPrerequisites:\n${taskForm.prerequisites}` : ""}`.trim(),
      parent_id: taskForm.parent_id === "root" ? null : taskForm.parent_id,
      assigned_to: taskForm.assigned_to === "none" ? "" : taskForm.assigned_to,
      days_required: taskForm.days_required,
      difficulty: taskForm.difficulty,
      is_folder: false,
    }

    const result = await onCreateTask(taskData)
    if (result) {
      resetForms()
      onOpenChange(false)
    }
  }

  // Don't render if plan is not available
  if (!plan) {
    return null
  }

  const assigneeOptions = [
    { value: "none", label: "No specific owner" },
    ...(plan.persons_concerned?.map((person) => ({ value: person, label: person })) || []),
  ]

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-6xl max-h-[95vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            Project Structure & Task Management
          </DialogTitle>
          <DialogDescription>
            First define organizational structure with folders, then create tasks within that structure
          </DialogDescription>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as "structure" | "tasks")}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="structure" className="flex items-center gap-2">
              <Folder className="h-4 w-4" />
              Define Structure
            </TabsTrigger>
            <TabsTrigger value="tasks" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              Create Tasks
            </TabsTrigger>
          </TabsList>

          {/* STRUCTURE DEFINITION TAB */}
          <TabsContent value="structure" className="space-y-6 mt-6">
            <div className="bg-blue-50 dark:bg-blue-950/20 p-6 rounded-lg border border-blue-200 dark:border-blue-800">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded-lg">
                  <Folder className="h-6 w-6 text-blue-600" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-blue-900 dark:text-blue-300">
                    Organizational Structure Definition
                  </h3>
                  <p className="text-sm text-blue-700 dark:text-blue-400">
                    Create folders to establish the organizational hierarchy for your project
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Left: Folder Identity */}
                <div className="space-y-4">
                  <div className="bg-white dark:bg-slate-800 p-4 rounded-lg border">
                    <h4 className="font-medium mb-3 text-blue-800 dark:text-blue-200">Folder Identity</h4>
                    <div className="space-y-3">
                      <div>
                        <Label htmlFor="folder-name">Folder Name *</Label>
                        <Input
                          id="folder-name"
                          value={folderForm.name}
                          onChange={(e) => setFolderForm({ ...folderForm, name: e.target.value })}
                          placeholder="e.g., 'Risk Assessment', 'Documentation', 'Compliance'"
                        />
                      </div>
                      <div>
                        <Label htmlFor="folder-desc">General Description</Label>
                        <Textarea
                          id="folder-desc"
                          value={folderForm.description}
                          onChange={(e) => setFolderForm({ ...folderForm, description: e.target.value })}
                          placeholder="Brief overview of this organizational unit"
                          rows={2}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="bg-white dark:bg-slate-800 p-4 rounded-lg border">
                    <h4 className="font-medium mb-3 text-blue-800 dark:text-blue-200">Hierarchy Placement</h4>
                    <div>
                      <Label>Parent Folder</Label>
                      <Select
                        value={folderForm.parent_id}
                        onValueChange={(value) =>
                          setFolderForm({
                            ...folderForm,
                            parent_id: value,
                          })
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="root">
                            <div className="flex items-center gap-2">
                              <FolderTree className="h-4 w-4" />
                              Root Level
                            </div>
                          </SelectItem>
                          {getOrganizationalFolders().map((folder) => (
                            <SelectItem key={folder.id} value={folder.id}>
                              <div className="flex items-center gap-2">
                                {"  ".repeat(folder.level)}
                                <Folder className="h-4 w-4" />
                                {folder.path}
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>

                {/* Right: Folder Specifications */}
                <div className="space-y-4">
                  <div className="bg-white dark:bg-slate-800 p-4 rounded-lg border">
                    <h4 className="font-medium mb-3 text-blue-800 dark:text-blue-200">Organizational Purpose</h4>
                    <div className="space-y-3">
                      <div>
                        <Label htmlFor="org-purpose">Purpose Statement *</Label>
                        <Textarea
                          id="org-purpose"
                          value={folderForm.organizational_purpose}
                          onChange={(e) =>
                            setFolderForm({
                              ...folderForm,
                              organizational_purpose: e.target.value,
                            })
                          }
                          placeholder="Define the organizational purpose and what this folder represents"
                          rows={3}
                        />
                      </div>
                      <div>
                        <Label htmlFor="scope-def">Scope Definition</Label>
                        <Textarea
                          id="scope-def"
                          value={folderForm.scope_definition}
                          onChange={(e) => setFolderForm({ ...folderForm, scope_definition: e.target.value })}
                          placeholder="Define what types of work/tasks belong in this folder"
                          rows={2}
                        />
                      </div>
                      <div>
                        <Label>Responsible Person</Label>
                        <Select
                          value={folderForm.responsible_person}
                          onValueChange={(value) =>
                            setFolderForm({
                              ...folderForm,
                              responsible_person: value,
                            })
                          }
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select responsible person" />
                          </SelectTrigger>
                          <SelectContent>
                            {assigneeOptions.map((option) => (
                              <SelectItem key={option.value} value={option.value}>
                                {option.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-6 flex justify-end">
                <Button
                  onClick={handleCreateFolder}
                  disabled={!folderForm.name.trim() || !folderForm.organizational_purpose.trim() || isLoading}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  <Folder className="h-4 w-4 mr-2" />
                  {isLoading ? "Creating..." : "Create Folder"}
                </Button>
              </div>
            </div>
          </TabsContent>

          {/* TASK CREATION TAB */}
          <TabsContent value="tasks" className="space-y-6 mt-6">
            <div className="bg-green-50 dark:bg-green-950/20 p-6 rounded-lg border border-green-200 dark:border-green-800">
              <div className="flex items-center gap-3 mb-4">
                <div className="p-2 bg-green-100 dark:bg-green-900/30 rounded-lg">
                  <FileText className="h-6 w-6 text-green-600" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-green-900 dark:text-green-300">
                    Task Creation & Placement
                  </h3>
                  <p className="text-sm text-green-700 dark:text-green-400">
                    Create executable tasks and place them within the defined organizational structure
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Left: Task Placement & Basic Info */}
                <div className="space-y-4">
                  <div className="bg-white dark:bg-slate-800 p-4 rounded-lg border">
                    <h4 className="font-medium mb-3 text-green-800 dark:text-green-200">Task Placement</h4>
                    <div className="space-y-3">
                      <div>
                        <Label>Location in Structure *</Label>
                        <Select
                          value={taskForm.parent_id}
                          onValueChange={(value) =>
                            setTaskForm({
                              ...taskForm,
                              parent_id: value,
                            })
                          }
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select task location" />
                          </SelectTrigger>
                          <SelectContent>
                            {getTaskPlacementOptions().map((option) => (
                              <SelectItem key={option.id} value={option.id}>
                                <div className="flex items-center gap-2">
                                  {"  ".repeat(option.level)}
                                  {option.id === "root" ? (
                                    <FolderTree className="h-4 w-4" />
                                  ) : (
                                    <Folder className="h-4 w-4" />
                                  )}
                                  {option.path}
                                </div>
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="task-name">Task Name *</Label>
                        <Input
                          id="task-name"
                          value={taskForm.name}
                          onChange={(e) => setTaskForm({ ...taskForm, name: e.target.value })}
                          placeholder="e.g., 'Create Risk Matrix', 'Review Compliance Documents'"
                        />
                      </div>
                      <div>
                        <Label htmlFor="task-desc">Task Overview</Label>
                        <Textarea
                          id="task-desc"
                          value={taskForm.description}
                          onChange={(e) => setTaskForm({ ...taskForm, description: e.target.value })}
                          placeholder="Brief overview of the work to be done"
                          rows={2}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="bg-white dark:bg-slate-800 p-4 rounded-lg border">
                    <h4 className="font-medium mb-3 text-green-800 dark:text-green-200">Assignment & Effort</h4>
                    <div className="space-y-3">
                      <div>
                        <Label>Assigned To</Label>
                        <Select
                          value={taskForm.assigned_to}
                          onValueChange={(value) =>
                            setTaskForm({
                              ...taskForm,
                              assigned_to: value,
                            })
                          }
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select assignee" />
                          </SelectTrigger>
                          <SelectContent>
                            {assigneeOptions.map((option) => (
                              <SelectItem key={option.value} value={option.value}>
                                {option.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <Label>Difficulty</Label>
                          <Select
                            value={taskForm.difficulty}
                            onValueChange={(value: "Easy" | "Medium" | "Hard") =>
                              setTaskForm({ ...taskForm, difficulty: value })
                            }
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="Easy">Easy</SelectItem>
                              <SelectItem value="Medium">Medium</SelectItem>
                              <SelectItem value="Hard">Hard</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                        <div>
                          <Label htmlFor="task-days">Days Required</Label>
                          <Input
                            id="task-days"
                            type="number"
                            min="1"
                            value={taskForm.days_required}
                            onChange={(e) =>
                              setTaskForm({
                                ...taskForm,
                                days_required: Number.parseInt(e.target.value) || 1,
                              })
                            }
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Right: Task Specifications */}
                <div className="space-y-4">
                  <div className="bg-white dark:bg-slate-800 p-4 rounded-lg border">
                    <h4 className="font-medium mb-3 text-green-800 dark:text-green-200">Work Definition</h4>
                    <div className="space-y-3">
                      <div>
                        <Label htmlFor="task-objective">Primary Objective *</Label>
                        <Textarea
                          id="task-objective"
                          value={taskForm.objective}
                          onChange={(e) => setTaskForm({ ...taskForm, objective: e.target.value })}
                          placeholder="What is the main goal of this task?"
                          rows={2}
                        />
                      </div>
                      <div>
                        <Label htmlFor="task-deliverables">Expected Deliverables</Label>
                        <Textarea
                          id="task-deliverables"
                          value={taskForm.deliverables}
                          onChange={(e) => setTaskForm({ ...taskForm, deliverables: e.target.value })}
                          placeholder="• List specific outputs&#10;• Documents to be created&#10;• Results to be achieved"
                          rows={3}
                        />
                      </div>
                      <div>
                        <Label htmlFor="task-criteria">Acceptance Criteria</Label>
                        <Textarea
                          id="task-criteria"
                          value={taskForm.acceptance_criteria}
                          onChange={(e) => setTaskForm({ ...taskForm, acceptance_criteria: e.target.value })}
                          placeholder="• Conditions for completion&#10;• Quality standards&#10;• Approval requirements"
                          rows={3}
                        />
                      </div>
                      <div>
                        <Label htmlFor="task-prereq">Prerequisites (Optional)</Label>
                        <Textarea
                          id="task-prereq"
                          value={taskForm.prerequisites}
                          onChange={(e) => setTaskForm({ ...taskForm, prerequisites: e.target.value })}
                          placeholder="• Dependencies on other tasks&#10;• Required resources&#10;• Preconditions"
                          rows={2}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="mt-6 flex justify-end">
                <Button
                  onClick={handleCreateTask}
                  disabled={!taskForm.name.trim() || !taskForm.objective.trim() || isLoading}
                  className="bg-green-600 hover:bg-green-700"
                >
                  <FileText className="h-4 w-4 mr-2" />
                  {isLoading ? "Creating..." : "Create Task"}
                </Button>
              </div>
            </div>

            {/* Placement Rules */}
            <div className="bg-amber-50 dark:bg-amber-950/20 p-4 rounded-lg border border-amber-200 dark:border-amber-800">
              <h4 className="font-medium text-amber-800 dark:text-amber-200 mb-2 flex items-center gap-2">
                <AlertCircle className="h-4 w-4" />
                Task Placement Rules
              </h4>
              <div className="text-sm text-amber-700 dark:text-amber-300 space-y-1">
                <p>• Tasks can only be placed at root level or within organizational folders</p>
                <p>• Tasks cannot be placed within other tasks</p>
                <p>• Each task must have a clear objective and deliverables</p>
                <p>• Folder structure must be defined before task placement</p>
              </div>
            </div>
          </TabsContent>
        </Tabs>

        <DialogFooter className="flex justify-between items-center pt-6">
          <div className="text-sm text-muted-foreground">
            {activeTab === "structure"
              ? "Define organizational structure with folders"
              : "Create executable tasks within the structure"}
          </div>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
