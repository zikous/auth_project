"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Dialog, DialogContent } from "@/components/ui/dialog"
import { Plus, CheckSquare, Target, FolderTree, FolderOpen, Clock } from "lucide-react"
import type { ReviewPlan } from "@/lib/types"
import { TaskTree } from "@/components/tasks/task-tree-simple"
import { TaskDetailsPanel } from "@/components/tasks/task-details-panel"
import { SimpleTaskCreator } from "@/components/tasks/task-creator-simple"
import { TaskEditDialog } from "@/components/tasks/task-edit-dialog"
import { ConfirmationDialog } from "@/components/confirmation-dialog"
import { useTaskManagement } from "@/hooks/use-task-management"
import { useTaskAggregation } from "@/hooks/use-task-aggregation"
import { useToast } from "@/hooks/use-toast"

interface TaskManagementPanelProps {
  initialPlan: ReviewPlan
  onPlanUpdate?: (plan: ReviewPlan) => void
}

export function TaskManagementPanel({ initialPlan, onPlanUpdate }: TaskManagementPanelProps) {
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [createInParentId, setCreateInParentId] = useState<string | null>(null)
  const [createInParentName, setCreateInParentName] = useState<string>("")
  const [editingTask, setEditingTask] = useState<any>(null)
  const [taskToDelete, setTaskToDelete] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)

  const { toast } = useToast()

  const {
    plan,
    selectedTask,
    setSelectedTask,
    createTask,
    updateTask,
    deleteTask,
    toggleTaskCompletion,
    addDiscussion,
    addConclusion,
    getTaskCompletionPercentage,
    getLeafTaskCount,
    getCompletedLeafTaskCount,
    isLeafTask,
  } = useTaskManagement(initialPlan, onPlanUpdate)

  // Pass selectedTask?.id explicitly and handle null case
  const { selectedTaskAggregation } = useTaskAggregation(plan.tasks, selectedTask?.id || null)

  // Calculate plan statistics
  const totalTasks = getLeafTaskCount()
  const completedTasks = getCompletedLeafTaskCount()
  const overallProgress = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0

  // Event handlers
  const handleCreateInFolder = (parentId: string | null, parentName?: string) => {
    setCreateInParentId(parentId)
    setCreateInParentName(parentName || "Root Level")
    setIsCreateDialogOpen(true)
  }

  const handleCreateTask = async (taskData: any) => {
    setIsLoading(true)
    try {
      await createTask(taskData)
      setIsCreateDialogOpen(false)
      setCreateInParentId(null)
      setCreateInParentName("")
      toast({ title: `${taskData.is_folder ? "Folder" : "Task"} created successfully` })
    } catch (error) {
      console.error("Error creating task:", error)
      toast({ title: "Error creating task", variant: "destructive" })
    } finally {
      setIsLoading(false)
    }
  }

  const handleEditTask = (taskData: any) => {
    if (editingTask) {
      try {
        updateTask(editingTask.id, taskData)
        setEditingTask(null)
        toast({ title: "Task updated" })
      } catch (error) {
        console.error("Error updating task:", error)
        toast({ title: "Error updating task", variant: "destructive" })
      }
    }
  }

  const handleDeleteTask = (taskId: string) => {
    setTaskToDelete(taskId)
  }

  const confirmDelete = () => {
    if (taskToDelete) {
      try {
        deleteTask(taskToDelete)
        setTaskToDelete(null)
        toast({ title: "Task deleted successfully" })
      } catch (error) {
        console.error("Error deleting task:", error)
        toast({ title: "Error deleting task", variant: "destructive" })
      }
    }
  }

  const handleTaskToggle = (taskId: string) => {
    try {
      toggleTaskCompletion(taskId)
      toast({ title: "Task updated" })
    } catch (error) {
      console.error("Error toggling task:", error)
      toast({ title: "Error updating task", variant: "destructive" })
    }
  }

  return (
    <div className="space-y-6">
      {/* Plan Header */}
      <Card className="border-l-4 border-l-blue-500 bg-gradient-to-r from-blue-50 via-white to-green-50">
        <CardHeader className="pb-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-blue-100 rounded-xl">
                <Target className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <CardTitle className="text-xl text-slate-800">{plan.name}</CardTitle>
                <p className="text-sm text-slate-600 mt-1">{plan.description}</p>
                <div className="flex items-center gap-2 mt-2">
                  <Badge variant="outline" className="text-xs">
                    Plan ID: {plan.id}
                  </Badge>
                  <Badge variant="secondary" className="bg-blue-100 text-blue-700 px-2 py-1 text-xs">
                    {plan.validation_status}
                  </Badge>
                </div>
              </div>
            </div>
          </div>
        </CardHeader>
      </Card>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <CheckSquare className="h-8 w-8 text-blue-600" />
              <div>
                <p className="text-sm text-slate-600">Progress</p>
                <p className="text-2xl font-bold">{overallProgress}%</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <FolderOpen className="h-8 w-8 text-green-600" />
              <div>
                <p className="text-sm text-slate-600">Total Tasks</p>
                <p className="text-2xl font-bold">{totalTasks}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <CheckSquare className="h-8 w-8 text-green-600" />
              <div>
                <p className="text-sm text-slate-600">Completed</p>
                <p className="text-2xl font-bold">{completedTasks}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Clock className="h-8 w-8 text-orange-600" />
              <div>
                <p className="text-sm text-slate-600">Remaining</p>
                <p className="text-2xl font-bold">{totalTasks - completedTasks}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Progress Bar */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium">Overall Progress</span>
            <span className="text-sm font-bold">{overallProgress}%</span>
          </div>
          <Progress value={overallProgress} className="h-2" />
        </CardContent>
      </Card>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Task Tree */}
        <Card>
          <CardHeader className="border-b">
            <div className="flex justify-between items-center">
              <CardTitle className="flex items-center gap-2">
                <FolderTree className="h-5 w-5 text-blue-600" />
                Tasks
              </CardTitle>
              <Button
                size="sm"
                onClick={() => setIsCreateDialogOpen(true)}
                className="bg-gradient-to-r from-blue-600 to-green-600 hover:from-blue-700 hover:to-green-700"
              >
                <Plus className="h-4 w-4 mr-2" />
                Create
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <TaskTree
              tasks={plan.tasks}
              onTaskSelect={setSelectedTask}
              onTaskEdit={setEditingTask}
              onTaskDelete={handleDeleteTask}
              onTaskToggle={handleTaskToggle}
              onCreateInFolder={handleCreateInFolder}
              selectedTaskId={selectedTask?.id}
              getTaskCompletionPercentage={getTaskCompletionPercentage}
              getTaskDifficulty={() => "Medium"}
              isLeafTask={isLeafTask}
            />
          </CardContent>
        </Card>

        {/* Task Details */}
        <TaskDetailsPanel
          task={selectedTask}
          plan={plan}
          aggregation={selectedTaskAggregation}
          isLeafTask={selectedTask ? isLeafTask(selectedTask.id) : false}
          onAddDiscussion={(taskId, message) => {
            try {
              addDiscussion(taskId, message)
              toast({ title: "Discussion added" })
            } catch (error) {
              console.error("Error adding discussion:", error)
              toast({ title: "Error adding discussion", variant: "destructive" })
            }
          }}
          onAddConclusion={(taskId, message) => {
            try {
              addConclusion(taskId, message)
              toast({ title: "Conclusion added" })
            } catch (error) {
              console.error("Error adding conclusion:", error)
              toast({ title: "Error adding conclusion", variant: "destructive" })
            }
          }}
          getTaskCompletionPercentage={getTaskCompletionPercentage}
          getTaskDifficulty={() => "Medium"}
        />
      </div>

      {/* Dialogs */}
      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent className="max-w-lg">
          <SimpleTaskCreator
            plan={plan}
            onCreateTask={handleCreateTask}
            onClose={() => {
              setIsCreateDialogOpen(false)
              setCreateInParentId(null)
              setCreateInParentName("")
            }}
            isLoading={isLoading}
            parentId={createInParentId}
            parentName={createInParentName}
          />
        </DialogContent>
      </Dialog>

      {editingTask && (
        <TaskEditDialog
          isOpen={!!editingTask}
          onClose={() => setEditingTask(null)}
          onSubmit={handleEditTask}
          task={editingTask}
          plan={plan}
          isLoading={false}
          existingTasks={plan.tasks}
        />
      )}

      <ConfirmationDialog
        open={!!taskToDelete}
        onOpenChange={() => setTaskToDelete(null)}
        onConfirm={confirmDelete}
        title="Delete Task"
        description="Are you sure? This will also delete all child tasks."
        confirmText="Delete"
        cancelText="Cancel"
        variant="destructive"
      />
    </div>
  )
}
