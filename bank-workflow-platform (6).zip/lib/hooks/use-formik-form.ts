"use client"

import { useFormik } from "formik"
import * as Yup from "yup"

// Generic form hook with Formik
export function useFormikForm<T extends Record<string, any>>({
  initialValues,
  validationSchema,
  onSubmit,
  enableReinitialize = true,
}: {
  initialValues: T
  validationSchema?: any
  onSubmit: (values: T) => void | Promise<void>
  enableReinitialize?: boolean
}) {
  const formik = useFormik({
    initialValues,
    validationSchema,
    onSubmit,
    enableReinitialize,
  })

  return {
    ...formik,
    isValid: formik.isValid && formik.dirty,
    hasErrors: Object.keys(formik.errors).length > 0,
  }
}

// Validation schemas
export const reviewValidationSchema = Yup.object({
  id: Yup.string().required("Review ID is required"),
  name: Yup.string().required("Name is required"),
  description: Yup.string(),
})

export const planValidationSchema = Yup.object({
  name: Yup.string().required("Plan name is required"),
  description: Yup.string(),
  attached_reviews: Yup.string().required("Review selection is required"),
  man_days: Yup.number().min(0, "Man days must be positive"),
})

export const taskValidationSchema = Yup.object({
  name: Yup.string().required("Task name is required"),
  description: Yup.string(),
  days_required: Yup.number().min(1, "Days required must be at least 1"),
  difficulty: Yup.string().oneOf(["Easy", "Medium", "Hard"]),
  objective: Yup.string().when("is_folder", {
    is: false,
    then: (schema) => schema.required("Objective is required for tasks"),
    otherwise: (schema) => schema,
  }),
})

export const folderValidationSchema = Yup.object({
  name: Yup.string().required("Folder name is required"),
  description: Yup.string(),
  organizational_purpose: Yup.string().required("Organizational purpose is required"),
  scope_definition: Yup.string(),
})
