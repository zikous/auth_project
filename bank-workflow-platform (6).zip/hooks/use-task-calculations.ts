"use client"

import type { Task } from "@/lib/types"

interface UseTaskCalculationsProps {
  tasks: Task[]
}

export function useTaskCalculations({ tasks }: UseTaskCalculationsProps) {
  // Simple functions without memoization
  const isLeafTask = (taskId: string): boolean => {
    const task = tasks.find((t) => t.id === taskId)
    if (!task) return false

    // If explicitly marked as folder, it's not a leaf task
    if (task.is_folder) return false

    // If it has children, it's not a leaf task
    const hasChildren = tasks.some((t) => t.parent_id === taskId)
    return !hasChildren
  }

  // Get task completion percentage for folders
  const getTaskCompletionPercentage = (taskId: string): number => {
    const getLeafTasksUnder = (parentId: string): Task[] => {
      const getAllDescendants = (taskId: string): Task[] => {
        const children = tasks.filter((task) => task.parent_id === taskId)
        let allDescendants: Task[] = []

        children.forEach((child) => {
          if (isLeafTask(child.id)) {
            allDescendants.push(child)
          } else {
            allDescendants = allDescendants.concat(getAllDescendants(child.id))
          }
        })

        return allDescendants
      }

      return getAllDescendants(parentId)
    }

    const leafTasks = getLeafTasksUnder(taskId)
    if (leafTasks.length === 0) return 0

    const completedTasks = leafTasks.filter((task) => task.completed).length
    return Math.round((completedTasks / leafTasks.length) * 100)
  }

  // Get aggregated difficulty for folders
  const getTaskDifficulty = (taskId: string): "Easy" | "Medium" | "Hard" | null => {
    const task = tasks.find((t) => t.id === taskId)
    if (!task) return null

    // For leaf tasks, return their difficulty
    if (isLeafTask(taskId)) {
      return task.difficulty
    }

    // For folders, calculate average difficulty of child leaf tasks
    const getLeafTasksUnder = (parentId: string): Task[] => {
      const getAllDescendants = (taskId: string): Task[] => {
        const children = tasks.filter((task) => task.parent_id === taskId)
        let allDescendants: Task[] = []

        children.forEach((child) => {
          if (isLeafTask(child.id)) {
            allDescendants.push(child)
          } else {
            allDescendants = allDescendants.concat(getAllDescendants(child.id))
          }
        })

        return allDescendants
      }

      return getAllDescendants(parentId)
    }

    const leafTasks = getLeafTasksUnder(taskId)
    if (leafTasks.length === 0) return null

    const difficultyValues = { Easy: 1, Medium: 2, Hard: 3 }
    const totalDifficulty = leafTasks.reduce((sum, task) => sum + difficultyValues[task.difficulty], 0)
    const averageDifficulty = totalDifficulty / leafTasks.length

    if (averageDifficulty <= 1.5) return "Easy"
    if (averageDifficulty <= 2.5) return "Medium"
    return "Hard"
  }

  // Get total count of leaf tasks
  const getLeafTaskCount = (): number => {
    return tasks.filter((task) => isLeafTask(task.id)).length
  }

  // Get count of completed leaf tasks
  const getCompletedLeafTaskCount = (): number => {
    return tasks.filter((task) => isLeafTask(task.id) && task.completed).length
  }

  // Get count of folders
  const getFolderCount = (): number => {
    return tasks.filter((task) => !isLeafTask(task.id)).length
  }

  return {
    isLeafTask,
    getTaskCompletionPercentage,
    getTaskDifficulty,
    getLeafTaskCount,
    getCompletedLeafTaskCount,
    getFolderCount,
  }
}
