"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Plus, Users } from "lucide-react"
import type { ReviewPlan } from "@/lib/types"
import { usePlans } from "@/hooks/use-plans"
import { useReviews } from "@/hooks/use-reviews"
import { useToast } from "@/hooks/use-toast"
import { PageHeader } from "@/components/common/page-header"
import { SearchBar } from "@/components/common/search-bar"
import { LoadingState } from "@/components/common/loading-state"
import { ErrorState } from "@/components/common/error-state"
import { EmptyState } from "@/components/common/empty-state"
import { BulkActions } from "@/components/common/bulk-actions"
import { FormDialog } from "@/components/common/form-dialog"
import { PlanTable } from "@/components/plans/plan-table"
import { PlanForm } from "@/components/plans/plan-form"

export default function PlansPage() {
  const { plans, loading, error, createPlan, updatePlan, deletePlan, deleteMultiplePlans, updatePlanStatus } =
    usePlans()
  const { reviews } = useReviews()
  const { toast } = useToast()

  const [searchTerm, setSearchTerm] = useState("")
  const [selectedItems, setSelectedItems] = useState<string[]>([])
  const [isCreateOpen, setIsCreateOpen] = useState(false)
  const [editingPlan, setEditingPlan] = useState<ReviewPlan | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)

  const filteredPlans = plans.filter(
    (plan) =>
      plan.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      plan.id.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const handleFormSubmit = async (formData: {
    name: string
    description: string
    attached_reviews: string
    man_days: number
  }) => {
    if (!formData.name.trim() || !formData.attached_reviews) {
      toast({
        title: "Validation Error",
        description: "Please enter a plan name and select a review",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)
    const result = editingPlan ? await updatePlan(editingPlan.id, formData) : await createPlan(formData)

    if (result.success) {
      toast({ title: "Success", description: `Plan ${editingPlan ? "updated" : "created"} successfully` })
      setIsCreateOpen(false)
      setEditingPlan(null)
    } else {
      toast({
        title: "Error",
        description: result.error || `Failed to ${editingPlan ? "update" : "create"} plan`,
        variant: "destructive",
      })
    }
    setIsSubmitting(false)
  }

  const handleDelete = async (id: string) => {
    const result = await deletePlan(id)
    if (result.success) {
      toast({ title: "Success", description: "Plan deleted successfully" })
      setSelectedItems(selectedItems.filter((item) => item !== id))
    } else {
      toast({ title: "Error", description: result.error || "Failed to delete plan", variant: "destructive" })
    }
  }

  const handleBulkDelete = async () => {
    const result = await deleteMultiplePlans(selectedItems)
    if (result.success) {
      toast({ title: "Success", description: `${result.deletedCount} plans deleted successfully` })
      setSelectedItems([])
    } else {
      toast({ title: "Error", description: result.error || "Failed to delete plans", variant: "destructive" })
    }
  }

  const handleStatusChange = async (id: string, newStatus: ReviewPlan["validation_status"]) => {
    const result = await updatePlanStatus(id, newStatus)
    if (result.success) {
      toast({ title: "Success", description: `Plan status updated to ${newStatus}` })
    } else {
      toast({ title: "Error", description: result.error || "Failed to update plan status", variant: "destructive" })
    }
  }

  const handleSelectAll = (checked: boolean) => {
    setSelectedItems(checked ? filteredPlans.map((p) => p.id) : [])
  }

  const handleSelectItem = (id: string, checked: boolean) => {
    setSelectedItems(checked ? [...selectedItems, id] : selectedItems.filter((item) => item !== id))
  }

  const planForm = PlanForm({ plan: editingPlan, reviews, onSubmit: handleFormSubmit })

  if (loading) return <LoadingState message="Loading plans..." />
  if (error) return <ErrorState title="Error Loading Plans" message={error} />

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-full mx-auto p-6">
        <PageHeader title="Plans" subtitle={`${plans.length} total plans`}>
          <BulkActions selectedCount={selectedItems.length} onDelete={handleBulkDelete} />
          <Button onClick={() => setIsCreateOpen(true)} className="bg-green-600 hover:bg-green-700">
            <Plus className="h-4 w-4 mr-2" />
            New Plan
          </Button>
        </PageHeader>

        <div className="mb-6">
          <SearchBar value={searchTerm} onChange={setSearchTerm} placeholder="Search plans..." />
        </div>

        {filteredPlans.length === 0 ? (
          <EmptyState
            icon={<Users className="h-12 w-12 text-gray-400" />}
            title="No plans found"
            description={searchTerm ? "Try a different search term" : "Create your first plan to get started"}
            action={
              !searchTerm ? (
                <Button onClick={() => setIsCreateOpen(true)} className="bg-green-600 hover:bg-green-700">
                  <Plus className="h-4 w-4 mr-2" />
                  New Plan
                </Button>
              ) : undefined
            }
          />
        ) : (
          <PlanTable
            plans={filteredPlans}
            selectedItems={selectedItems}
            onSelectAll={handleSelectAll}
            onSelectItem={handleSelectItem}
            onEdit={setEditingPlan}
            onDelete={handleDelete}
            onStatusChange={handleStatusChange}
          />
        )}

        <FormDialog
          open={isCreateOpen || !!editingPlan}
          onOpenChange={(open) => {
            setIsCreateOpen(open)
            if (!open) setEditingPlan(null)
          }}
          title={editingPlan ? "Edit Plan" : "New Plan"}
          onSubmit={planForm.handleSubmit}
          onCancel={() => {
            setIsCreateOpen(false)
            setEditingPlan(null)
          }}
          isLoading={isSubmitting}
          isValid={planForm.isValid}
          submitLabel={editingPlan ? "Save" : "Create"}
        >
          {planForm.form}
        </FormDialog>
      </div>
    </div>
  )
}
