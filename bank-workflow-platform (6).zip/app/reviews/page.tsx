"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Plus, FileText } from "lucide-react"
import { useReviews } from "@/hooks/use-reviews"
import { usePlans } from "@/hooks/use-plans"
import { useToast } from "@/hooks/use-toast"
import { PageHeader } from "@/components/common/page-header"
import { SearchBar } from "@/components/common/search-bar"
import { LoadingState } from "@/components/common/loading-state"
import { ErrorState } from "@/components/common/error-state"
import { EmptyState } from "@/components/common/empty-state"
import { BulkActions } from "@/components/common/bulk-actions"
import { FormDialog } from "@/components/common/form-dialog"
import { ReviewTable } from "@/components/reviews/review-table"
import { ReviewForm } from "@/components/reviews/review-form"
import type { Review } from "@/lib/types"

export default function ReviewsPage() {
  const { reviews, loading, error, createReview, updateReview, deleteReview, deleteMultipleReviews } = useReviews()
  const { plans } = usePlans()
  const { toast } = useToast()

  const [searchTerm, setSearchTerm] = useState("")
  const [isCreateOpen, setIsCreateOpen] = useState(false)
  const [editingReview, setEditingReview] = useState<Review | null>(null)
  const [selectedItems, setSelectedItems] = useState<string[]>([])
  const [viewingLinkedPlans, setViewingLinkedPlans] = useState<string | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)

  const filteredReviews = reviews.filter(
    (review) =>
      review.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      review.id.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  const getLinkedPlans = (reviewId: string) => {
    return plans.filter((plan) => plan.attached_reviews === reviewId)
  }

  const handleFormSubmit = async (formData: { id: string; name: string; description: string }) => {
    if (!formData.id.trim() || !formData.name.trim()) {
      toast({ title: "Validation Error", description: "Please fill in all required fields", variant: "destructive" })
      return
    }

    setIsSubmitting(true)
    try {
      const result = editingReview ? await updateReview(editingReview.id, formData) : await createReview(formData)

      if (result.success) {
        toast({ title: "Success", description: `Review ${editingReview ? "updated" : "created"} successfully` })
        setIsCreateOpen(false)
        setEditingReview(null)
      } else {
        toast({
          title: "Error",
          description: result.error || `Failed to ${editingReview ? "update" : "create"} review`,
          variant: "destructive",
        })
      }
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleDelete = async (id: string) => {
    const result = await deleteReview(id)
    if (result.success) {
      toast({ title: "Success", description: "Review deleted successfully" })
      setSelectedItems(selectedItems.filter((item) => item !== id))
    } else {
      toast({ title: "Error", description: result.error || "Failed to delete review", variant: "destructive" })
    }
  }

  const handleBulkDelete = async () => {
    const result = await deleteMultipleReviews(selectedItems)
    if (result.success) {
      toast({ title: "Success", description: `${result.deletedCount} reviews deleted successfully` })
      setSelectedItems([])
    } else {
      toast({ title: "Error", description: result.error || "Failed to delete reviews", variant: "destructive" })
    }
  }

  const handleSelectAll = (checked: boolean) => {
    setSelectedItems(checked ? filteredReviews.map((r) => r.id) : [])
  }

  const handleSelectItem = (id: string, checked: boolean) => {
    setSelectedItems(checked ? [...selectedItems, id] : selectedItems.filter((item) => item !== id))
  }

  const reviewForm = ReviewForm({ review: editingReview, onSubmit: handleFormSubmit })

  if (loading) return <LoadingState message="Loading reviews..." />
  if (error) return <ErrorState title="Error Loading Reviews" message={error} />

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto p-6">
        <PageHeader title="Reviews" subtitle={`${reviews.length} total reviews`}>
          <BulkActions selectedCount={selectedItems.length} onDelete={handleBulkDelete} />
          <Button onClick={() => setIsCreateOpen(true)} className="bg-blue-600 hover:bg-blue-700">
            <Plus className="h-4 w-4 mr-2" />
            New Review
          </Button>
        </PageHeader>

        <div className="mb-6">
          <SearchBar value={searchTerm} onChange={setSearchTerm} placeholder="Search reviews..." />
        </div>

        {filteredReviews.length === 0 ? (
          <EmptyState
            icon={<FileText className="h-12 w-12 text-gray-400" />}
            title="No reviews found"
            description={searchTerm ? "Try a different search term" : "Create your first review to get started"}
            action={
              !searchTerm ? (
                <Button onClick={() => setIsCreateOpen(true)} className="bg-blue-600 hover:bg-blue-700">
                  <Plus className="h-4 w-4 mr-2" />
                  New Review
                </Button>
              ) : undefined
            }
          />
        ) : (
          <ReviewTable
            reviews={filteredReviews}
            plans={plans}
            selectedItems={selectedItems}
            onSelectAll={handleSelectAll}
            onSelectItem={handleSelectItem}
            onEdit={setEditingReview}
            onDelete={handleDelete}
            onViewLinkedPlans={setViewingLinkedPlans}
          />
        )}

        <FormDialog
          open={isCreateOpen || !!editingReview}
          onOpenChange={(open) => {
            setIsCreateOpen(open)
            if (!open) setEditingReview(null)
          }}
          title={editingReview ? "Edit Review" : "New Review"}
          onSubmit={reviewForm.handleSubmit}
          onCancel={() => {
            setIsCreateOpen(false)
            setEditingReview(null)
          }}
          isLoading={isSubmitting}
          isValid={reviewForm.isValid}
          submitLabel={editingReview ? "Save" : "Create"}
        >
          {reviewForm.form}
        </FormDialog>

        {/* Linked Plans Dialog */}
        <Dialog open={!!viewingLinkedPlans} onOpenChange={() => setViewingLinkedPlans(null)}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>
                Linked Plans for {viewingLinkedPlans && reviews.find((r) => r.id === viewingLinkedPlans)?.name}
              </DialogTitle>
            </DialogHeader>
            <div className="py-4">
              {viewingLinkedPlans && (
                <div className="space-y-3">
                  {getLinkedPlans(viewingLinkedPlans).map((plan) => (
                    <div key={plan.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="bg-green-100 rounded p-2">
                          <FileText className="h-4 w-4 text-green-600" />
                        </div>
                        <div>
                          <h4 className="font-medium text-gray-900">{plan.name}</h4>
                          <p className="text-sm text-gray-500">{plan.id}</p>
                          <p className="text-xs text-gray-400 mt-1">{plan.description}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <span className="text-xs px-2 py-1 bg-gray-100 rounded-full">{plan.validation_status}</span>
                        <Button size="sm" variant="outline" asChild>
                          <a href={`/plans/${plan.id}`}>View</a>
                        </Button>
                      </div>
                    </div>
                  ))}
                  {getLinkedPlans(viewingLinkedPlans).length === 0 && (
                    <EmptyState
                      icon={<FileText className="h-8 w-8 text-gray-400" />}
                      title="No linked plans"
                      description="No plans are linked to this review"
                    />
                  )}
                </div>
              )}
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setViewingLinkedPlans(null)}>
                Close
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </div>
  )
}
