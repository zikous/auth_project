"use client"

import { useState, useEffect, useCallback } from "react"
import { api } from "@/lib/api/mock-api"

interface UseDataManagementOptions<T> {
  apiEndpoint: keyof typeof api
  initialData?: T[]
}

export function useDataManagement<T extends { id: string }>({
  apiEndpoint,
  initialData = [],
}: UseDataManagementOptions<T>) {
  const [data, setData] = useState<T[]>(initialData)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const endpoint = api[apiEndpoint] as any

  const fetchData = useCallback(async () => {
    try {
      setLoading(true)
      setError(null)
      const response = await endpoint.getAll()
      if (response.success) {
        setData(response.data)
      } else {
        setError(response.error || "Failed to fetch data")
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unknown error occurred")
    } finally {
      setLoading(false)
    }
  }, [endpoint])

  const createItem = useCallback(
    async (itemData: Partial<T>) => {
      try {
        const response = await endpoint.create(itemData)
        if (response.success) {
          setData((prev) => [...prev, response.data])
          return { success: true, data: response.data }
        }
        return { success: false, error: response.error }
      } catch (err) {
        return { success: false, error: err instanceof Error ? err.message : "Unknown error" }
      }
    },
    [endpoint],
  )

  const updateItem = useCallback(
    async (id: string, updates: Partial<T>) => {
      try {
        const response = await endpoint.update(id, updates)
        if (response.success) {
          setData((prev) => prev.map((item) => (item.id === id ? response.data : item)))
          return { success: true, data: response.data }
        }
        return { success: false, error: response.error }
      } catch (err) {
        return { success: false, error: err instanceof Error ? err.message : "Unknown error" }
      }
    },
    [endpoint],
  )

  const deleteItem = useCallback(
    async (id: string) => {
      try {
        const response = await endpoint.delete(id)
        if (response.success) {
          setData((prev) => prev.filter((item) => item.id !== id))
          return { success: true }
        }
        return { success: false, error: response.error }
      } catch (err) {
        return { success: false, error: err instanceof Error ? err.message : "Unknown error" }
      }
    },
    [endpoint],
  )

  const deleteMultiple = useCallback(
    async (ids: string[]) => {
      try {
        const results = await Promise.all(ids.map((id) => endpoint.delete(id)))
        const successful = results.filter((r) => r.success)
        if (successful.length > 0) {
          setData((prev) => prev.filter((item) => !ids.includes(item.id)))
        }
        return { success: successful.length === ids.length, deletedCount: successful.length }
      } catch (err) {
        return { success: false, error: err instanceof Error ? err.message : "Unknown error" }
      }
    },
    [endpoint],
  )

  useEffect(() => {
    fetchData()
  }, [fetchData])

  return {
    data,
    loading,
    error,
    createItem,
    updateItem,
    deleteItem,
    deleteMultiple,
    refetch: fetchData,
  }
}
