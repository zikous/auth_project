"use client"

import type { Review } from "@/lib/types"
import { useDataManagement } from "./use-data-management"

export function useReviews() {
  const {
    data: reviews,
    loading,
    error,
    createItem: createReview,
    updateItem: updateReview,
    deleteItem: deleteReview,
    deleteMultiple: deleteMultipleReviews,
    refetch,
  } = useDataManagement<Review>({ apiEndpoint: "reviews" })

  return {
    reviews,
    loading,
    error,
    createReview,
    updateReview,
    deleteReview,
    deleteMultipleReviews,
    refetch,
  }
}
