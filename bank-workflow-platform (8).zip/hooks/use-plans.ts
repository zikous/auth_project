"use client"

import type { ReviewPlan } from "@/lib/types"
import { useDataManagement } from "./use-data-management"

export function usePlans() {
  const {
    data: plans,
    loading,
    error,
    createItem: createPlan,
    updateItem: updatePlan,
    deleteItem: deletePlan,
    deleteMultiple: deleteMultiplePlans,
    refetch,
  } = useDataManagement<ReviewPlan>({ apiEndpoint: "plans" })

  const updatePlanStatus = async (id: string, status: ReviewPlan["validation_status"]) => {
    return updatePlan(id, { validation_status: status })
  }

  return {
    plans,
    loading,
    error,
    createPlan,
    updatePlan,
    deletePlan,
    deleteMultiplePlans,
    updatePlanStatus,
    refetch,
  }
}
