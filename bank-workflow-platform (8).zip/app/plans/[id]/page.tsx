"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import type { ReviewPlan } from "@/lib/types"
import { TaskManagementPanel } from "@/components/tasks/task-management-panel"
import { LoadingState } from "@/components/common/loading-state"
import { ErrorState } from "@/components/common/error-state"
import { api } from "@/lib/api/mock-api"

export default function PlanDetailPage() {
  const params = useParams()
  const router = useRouter()
  const planId = params.id as string

  const [plan, setPlan] = useState<ReviewPlan | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const loadPlan = async () => {
      setIsLoading(true)
      setError(null)

      try {
        const response = await api.plans.getById(planId)
        if (response.success) {
          setPlan(response.data)
        } else {
          setError(response.error || "Failed to load plan")
        }
      } catch (error) {
        console.error("Failed to load plan:", error)
        setError("Failed to load plan")
      } finally {
        setIsLoading(false)
      }
    }

    loadPlan()
  }, [planId])

  if (isLoading) {
    return <LoadingState message="Loading plan..." />
  }

  if (error || !plan) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center space-y-4">
          <ErrorState title="Error Loading Plan" message={error || "Plan not found"} />
          <Button onClick={() => router.push("/plans")}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Plans
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="container mx-auto p-6">
        {/* Header */}
        <div className="flex items-center gap-4 mb-6">
          <Button variant="ghost" onClick={() => router.push("/plans")}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Plans
          </Button>
        </div>

        {/* Task Management Panel */}
        <TaskManagementPanel initialPlan={plan} />
      </div>
    </div>
  )
}
