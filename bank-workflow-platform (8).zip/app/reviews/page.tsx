"use client"

import { useState } from "react"
import { FileText, LinkIcon } from "lucide-react"
import { useReviews } from "@/hooks/use-reviews"
import { usePlans } from "@/hooks/use-plans"
import { useToast } from "@/hooks/use-toast"
import { PageLayout } from "@/components/common/page-layout"
import { DataTable } from "@/components/common/data-table"
import { FormDialog } from "@/components/common/form-dialog"
import { ReviewForm } from "@/components/reviews/review-form"
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import type { Review } from "@/lib/types"

export default function ReviewsPage() {
  const { reviews, loading, error, createReview, updateReview, deleteReview, deleteMultipleReviews } = useReviews()
  const { plans } = usePlans()
  const { toast } = useToast()

  const [selectedItems, setSelectedItems] = useState<string[]>([])
  const [isCreateOpen, setIsCreateOpen] = useState(false)
  const [editingReview, setEditingReview] = useState<Review | null>(null)
  const [viewingLinkedPlans, setViewingLinkedPlans] = useState<string | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)

  const getLinkedPlans = (reviewId: string) => plans.filter((plan) => plan.attached_reviews === reviewId)

  const handleFormSubmit = async (formData: { id: string; name: string; description: string }) => {
    if (!formData.id.trim() || !formData.name.trim()) {
      toast({ title: "Validation Error", description: "Please fill in all required fields", variant: "destructive" })
      return
    }

    setIsSubmitting(true)
    try {
      const result = editingReview ? await updateReview(editingReview.id, formData) : await createReview(formData)

      if (result.success) {
        toast({ title: "Success", description: `Review ${editingReview ? "updated" : "created"} successfully` })
        setIsCreateOpen(false)
        setEditingReview(null)
      } else {
        toast({ title: "Error", description: result.error || "Operation failed", variant: "destructive" })
      }
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleDelete = async (id: string) => {
    const result = await deleteReview(id)
    if (result.success) {
      toast({ title: "Success", description: "Review deleted successfully" })
      setSelectedItems((prev) => prev.filter((item) => item !== id))
    } else {
      toast({ title: "Error", description: result.error || "Failed to delete review", variant: "destructive" })
    }
  }

  const handleBulkDelete = async () => {
    const result = await deleteMultipleReviews(selectedItems)
    if (result.success) {
      toast({ title: "Success", description: `${result.deletedCount} reviews deleted successfully` })
      setSelectedItems([])
    } else {
      toast({ title: "Error", description: result.error || "Failed to delete reviews", variant: "destructive" })
    }
  }

  const columns = [
    {
      key: "id",
      header: "ID",
      render: (review: Review) => (
        <div className="flex items-center space-x-2">
          <div className="bg-blue-100 rounded p-1">
            <FileText className="h-3 w-3 text-blue-600" />
          </div>
          <span className="text-sm font-mono text-gray-900">{review.id}</span>
        </div>
      ),
    },
    { key: "name", header: "Name" },
    { key: "description", header: "Description" },
    {
      key: "linkedPlans",
      header: "Linked Plans",
      render: (review: Review) => {
        const linkedPlans = getLinkedPlans(review.id)
        return linkedPlans.length > 0 ? (
          <div className="flex items-center space-x-2">
            <span className="text-sm text-gray-600">{linkedPlans.length} plan(s)</span>
            <Button size="sm" variant="ghost" onClick={() => setViewingLinkedPlans(review.id)} className="h-6 w-6 p-0">
              <LinkIcon className="h-3 w-3" />
            </Button>
          </div>
        ) : (
          <span className="text-sm text-gray-400">No plans</span>
        )
      },
    },
  ]

  const reviewForm = ReviewForm({ review: editingReview, onSubmit: handleFormSubmit })

  return (
    <PageLayout
      title="Reviews"
      data={reviews}
      loading={loading}
      error={error}
      selectedItems={selectedItems}
      onSelectAll={(checked) => setSelectedItems(checked ? reviews.map((r) => r.id) : [])}
      onSelectItem={(id, checked) =>
        setSelectedItems((prev) => (checked ? [...prev, id] : prev.filter((item) => item !== id)))
      }
      onBulkDelete={handleBulkDelete}
      onCreate={() => setIsCreateOpen(true)}
      createButtonText="New Review"
      emptyIcon={<FileText className="h-12 w-12 text-gray-400" />}
      emptyTitle="No reviews found"
      emptyDescription="Create your first review to get started"
      searchPlaceholder="Search reviews..."
    >
      <DataTable
        data={reviews}
        columns={columns}
        selectedItems={selectedItems}
        onSelectAll={(checked) => setSelectedItems(checked ? reviews.map((r) => r.id) : [])}
        onSelectItem={(id, checked) =>
          setSelectedItems((prev) => (checked ? [...prev, id] : prev.filter((item) => item !== id)))
        }
        onEdit={setEditingReview}
        onDelete={handleDelete}
      />

      <FormDialog
        open={isCreateOpen || !!editingReview}
        onOpenChange={(open) => {
          setIsCreateOpen(open)
          if (!open) setEditingReview(null)
        }}
        title={editingReview ? "Edit Review" : "New Review"}
        onSubmit={reviewForm.handleSubmit}
        onCancel={() => {
          setIsCreateOpen(false)
          setEditingReview(null)
        }}
        isLoading={isSubmitting}
        isValid={reviewForm.isValid}
        submitLabel={editingReview ? "Save" : "Create"}
      >
        {reviewForm.form}
      </FormDialog>

      <Dialog open={!!viewingLinkedPlans} onOpenChange={() => setViewingLinkedPlans(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              Linked Plans for {viewingLinkedPlans && reviews.find((r) => r.id === viewingLinkedPlans)?.name}
            </DialogTitle>
          </DialogHeader>
          <div className="py-4">
            {viewingLinkedPlans && (
              <div className="space-y-3">
                {getLinkedPlans(viewingLinkedPlans).map((plan) => (
                  <div key={plan.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="bg-green-100 rounded p-2">
                        <FileText className="h-4 w-4 text-green-600" />
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-900">{plan.name}</h4>
                        <p className="text-sm text-gray-500">{plan.id}</p>
                        <p className="text-xs text-gray-400 mt-1">{plan.description}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge variant="outline" className="text-xs">
                        {plan.validation_status}
                      </Badge>
                      <Button size="sm" variant="outline" asChild>
                        <a href={`/plans/${plan.id}`}>View</a>
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setViewingLinkedPlans(null)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PageLayout>
  )
}
