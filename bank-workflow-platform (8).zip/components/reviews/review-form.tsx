"use client"

import { useEffect } from "react"
import { InputField, TextareaField } from "@/components/common/form-field"
import { useFormikForm, reviewValidationSchema } from "@/lib/hooks/use-formik-form"
import type { Review } from "@/lib/types"

interface ReviewFormProps {
  review?: Review | null
  onSubmit: (data: { id: string; name: string; description: string }) => void
}

export function ReviewForm({ review, onSubmit }: ReviewFormProps) {
  const formik = useFormikForm({
    initialValues: {
      id: review?.id || "",
      name: review?.name || "",
      description: review?.description || "",
    },
    validationSchema: reviewValidationSchema,
    onSubmit: (values) => onSubmit(values),
  })

  // Reset form when review changes
  useEffect(() => {
    if (review) {
      formik.setValues({
        id: review.id,
        name: review.name,
        description: review.description,
      })
    } else {
      formik.resetForm()
    }
  }, [review])

  return {
    formik,
    isValid: formik.isValid,
    form: (
      <>
        <InputField name="id" label="Review ID" placeholder="e.g., RVW-001" required formik={formik} />
        <InputField name="name" label="Name" placeholder="Review name" required formik={formik} />
        <TextareaField name="description" label="Description" placeholder="Brief description" formik={formik} />
      </>
    ),
  }
}
