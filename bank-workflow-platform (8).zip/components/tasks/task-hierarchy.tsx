"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  ChevronDown,
  ChevronRight,
  Folder,
  FileText,
  Edit,
  Trash2,
  Plus,
  CheckSquare,
  Square,
  Calendar,
  MessageSquare,
  GitCommit,
} from "lucide-react"
import type { Task } from "@/lib/types"

interface TaskHierarchyProps {
  tasks: Task[]
  selectedTaskId: string | null
  onTaskSelect: (taskId: string) => void
  onTaskEdit: (task: Task) => void
  onTaskDelete: (taskId: string) => void
  onTaskToggle: (taskId: string) => void
  onCreateChild: (parentId: string | null) => void
  getChildTasks: (parentId: string | null) => Task[]
  isFolder: (taskId: string) => boolean
  getTaskProgress: (taskId: string) => number
}

export function TaskHierarchy({
  tasks,
  selectedTaskId,
  onTaskSelect,
  onTaskEdit,
  onTaskDelete,
  onTaskToggle,
  onCreateChild,
  getChildTasks,
  isFolder,
  getTaskProgress,
}: TaskHierarchyProps) {
  const [expandedNodes, setExpandedNodes] = useState<Set<string>>(new Set())

  const toggleExpanded = (taskId: string) => {
    const newExpanded = new Set(expandedNodes)
    if (newExpanded.has(taskId)) {
      newExpanded.delete(taskId)
    } else {
      newExpanded.add(taskId)
    }
    setExpandedNodes(newExpanded)
  }

  const renderTask = (task: Task, level = 0) => {
    const children = getChildTasks(task.id)
    const hasChildren = children.length > 0
    const isExpanded = expandedNodes.has(task.id)
    const isSelected = selectedTaskId === task.id
    const isFolderTask = isFolder(task.id)
    const progress = isFolderTask ? getTaskProgress(task.id) : 0

    return (
      <div key={task.id}>
        <div
          className={`group flex items-center gap-2 p-2 rounded cursor-pointer transition-colors ${
            isSelected ? "bg-blue-100 border border-blue-300" : "hover:bg-slate-50"
          }`}
          style={{ marginLeft: `${level * 20}px` }}
          onClick={() => onTaskSelect(task.id)}
        >
          {/* Expand/Collapse */}
          {hasChildren ? (
            <Button
              variant="ghost"
              size="sm"
              className="h-6 w-6 p-0"
              onClick={(e) => {
                e.stopPropagation()
                toggleExpanded(task.id)
              }}
            >
              {isExpanded ? <ChevronDown className="h-3 w-3" /> : <ChevronRight className="h-3 w-3" />}
            </Button>
          ) : (
            <div className="w-6" />
          )}

          {/* Icon */}
          {isFolderTask ? (
            <Folder className="h-4 w-4 text-blue-600 flex-shrink-0" />
          ) : (
            <FileText className="h-4 w-4 text-slate-600 flex-shrink-0" />
          )}

          {/* Checkbox for non-folders */}
          {!isFolderTask && (
            <Button
              variant="ghost"
              size="sm"
              className="h-6 w-6 p-0"
              onClick={(e) => {
                e.stopPropagation()
                onTaskToggle(task.id)
              }}
            >
              {task.completed ? (
                <CheckSquare className="h-4 w-4 text-green-600" />
              ) : (
                <Square className="h-4 w-4 text-slate-400" />
              )}
            </Button>
          )}

          {/* Content */}
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="text-xs font-mono">
                {task.id}
              </Badge>
              <span
                className={`text-sm font-medium ${task.completed ? "line-through text-slate-500" : "text-slate-900"}`}
              >
                {task.name}
              </span>
              {task.completed && !isFolderTask && (
                <Badge variant="default" className="text-xs bg-green-600">
                  Done
                </Badge>
              )}
              {isFolderTask && (
                <Badge variant="secondary" className="text-xs">
                  Folder
                </Badge>
              )}
            </div>

            {/* Progress for folders */}
            {isFolderTask && children.length > 0 && (
              <div className="flex items-center gap-2 mt-1">
                <Progress value={progress} className="flex-1 h-1" />
                <span className="text-xs text-slate-500">{progress}%</span>
              </div>
            )}

            {/* Meta info */}
            <div className="flex items-center gap-3 mt-1 text-xs text-slate-500">
              {!isFolderTask && task.days_required > 0 && (
                <div className="flex items-center gap-1">
                  <Calendar className="h-3 w-3" />
                  <span>{task.days_required}d</span>
                </div>
              )}
              {(task.discussions.length > 0 || task.conclusions.length > 0) && (
                <div className="flex items-center gap-2">
                  {task.discussions.length > 0 && (
                    <div className="flex items-center gap-1">
                      <MessageSquare className="h-3 w-3" />
                      <span>{task.discussions.length}</span>
                    </div>
                  )}
                  {task.conclusions.length > 0 && (
                    <div className="flex items-center gap-1">
                      <GitCommit className="h-3 w-3" />
                      <span>{task.conclusions.length}</span>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Actions */}
          <div className="opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1">
            {isFolderTask && (
              <Button
                variant="ghost"
                size="sm"
                className="h-6 w-6 p-0"
                onClick={(e) => {
                  e.stopPropagation()
                  onCreateChild(task.id)
                }}
                title="Add child task"
              >
                <Plus className="h-3 w-3" />
              </Button>
            )}
            <Button
              variant="ghost"
              size="sm"
              className="h-6 w-6 p-0"
              onClick={(e) => {
                e.stopPropagation()
                onTaskEdit(task)
              }}
              title="Edit"
            >
              <Edit className="h-3 w-3" />
            </Button>
            <Button
              variant="ghost"
              size="sm"
              className="h-6 w-6 p-0 text-red-600 hover:text-red-700"
              onClick={(e) => {
                e.stopPropagation()
                onTaskDelete(task.id)
              }}
              title="Delete"
            >
              <Trash2 className="h-3 w-3" />
            </Button>
          </div>
        </div>

        {/* Children */}
        {isExpanded && hasChildren && (
          <div className="ml-4 border-l border-slate-200 pl-2 mt-1">
            {children.map((child) => renderTask(child, level + 1))}
          </div>
        )}
      </div>
    )
  }

  const rootTasks = getChildTasks(null)

  if (tasks.length === 0) {
    return (
      <div className="text-center py-12 text-slate-500">
        <FileText className="h-12 w-12 mx-auto mb-4 opacity-30" />
        <p className="text-lg font-medium mb-2">No tasks yet</p>
        <p className="text-sm">Create your first task to get started</p>
      </div>
    )
  }

  return (
    <div className="space-y-1">
      {/* Add Root Task Button */}
      <div className="p-2 border-b border-slate-200">
        <Button
          variant="outline"
          size="sm"
          onClick={() => onCreateChild(null)}
          className="w-full justify-start text-slate-600 hover:text-slate-900"
        >
          <Plus className="h-4 w-4 mr-2" />
          Add Root Task
        </Button>
      </div>

      {/* Task Tree */}
      <div className="space-y-1">{rootTasks.map((task) => renderTask(task))}</div>
    </div>
  )
}
