"use client"

interface ErrorStateProps {
  title: string
  message: string
}

export function ErrorState({ title, message }: ErrorStateProps) {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="text-center">
        <h2 className="text-lg font-semibold text-red-600 mb-2">{title}</h2>
        <p className="text-gray-600">{message}</p>
      </div>
    </div>
  )
}
