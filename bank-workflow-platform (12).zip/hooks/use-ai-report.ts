"use client"

import { useState } from "react"
import type { Task, ReviewPlan } from "@/lib/types"

export function useAIReport(task: Task | null, plan: ReviewPlan | null) {
  const [isGenerating, setIsGenerating] = useState(false)
  const [customPrompt, setCustomPrompt] = useState("")
  const [isEditingPrompt, setIsEditingPrompt] = useState(false)

  if (!task) {
    return {
      currentPrompt: "",
      customPrompt,
      setCustomPrompt,
      isEditingPrompt,
      isGenerating,
      generateReport: () => "",
      handleGenerateReport: async () => {},
      handleEditPrompt: () => {},
      handleSavePrompt: () => {},
      handleCancelPrompt: () => {},
    }
  }

  const defaultPrompt = `Analyze task "${task.name}" (${task.id}):

Status: ${task.completed ? "Completed" : "In Progress"}
Difficulty: ${task.difficulty}
Days Required: ${task.days_required}
Plan: ${plan?.name || "Unknown"} (${plan?.validation_status || "Unknown"})

Discussions: ${task.discussions.length}
Conclusions: ${task.conclusions.length}

Provide a professional analysis with:
1. Executive Summary
2. Task Analysis  
3. Communication Review
4. Risk Assessment
5. Recommendations`

  const currentPrompt = isEditingPrompt && customPrompt ? customPrompt : defaultPrompt

  const generateReport = () => {
    const content = `# Task Analysis Report

**Task:** ${task.name} (${task.id})
**Status:** ${task.completed ? "✅ Completed" : "🔄 In Progress"}
**Plan:** ${plan?.name || "Unknown"}

## Executive Summary
Task "${task.name}" is ${task.completed ? "completed" : "in progress"} with ${task.discussions.length} discussions and ${task.conclusions.length} conclusions.

## Task Analysis
- Completion: ${task.completed ? "100%" : "In Progress"}
- Difficulty: ${task.difficulty}
- Effort: ${task.days_required} days

## Communication Review
- Discussions: ${task.discussions.length} recorded
- Conclusions: ${task.conclusions.length} documented
- Engagement: ${task.discussions.length > 2 ? "Active" : "Limited"}

## Risk Assessment
Risk Level: ${task.difficulty === "Hard" ? "High" : task.difficulty === "Easy" ? "Low" : "Medium"}

## Recommendations
${
  task.completed
    ? "- Archive documentation\n- Share lessons learned"
    : "- Continue progress monitoring\n- Maintain communication"
}

---
*Generated: ${new Date().toLocaleString()}*`

    return content
  }

  const handleGenerateReport = async () => {
    setIsGenerating(true)
    await new Promise((resolve) => setTimeout(resolve, 1500))
    setIsGenerating(false)
  }

  const handleEditPrompt = (editing?: boolean) => {
    setIsEditingPrompt(editing ?? !isEditingPrompt)
    if (editing && !customPrompt) {
      setCustomPrompt(defaultPrompt)
    }
  }

  const handleSavePrompt = () => setIsEditingPrompt(false)
  const handleCancelPrompt = () => {
    setIsEditingPrompt(false)
    setCustomPrompt("")
  }

  return {
    currentPrompt,
    customPrompt,
    setCustomPrompt,
    isEditingPrompt,
    isGenerating,
    generateReport,
    handleGenerateReport,
    handleEditPrompt,
    handleSavePrompt,
    handleCancelPrompt,
  }
}
