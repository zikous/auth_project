"use client"

import { useState, useEffect } from "react"
import { api } from "@/lib/api/mock-api"
import type { ReviewPlan } from "@/lib/types"

export function usePlans() {
  const [plans, setPlans] = useState<ReviewPlan[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchPlans = async () => {
      try {
        const response = await api.plans.getAll()
        if (response.success) {
          setPlans(response.data)
        } else {
          setError(response.error || "Failed to fetch plans")
        }
      } catch (err) {
        setError("Failed to fetch plans")
      } finally {
        setLoading(false)
      }
    }
    fetchPlans()
  }, [])

  const createPlan = async (data: Partial<ReviewPlan>) => {
    const response = await api.plans.create(data)
    if (response.success) {
      setPlans((prev) => [...prev, response.data])
    }
    return response
  }

  const updatePlan = async (id: string, data: Partial<ReviewPlan>) => {
    const response = await api.plans.update(id, data)
    if (response.success) {
      setPlans((prev) => prev.map((p) => (p.id === id ? response.data : p)))
    }
    return response
  }

  const deletePlan = async (id: string) => {
    const response = await api.plans.delete(id)
    if (response.success) {
      setPlans((prev) => prev.filter((p) => p.id !== id))
    }
    return response
  }

  const updatePlanStatus = async (id: string, status: ReviewPlan["validation_status"]) => {
    return updatePlan(id, { validation_status: status })
  }

  return { plans, loading, error, createPlan, updatePlan, deletePlan, updatePlanStatus }
}
