"use client"

import { useState, useEffect } from "react"
import { api } from "@/lib/api/mock-api"
import type { ReviewPlan } from "@/lib/types"

export function usePlanDetail(planId: string) {
  const [plan, setPlan] = useState<ReviewPlan | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const loadPlan = async () => {
      setLoading(true)
      setError(null)

      try {
        const response = await api.plans.getById(planId)
        if (response.success) {
          setPlan(response.data)
        } else {
          setError(response.error || "Failed to load plan")
        }
      } catch (error) {
        console.error("Failed to load plan:", error)
        setError("Failed to load plan")
      } finally {
        setLoading(false)
      }
    }

    if (planId) {
      loadPlan()
    }
  }, [planId])

  return { plan, loading, error }
}
