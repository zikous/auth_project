"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { useReviews } from "@/hooks/use-reviews"
import { useToast } from "@/hooks/use-toast"
import { ReviewList } from "@/components/reviews/review-list"
import { ReviewForm } from "@/components/reviews/review-form"
import { ConfirmationDialog } from "@/components/confirmation-dialog"
import type { Review } from "@/lib/types"

export default function ReviewsPage() {
  const { reviews, loading, error, createReview, updateReview, deleteReview } = useReviews()
  const { toast } = useToast()

  const [isCreateOpen, setIsCreateOpen] = useState(false)
  const [editingReview, setEditingReview] = useState<Review | null>(null)
  const [deletingId, setDeletingId] = useState<string | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSubmit = async (data: { id: string; name: string; description: string }) => {
    setIsSubmitting(true)
    try {
      const result = editingReview ? await updateReview(editingReview.id, data) : await createReview(data)

      if (result.success) {
        toast({ title: `Review ${editingReview ? "updated" : "created"} successfully` })
        setIsCreateOpen(false)
        setEditingReview(null)
      } else {
        toast({ title: "Error", description: result.error, variant: "destructive" })
      }
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleDelete = async () => {
    if (!deletingId) return

    const result = await deleteReview(deletingId)
    if (result.success) {
      toast({ title: "Review deleted successfully" })
    } else {
      toast({ title: "Error", description: result.error, variant: "destructive" })
    }
    setDeletingId(null)
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p>Loading reviews...</p>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-red-600 mb-4">Error: {error}</p>
          <button onClick={() => window.location.reload()}>Retry</button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <div className="container mx-auto p-6">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900">Reviews</h1>
          <p className="text-gray-600">Manage your review items</p>
        </div>

        <ReviewList
          reviews={reviews}
          onEdit={setEditingReview}
          onDelete={setDeletingId}
          onCreate={() => setIsCreateOpen(true)}
        />

        {/* Create/Edit Dialog */}
        <Dialog
          open={isCreateOpen || !!editingReview}
          onOpenChange={(open) => {
            setIsCreateOpen(open)
            if (!open) setEditingReview(null)
          }}
        >
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{editingReview ? "Edit Review" : "New Review"}</DialogTitle>
            </DialogHeader>
            <ReviewForm
              review={editingReview}
              onSubmit={handleSubmit}
              onCancel={() => {
                setIsCreateOpen(false)
                setEditingReview(null)
              }}
              isLoading={isSubmitting}
            />
          </DialogContent>
        </Dialog>

        {/* Delete Confirmation */}
        <ConfirmationDialog
          open={!!deletingId}
          onOpenChange={() => setDeletingId(null)}
          onConfirm={handleDelete}
          title="Delete Review"
          description="Are you sure you want to delete this review? This action cannot be undone."
          confirmText="Delete"
          variant="destructive"
        />
      </div>
    </div>
  )
}
