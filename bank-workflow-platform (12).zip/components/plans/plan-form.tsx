"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import type { ReviewPlan, Review } from "@/lib/types"

interface PlanFormProps {
  plan?: ReviewPlan | null
  reviews: Review[]
  onSubmit: (data: { name: string; description: string; attached_reviews: string; man_days: number }) => void
  onCancel: () => void
  isLoading?: boolean
}

export function PlanForm({ plan, reviews, onSubmit, onCancel, isLoading }: PlanFormProps) {
  const [name, setName] = useState("")
  const [description, setDescription] = useState("")
  const [attachedReviews, setAttachedReviews] = useState("")
  const [manDays, setManDays] = useState(0)

  useEffect(() => {
    if (plan) {
      setName(plan.name)
      setDescription(plan.description)
      setAttachedReviews(plan.attached_reviews)
      setManDays(plan.man_days || 0)
    } else {
      setName("")
      setDescription("")
      setAttachedReviews("")
      setManDays(0)
    }
  }, [plan])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!name.trim() || !attachedReviews) return
    onSubmit({
      name: name.trim(),
      description: description.trim(),
      attached_reviews: attachedReviews,
      man_days: manDays,
    })
  }

  const isValid = name.trim() && attachedReviews

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="name">Plan Name *</Label>
        <Input id="name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Plan name" required />
      </div>

      <div>
        <Label htmlFor="description">Description</Label>
        <Textarea
          id="description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Brief description"
          rows={3}
        />
      </div>

      <div>
        <Label htmlFor="man_days">Man Days</Label>
        <Input
          id="man_days"
          type="number"
          value={manDays}
          onChange={(e) => setManDays(Number(e.target.value) || 0)}
          placeholder="Estimated man days"
          min="0"
        />
      </div>

      <div>
        <Label htmlFor="review">Review *</Label>
        <Select value={attachedReviews} onValueChange={setAttachedReviews}>
          <SelectTrigger>
            <SelectValue placeholder="Select a review" />
          </SelectTrigger>
          <SelectContent>
            {reviews.map((review) => (
              <SelectItem key={review.id} value={review.id}>
                {review.id} - {review.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="flex justify-end gap-3 pt-4">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit" disabled={!isValid || isLoading}>
          {isLoading ? "Saving..." : plan ? "Update" : "Create"}
        </Button>
      </div>
    </form>
  )
}
