"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Badge } from "@/components/ui/badge"
import { FileText, Edit, Trash2, Plus } from "lucide-react"
import type { Review } from "@/lib/types"

interface ReviewListProps {
  reviews: Review[]
  onEdit: (review: Review) => void
  onDelete: (id: string) => void
  onCreate: () => void
}

export function ReviewList({ reviews, onEdit, onDelete, onCreate }: ReviewListProps) {
  const [selectedIds, setSelectedIds] = useState<string[]>([])

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]))
  }

  const selectAll = () => {
    setSelectedIds(selectedIds.length === reviews.length ? [] : reviews.map((r) => r.id))
  }

  if (reviews.length === 0) {
    return (
      <Card>
        <CardContent className="p-12 text-center">
          <FileText className="h-16 w-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No reviews yet</h3>
          <p className="text-gray-500 mb-6">Create your first review to get started</p>
          <Button onClick={onCreate}>
            <Plus className="h-4 w-4 mr-2" />
            Create Review
          </Button>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-4">
          <Checkbox checked={selectedIds.length === reviews.length} onCheckedChange={selectAll} />
          <span className="text-sm text-gray-600">
            {selectedIds.length > 0 ? `${selectedIds.length} selected` : `${reviews.length} reviews`}
          </span>
        </div>
        <Button onClick={onCreate}>
          <Plus className="h-4 w-4 mr-2" />
          New Review
        </Button>
      </div>

      {/* List */}
      <div className="space-y-2">
        {reviews.map((review) => (
          <Card key={review.id} className="hover:shadow-md transition-shadow">
            <CardContent className="p-4">
              <div className="flex items-center gap-4">
                <Checkbox checked={selectedIds.includes(review.id)} onCheckedChange={() => toggleSelect(review.id)} />

                <div className="bg-blue-100 p-2 rounded">
                  <FileText className="h-4 w-4 text-blue-600" />
                </div>

                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <Badge variant="outline" className="font-mono text-xs">
                      {review.id}
                    </Badge>
                    <h3 className="font-medium">{review.name}</h3>
                  </div>
                  {review.description && <p className="text-sm text-gray-600">{review.description}</p>}
                </div>

                <div className="flex gap-2">
                  <Button size="sm" variant="ghost" onClick={() => onEdit(review)}>
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => onDelete(review.id)}
                    className="text-red-600 hover:text-red-700"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
